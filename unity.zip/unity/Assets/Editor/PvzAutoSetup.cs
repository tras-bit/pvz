// ============================================================================
//  АВТОСБОРКА СЦЕНЫ. Чтобы в проекте из архива не надо было ничего тыкать:
//  при первом открытии Unity сама
//    • заводит sorting layers и Gamma color space,
//    • создаёт Assets/Scenes/PvZ-1-1.unity с GameRoot и открывает её,
//    • добавляет сцену в Build Settings.
//  Дальше — просто Play (F5). Настройки импорта PNG/WAV ставит PvzImporter
//  прямо на первом импорте, его тоже звать не надо. Вмешивается только в
//  «пустой» проект: если открыта твоя сохранённая сцена, она и останется.
//
//  Идемпотентно: если сцена уже есть и на ней есть GameRoot — не трогаем.
//  Ручные пункты меню на месте: PvZ → Создать сцену 1-1, Собрать билд,
//  Проверить ассеты. Автонастройку можно выключить галкой «PvZ → Автонастройка сцены».
// ============================================================================
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using Pvz.View;

namespace PvzEditor
{
    [InitializeOnLoad]
    public static class PvzAutoSetup
    {
        private const string PrefKey = "Pvz.AutoSetupScene";
        private static bool _scheduled;

        static PvzAutoSetup()
        {
            if (_scheduled) return;
            _scheduled = true;
            // в статическом конструкторе сцену трогать нельзя — ждём первый delayCall
            EditorApplication.delayCall += Run;
        }

        private static void Run()
        {
            if (!EditorPrefs.GetBool(PrefKey, true))
            {
                Debug.Log("[PvZ] автосборка сцены выключена (PvZ → Автонастройка сцены)");
                return;
            }

            bool exists = PvzBootstrapper.SceneOnDisk ||
                          AssetDatabase.LoadAssetAtPath<SceneAsset>(PvzBootstrapper.ScenePath) != null;
            var active = EditorSceneManager.GetActiveScene();

            // Автосборка вмешивается только в случай «просто открыли проект»:
            // активная сцена — пустой «Untitled». Свою сохранённую сцену не отберём.
            bool untitled = !active.IsValid() || active.path.Length == 0;

            if (exists)
            {
                PvzBootstrapper.PrepareProject();               // цвет/слои — на всякий случай
                if (HasGameRoot(active)) return;                // играть уже где — не мешаем
                if (!untitled)
                {
                    Debug.Log("[PvZ] открыта твоя сцена «" + active.name + "» — не переключаю. " +
                              "Нужна игровая: " + PvzBootstrapper.ScenePath + " (или PvZ → Создать сцену 1-1).");
                    return;
                }
                if (active.isDirty)
                {
                    Debug.Log("[PvZ] текущая сцена не сохранена — автосборку не навязываю; " +
                              "открой " + PvzBootstrapper.ScenePath + " или жми PvZ → Создать сцену 1-1");
                    return;
                }
                EditorSceneManager.OpenScene(PvzBootstrapper.ScenePath, OpenSceneMode.Single);
                Debug.Log("[PvZ] открыта сцена " + PvzBootstrapper.ScenePath + " → Play");
                return;
            }

            if (!untitled || active.isDirty)
            {
                Debug.Log("[PvZ] сцены " + PvzBootstrapper.ScenePath + " ещё нет, но у тебя открыта своя — " +
                          "создавать поверх неё не буду. Жми PvZ → Создать сцену 1-1.");
                return;
            }

            PvzBootstrapper.CreateScene();
            Debug.Log("[PvZ] сцена собрана автоматически → Play (F5)");
        }

        private static bool HasGameRoot(UnityEngine.SceneManagement.Scene scene)
        {
            if (!scene.IsValid()) return false;
            var gos = scene.GetRootGameObjects();
            for (int i = 0; i < gos.Length; i++)
                if (gos[i].GetComponent<GameRoot>() != null || gos[i].GetComponentInChildren<GameRoot>(true) != null)
                    return true;
            return false;
        }

        [MenuItem("PvZ/Автонастройка сцены")]
        private static void Toggle()
        {
            bool on = !EditorPrefs.GetBool(PrefKey, true);
            EditorPrefs.SetBool(PrefKey, on);
            Menu.SetChecked("PvZ/Автонастройка сцены", on);
            Debug.Log("[PvZ] автосборка сцены: " + (on ? "вкл" : "выкл"));
        }

        [MenuItem("PvZ/Автонастройка сцены", true, 0)]
        private static bool ToggleValidate()
        {
            Menu.SetChecked("PvZ/Автонастройка сцены", EditorPrefs.GetBool(PrefKey, true));
            return true;
        }
    }
}
