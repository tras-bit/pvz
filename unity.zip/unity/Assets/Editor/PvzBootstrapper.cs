// ============================================================================
//  Пуск проекта за два клика.
//
//    PvZ → Создать сцену 1-1      — делает сцену с GameRoot, заводит sorting
//                                   layers, ставит Gamma color space, добавляет
//                                   сцену в Build Settings. После этого F5 (Play).
//    PvZ → Проверить ассеты       — говорит, каких картинок не хватает (арт-контракт).
//
//  Никаких URP/2D-пакетов не нужно: игра рисует спрайтами Built-in 2D и своим
//  программным буфером (Tex), шрифт тоже свой (Glyphs).
// ============================================================================
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEngine;
using Pvz.View;

namespace PvzEditor
{
    public static class PvzBootstrapper
    {
        public const string ScenePath = "Assets/Scenes/PvZ-1-1.unity";
        public const string BuildDir = "Pvz-Build";
        private const string ResRoot = "Assets/Resources/Pvz";

        /// <summary>Корень проекта (Unity держит cwd = он, но полагаться на cwd —
        /// хрупко: все файловые проверки ведём от Application.dataPath).</summary>
        public static string ProjectDir
        {
            get
            {
                string data = Application.dataPath;                       // <project>/Assets
                string dir = string.IsNullOrEmpty(data) ? null : Path.GetDirectoryName(Path.GetFullPath(data));
                return string.IsNullOrEmpty(dir) ? Directory.GetCurrentDirectory() : dir;
            }
        }

        /// <summary>Путь «от корня проекта» → абсолютный (Unity живёт в корне проекта,
        /// но cwd — вещь хрупкая, поэтому все файловые проверки идут так).</summary>
        public static string Abs(string projectRelative)
        {
            return Path.Combine(ProjectDir, projectRelative.Replace('/', Path.DirectorySeparatorChar));
        }

        /// <summary>Файл сцены на диске (абсолютный путь).</summary>
        public static string SceneFile { get { return Abs(ScenePath); } }
        public static bool SceneOnDisk { get { return File.Exists(SceneFile); } }

        /// <summary>Настройки проекта, без которых картинка/порядок слоёв поедут.
        /// Вызывается и из автосборки (PvzAutoSetup), и из меню.</summary>
        public static void PrepareProject()
        {
            EnsureColorSpace();
            EnsureSortingLayers();
        }

        [MenuItem("PvZ/Создать сцену 1-1", false, 0)]
        public static void CreateScene()
        {
            PrepareProject();

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            var go = new GameObject("PvZ");
            var root = go.AddComponent<GameRoot>();
            root.LevelIndex = 0;
            root.StartInMenu = true;         // сначала меню, как в настоящей PvZ
            root.PixelPerfect = true;        // целые масштабы, без ресемпла
            Undo.RegisterCreatedObjectUndo(go, "PvZ");

            Directory.CreateDirectory(Path.GetDirectoryName(SceneFile));
            EditorSceneManager.SaveScene(scene, ScenePath);          // Unity ждёт путь от Assets/

            var list = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
            bool has = false;
            for (int i = 0; i < list.Count; i++) if (list[i].path == ScenePath) has = true;
            if (!has) list.Add(new EditorBuildSettingsScene(ScenePath, true));
            EditorBuildSettings.scenes = list.ToArray();

            AssetDatabase.Refresh();
            Debug.Log("[PvZ] сцена готова: " + ScenePath + " → жми Play. " +
                      "Управление: ЛКМ — карточка/посадка, ПКМ — снять руку, P — пауза, R — заново, M — звук, Enter — старт.");
        }

        // ------------------------------------------------------- билд игрока
        /// <summary>Gотовый exe: Unity → PvZ → Собрать билд (Windows).
        /// Сцену создаст сама, если её ещё нет.</summary>
        [MenuItem("PvZ/Собрать билд (Windows)", false, 3)]
        public static void BuildWindows()
        {
            PrepareProject();
            if (!SceneOnDisk) CreateScene();

            string dir = Path.Combine(ProjectDir, BuildDir);
            Directory.CreateDirectory(dir);
            string exe = Path.Combine(dir, "PvZ.exe");

            var opts = new BuildPlayerOptions
            {
                scenes = new[] { ScenePath },
                locationPathName = exe,
                target = BuildTarget.StandaloneWindows64,
                options = BuildOptions.None
            };
            // в 2022.3 у BuildReport нет result/totalTime — они в BuildSummary
            BuildReport report = BuildPipeline.BuildPlayer(opts);
            BuildSummary sum = report.summary;
            Debug.Log("[PvZ] билд " + sum.result + ": " + sum.outputPath + "  (" +
                      sum.totalSize / (1024 * 1024) + " МБ, " + sum.totalTime +
                      ", ошибок " + sum.totalErrors + ", предупреждений " + sum.totalWarnings + ")");
            if (sum.result != BuildResult.Succeeded) Debug.LogError("[PvZ] отчёт сборки:\n" + report.SummarizeErrors());
            else EditorUtility.RevealInFinder(exe);
        }

        // --------------------------------------------------------- настройки
        private static void EnsureColorSpace()
        {
            if (PlayerSettings.colorSpace == ColorSpace.Gamma) return;
            PlayerSettings.colorSpace = ColorSpace.Gamma;      // как в браузере: смешиваем в sRGB
            Debug.Log("[PvZ] Color Space → Gamma (пиксель-арт и аддитивные вспышки совпадают с web)");
        }

        /// <summary>Заводит sorting layers по списку Sort.All (Default остаётся первым).</summary>
        private static void EnsureSortingLayers()
        {
            var obj = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset");
            if (obj == null || obj.Length == 0)
            {
                Debug.LogWarning("[PvZ] не нашёл ProjectSettings/TagManager.asset — sorting layers не трогал " +
                                 "(порядок всё равно правильный: Layer.Order закладывает старший разряд)");
                return;
            }
            var so = new SerializedObject(obj[0]);
            var arr = so.FindProperty("m_SortingLayers");
            if (arr == null) { Debug.LogWarning("[PvZ] m_SortingLayers не найден"); return; }

            var known = new HashSet<string>();
            for (int i = 0; i < arr.arraySize; i++)
            {
                var nm = arr.GetArrayElementAtIndex(i).FindPropertyRelative("name");
                if (nm != null) known.Add(nm.stringValue);
            }
            int added = 0, id = 1000;
            for (int i = 0; i < Sort.All.Length; i++)
            {
                string name = Sort.All[i];
                if (known.Contains(name)) continue;
                int at = arr.arraySize;
                arr.InsertArrayElementAtIndex(at);
                var el = arr.GetArrayElementAtIndex(at);
                el.FindPropertyRelative("name").stringValue = name;
                el.FindPropertyRelative("uniqueID").intValue = id++;
                var locked = el.FindPropertyRelative("locked");
                if (locked != null) locked.boolValue = false;
                added++;
            }
            if (added > 0)
            {
                so.ApplyModifiedProperties();
                Debug.Log("[PvZ] добавлено sorting layers: " + added + " (" + string.Join(", ", Sort.All) + ")");
            }
        }

        // ------------------------------------------------------ арт-контракт
        private static readonly string[] Required =
        {
            "assets/plants/sunflower.png",
            "assets/plants/peashooter.png",
            "assets/plants/cherry.png",
            "assets/zombies/cone.png",
            "assets/zombies/cone-dmg.png",
            "assets/zombies/basic.png",
            "assets/lawn/grass-0.png",
            "assets/lawn/grass-1.png",
            "assets/fx/sun.png",
            "assets/fx/pea.png",
            "assets/mowers/mower.png",
        };

        /// <summary>Прогресс (открытые растения и уровни) живёт в PlayerPrefs —
        /// здесь же и сбрасывается, чтобы 1-1 снова starting с одним горохострелом.</summary>
        [MenuItem("PvZ/Сбросить прогресс", false, 12)]
        public static void ResetProgress()
        {
            Pvz.View.Progress.Reset();
            Debug.Log("[PvZ] прогресс сброшен: открыто «ПРИКЛЮЧЕНИЕ 1-1», из растений только горохострел.");
        }

        [MenuItem("PvZ/Проверить ассеты", false, 11)]
        public static void CheckAssets()
        {
            var missing = new List<string>();
            string resAbs = Abs(ResRoot);
            for (int i = 0; i < Required.Length; i++)
                if (!File.Exists(Path.Combine(resAbs, Required[i]))) missing.Add(Required[i]);

            int png = 0, wav = 0;
            if (Directory.Exists(resAbs))
            {
                png = Directory.GetFiles(resAbs, "*.png", SearchOption.AllDirectories).Length;
                wav = Directory.GetFiles(resAbs, "*.wav", SearchOption.AllDirectories).Length;
            }
            string audio = "";
            string[] want = { "plant", "sunDrop", "collect", "shoot", "hit", "chomp", "die", "error", "wave", "mower", "win", "lose", "boom" };
            for (int i = 0; i < want.Length; i++)
                if (!File.Exists(Path.Combine(resAbs, "audio", want[i] + ".wav"))) audio += (audio.Length == 0 ? "" : ", ") + want[i];

            Debug.Log(string.Format("[PvZ] ассеты: {0} png, {1} wav в {2}. картинок не хватает: {3}; звука не хватает: {4}. " +
                                    "Обновить из web-проекта: python3 ../../pvz-pixel/tools/export_unity.py",
                png, wav, ResRoot,
                missing.Count == 0 ? "нет" : string.Join(", ", missing),
                audio.Length == 0 ? "нет" : audio));
            if (missing.Count > 0 || audio.Length > 0)
                EditorUtility.DisplayDialog("PvZ: чего-то не хватает",
                    "Картинки: " + (missing.Count == 0 ? "все на месте" : string.Join("\n", missing)) +
                    "\n\nЗвук: " + (audio.Length == 0 ? "весь на месте" : audio),
                    "Ок");
        }
    }
}
