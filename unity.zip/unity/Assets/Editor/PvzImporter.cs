// ============================================================================
//  Настройка импорта ассетов PvZ. Кидать картинку в Assets/Resources/Pvz/** —
//  и она сразу становится пиксельным спрайтом с нужными параметрами:
//
//    PPU = 1            1 юнит = 1 пиксель (View-слой считает координаты в пикселях)
//    pivot = TopLeft    начало координат — левый верхний угол, как в canvas
//    Point / без mipmap никаких «мягких» краёв и мерцания при масштабе
//    Read/Write         нужен Tex.Blit: он читает пиксели спрайтов, когда печёт фон/HUD
//    Full Rect          без Tight-обрезки, иначе якорь «съедет»
//
//  Важно для API: часть настроек в 2022.3 лежит НЕ на TextureImporter, а в
//  TextureImporterSettings (spriteAlignment, spritePivot, spriteMeshType,
//  spriteExtrude — читаются/пишутся через ReadTextureSettings/SetTextureSettings),
//  а у звука все loadType/compressionFormat переехали в AudioImporterSampleSettings
//  (AudioImporter.defaultSampleSettings). Имена ignoreMasterTextureLimit больше нет —
//  с 2022.2 это ignoreMipmapLimit.
//
//  Меню: PvZ → Переимпортировать ассеты (если менял настройки или доложил картинки).
// ============================================================================
using System.IO;
using UnityEditor;
using UnityEngine;

namespace PvzEditor
{
    public sealed class PvzImporter : AssetPostprocessor
    {
        private const string Root = "Assets/Resources/Pvz";

        private static bool Under(string path)
        {
            string p = path.Replace('\\', '/');
            return p.StartsWith(Root + "/", System.StringComparison.Ordinal)
                && !p.EndsWith(".meta", System.StringComparison.OrdinalIgnoreCase);
        }

        private void OnPreprocessTexture()
        {
            if (!Under(assetPath)) return;
            var ti = (TextureImporter)assetImporter;

            // то, что живёт на самом импортере
            ti.textureType = TextureImporterType.Sprite;
            ti.spriteImportMode = SpriteImportMode.Single;
            ti.spritePixelsPerUnit = 1f;
            ti.mipmapEnabled = false;
            ti.streamingMipmaps = false;
            ti.filterMode = FilterMode.Point;
            ti.wrapMode = TextureWrapMode.Clamp;
            ti.isReadable = true;
            ti.ignoreMipmapLimit = true;                     // «ignore master texture limit» в 2022.2+
            ti.npotScale = TextureImporterNPOTScale.None;
            ti.alphaIsTransparency = true;
            ti.compressionQuality = 100;
            ti.textureCompression = TextureImporterCompression.Uncompressed;
            ti.sRGBTexture = true;
            ti.crunchedCompression = false;
            ti.allowAlphaSplitting = false;

            // пивот/сетка — только через TextureImporterSettings
            var st = new TextureImporterSettings();
            ti.ReadTextureSettings(st);            // сигнатура: ReadTextureSettings(settings), не out
            st.spriteAlignment = (int)SpriteAlignment.TopLeft;   // = пивот (0,1), как в canvas
            st.spritePivot = new Vector2(0f, 1f);
            st.spriteBorder = Vector4.zero;
            st.spriteMeshType = SpriteMeshType.FullRect;
            st.spriteExtrude = 0;
            ti.SetTextureSettings(st);
        }

        private void OnPreprocessAudio()
        {
            if (!Under(assetPath)) return;
            var ai = (AudioImporter)assetImporter;
            ai.forceToMono = false;
            ai.loadInBackground = false;

            // в 2022.3 loadType/compressionFormat живут в AudioImporterSampleSettings
            AudioImporterSampleSettings s = ai.defaultSampleSettings;
            s.loadType = AudioClipLoadType.DecompressOnLoad;   // короткие семплы — с диска в память как есть
            s.compressionFormat = AudioCompressionFormat.PCM;  // без Vorbis-пережатия
            ai.defaultSampleSettings = s;
        }

        [MenuItem("PvZ/Переимпортировать ассеты", false, 10)]
        public static void Reimport()
        {
            if (!Directory.Exists(PvzBootstrapper.Abs(Root)))
            {
                Debug.LogWarning("[PvZ] нет папки " + Root + " — нечего импортировать");
                return;
            }
            string[] guids = AssetDatabase.FindAssets("", new[] { Root });   // Unity хочет путь от Assets/
            int n = 0;
            foreach (string guid in guids)
            {
                string p = AssetDatabase.GUIDToAssetPath(guid);
                if (Directory.Exists(p)) continue;
                AssetImporter im = AssetImporter.GetAtPath(p);
                if (im == null) continue;
                im.SaveAndReimport();
                n++;
            }
            AssetDatabase.Refresh();
            Debug.Log("[PvZ] переимпортировано файлов: " + n);
        }
    }
}
