// ============================================================================
//  МИР. Порт js/world.js — чистая симуляция, никакой логики рисования.
//  Цель: те же числа, что в браузере (проверяется паритетом, см. tests/README).
// ============================================================================
using System;
using System.Collections.Generic;

namespace Pvz.Core
{
    public enum WorldState { Playing, Won, Lost }

    public enum Fail { None, Idle, Out, Locked, Occupied, Unknown, NoSun, Cool }

    public enum EvKind
    {
        Planted, SunSpawn, SunGrab, SunBanked, Produce, Shoot, PeaHit,
        ZombieSpawn, ZombieLimb, PlantEaten, ZombieDie, RowsUnlock,
        Wave, MowerStart, ZombieMowed, Win, Lose, Explode, ArmorLost,
        Chomp, Dig, PlantCrack,
    }

    /// <summary>Одно событие мира — плоский класс (в JS это был объект {type, ...data}).</summary>
    public sealed class Ev
    {
        public EvKind Kind;
        public Plant Plant;
        public Zombie Zombie;
        public Pea Pea;
        public Sun Sun;
        public Mower Mower;
        public double X, Y;
        public int Row;
        public int Value, Total, Index, Count, Stage, Ids;
        public bool Final;
        public string Type;       // тип зомби / тип солнца ('sky'|'plant')
        public string Hint;
        public string Part;
        public List<int> Rows;
    }

    /// <summary>mulberry32 — тот же генератор, что в JS, чтобы симуляция совпадала бит-в-бит.</summary>
    public sealed class Rng
    {
        private uint _a;
        public Rng(uint seed) { _a = seed; }
        public double Next()
        {
            unchecked
            {
                _a = _a + 0x6d2b79f5u;
                uint t = (uint)((int)(_a ^ (_a >> 15)) * (int)(_a | 1u));
                t = (uint)((int)(t + (uint)((int)(t ^ (t >> 7)) * (int)(61u | t))) ^ (int)t);
                return (t ^ (t >> 14)) / 4294967296.0;
            }
        }
        public int Range(int max) { return (int)(Next() * max); }
    }

    // ---------------------------------------------------------------- Plant ---
    public sealed class Plant
    {
        private static int _id = 0;

        public int Id;
        public string Type;
        public PlantDef Def;
        public int Row, Col;
        public double X, Y;
        public double Hp, MaxHp;
        public bool Alive = true;
        public double Recoil;      // анимация «плевка»
        public double Hurt;        // вспышка после урона
        public double LimbT;
        public double Age;
        public double ProduceTimer;
        public double FireTimer;
        public double FuseTimer;           // взрывчатка (Вишня): сколько осталось до бабаха
        public double FuseMax;
        public double ChewTimer;           // чемпер: >0 — жуёт и в это время не атакует

        public Plant(int row, int col, PlantDef def)
        {
            Id = ++_id;
            Type = def.Id;
            Def = def;
            Row = row; Col = col;
            X = Geo.CellX(col); Y = Geo.CellY(row);
            Hp = def.Hp; MaxHp = def.Hp;
            ProduceTimer = def.Produce != null ? def.Produce.First : double.PositiveInfinity;
            FireTimer = def.Fire != null ? def.Fire.First : double.PositiveInfinity;
            FuseMax = def.Explode != null ? def.Explode.Fuse : double.PositiveInfinity;
            FuseTimer = FuseMax;
        }

        /// <summary>0..1 — насколько «дотлел» фитиль (вьюха по этому мигает и раздувается).</summary>
        public double Fuse { get { return double.IsPositiveInfinity(FuseMax) || FuseMax <= 0 ? 0 : 1.0 - FuseTimer / FuseMax; } }

        public double Cx { get { return X + Geo.TILE / 2; } }
        public double Cy { get { return Y + Geo.TILE / 2; } }
        /// <summary>Правый край «туловища», до которого дотягивается пасть зомби.</summary>
        public double EatEdge { get { return X + 44; } }

        /// <summary>Стадия расколотой скорлупы: 0 цела, дальше по Def.Dmg. Считается
        /// из остатка HP — своего состояния нет, поэтому не может «отстать» от урона.</summary>
        public int Stage
        {
            get
            {
                var dmg = Def.Dmg;
                double r = MaxHp > 0 ? Hp / MaxHp : 1.0;
                int st = 0;
                for (int i = 0; i < dmg.Count; i++) if (r <= dmg[i].At) st = i + 1;
                return st;
            }
        }

        /// <summary>Сколько укусов показать на скорлупе: линейно растёт по мере урона.</summary>
        public int Bites
        {
            get
            {
                int n = Def.Bites.Count;
                if (n == 0) return 0;
                double r = MaxHp > 0 ? System.Math.Max(0.0, Hp / MaxHp) : 0.0;
                int k = (int)System.Math.Floor((1.0 - r) * n + 1e-9);
                return k < 0 ? 0 : (k > n ? n : k);
            }
        }
    }

    // -------------------------------------------------------------- Zombie ----
    public sealed class Zombie
    {
        private static int _id = 0;

        public int Id;
        public string Type;
        public ZombieDef Def;
        public int Row;
        public double Y;
        public double X;
        public double Hp, MaxHp;
        public double ArmorHp, ArmorMax;      // конус/ведро: урон сначала по броне
        public bool Alive = true;
        public string State = "walk";         // walk | eat | die
        public Plant Target;
        public double Hurt;
        public double LimbT;
        public double Phase;
        public double DieT;
        public double SpawnedAt;

        public Zombie(int row, ZombieDef def, Rng rng)
        {
            Id = ++_id;
            Type = def.Id;
            Def = def;
            Row = row;
            Y = Geo.CellY(row);
            X = Geo.LAWN_RIGHT + 20 + (rng != null ? rng.Next() : 0.5) * 16;
            Hp = def.Hp; MaxHp = def.Hp;
            ArmorMax = def.Armor; ArmorHp = def.Armor;
            Phase = (rng != null ? rng.Next() : 0.5) * 6.283;
        }

        /// <summary>Доля брони: 1 = конус целый, 0 = слетел.</summary>
        public double ArmorRatio { get { return ArmorMax <= 0 ? 0 : ArmorHp / ArmorMax; } }

        public double FootY { get { return Y + Geo.TILE; } }
        public double Front { get { return X - Def.Mouth; } }

        /// <summary>0 целым, 1 без руки, 2 без руки и ноги, 3 без головы.</summary>
        public int Stage
        {
            get
            {
                var dmg = Def.Dmg;
                // пока броня держит, тело не «портится»: урон считаем по общему запасу
                double r = (Hp + ArmorHp) / (double)(MaxHp + Def.Armor);
                int st = 0;
                for (int i = 0; i < dmg.Count; i++) if (r <= dmg[i].At) st = i + 1;
                return st;
            }
        }

        public double HurtLeft { get { return X - Def.HitW / 2; } }
        public double HurtRight { get { return X + Def.HitW / 2; } }
    }

    // ------------------------------------------------------------------ Pea ---
    public sealed class Pea
    {
        private static int _id = 0;
        public int Id;
        public int Row;
        public double X, Y;
        public int Damage;
        public bool Alive = true;
        public double Life;

        public Pea(int row, double x, double y, int damage)
        {
            Id = ++_id; Row = row; X = x; Y = y; Damage = damage; Life = CFG.PEA.Life;
        }
    }

    // ------------------------------------------------------------------ Sun ---
    public sealed class Sun
    {
        private static int _id = 0;
        public int Id;
        public string Kind;           // 'sky' | 'plant'
        public int Value;
        public double X, Y, RestY;
        public string State;          // fall | pop | rest | collect
        public double Vx, Vy;
        public double Life;
        public double Fade = 1;
        public double Collect;
        public double Spin;
        public bool Alive = true;
        public double FromX, FromY;

        public Sun(double x, double y, int value, string kind, double restY, Rng rng)
        {
            Id = ++_id;
            Kind = kind; Value = value; X = x; Y = y; RestY = restY;
            bool sky = kind == "sky";
            State = sky ? "fall" : "pop";
            double r1 = rng != null ? rng.Next() : 0.5, r2 = rng != null ? rng.Next() : 0.5;
            Vx = sky ? ((r1 - 0.5) * 12) : ((r1 - 0.5) * 70);
            Vy = sky ? CFG.SUN.FallSpeed : -CFG.SUN.PopUp;
            Life = CFG.SUN.IdleTime;
            Spin = r2 * 6.283;
        }
    }

    // ---------------------------------------------------------------- Mower ---
    public sealed class Mower
    {
        public int Row;
        public double X;
        public string State = "idle";         // idle | run
        public double Spin;
        public bool Gone;

        public Mower(int row) { Row = row; X = CFG.MOWER.IdleX; }
        public double GroundY { get { return Geo.LAWN_Y + (Row + 1) * Geo.TILE; } }
    }

    // ---------------------------------------------------------------- World ---
    public sealed class World
    {
        private sealed class SpawnItem { public string Type; public int Row; public double T; public bool Done; }

        public readonly LevelDef Level;
        public readonly Rng Rng;
        public UnityEngine.Vector2 Bank;

        public double Time;
        public int SunCount;          // world.sun в JS (имя не Sun, чтобы не спорить с классом Sun)
        public WorldState State = WorldState.Playing;
        public double EndTimer;

        public readonly List<Plant> Plants = new List<Plant>();
        public readonly List<Zombie> Zombies = new List<Zombie>();
        public readonly List<Pea> Peas = new List<Pea>();
        public readonly List<Sun> Suns = new List<Sun>();
        public readonly List<Ev> Events = new List<Ev>();
        public readonly List<Mower> Mowers = new List<Mower>();

        public readonly Dictionary<long, Plant> PlantsAt = new Dictionary<long, Plant>();
        // сколько осталось до следующей посадки этого растения (тип -> секунды).
        // _coolKeys — тот же набор ключей списком: тикаем ПО НЕМУ, а словарь под ногами
        // не трогаем. В Mono (то есть в Unity) присваивание dict[k] = v инвалидирует
        // итератор и foreach падает InvalidOperationException «Collection was modified»,
        // хотя на .NET Core за тем же кодом ничего не происходит. Так что: никаких
        // мутаций коллекции во время её же перечисления — проверено офлайн-харнессом.
        private readonly Dictionary<string, double> _cool = new Dictionary<string, double>();
        private readonly List<string> _coolKeys = new List<string>();
        public readonly Dictionary<string, int> PlantedCount = new Dictionary<string, int>();
        // порядок вставки важен: «случайная полоса» обязана считаться как в JS
        // (там Set итерируется в порядке вставки), поэтому List, не HashSet
        public readonly List<int> UnlockedRows = new List<int>();
        /// <summary>Карточки в пачке: seeds уровня ∩ открытое (пусто = весь уровень).</summary>
        public readonly List<string> Seeds = new List<string>();

        public int TotalZombies;
        public int SpawnedZombies;
        public int KilledZombies;

        public int WaveIndex;
        private readonly List<SpawnItem> _spawnQueue = new List<SpawnItem>();
        public double SpawnGap;
        private double _nextSkySun;
        private static long Key(int row, int col) { return row * 1000L + col; }

        public World(LevelDef level, uint seed = 1337u, IReadOnlyList<string> unlockedPlants = null)
        {
            Level = level;
            Rng = new Rng(seed);
            Bank = CFG.HUD.SunIconAt;
            SunCount = level.StartSun;

            foreach (int r in level.Rows) UnlockRow(r);
            foreach (int r in level.Rows) Mowers.Add(new Mower(r));    // по одной на открытую полосу

            foreach (string id in level.Seeds)
            {
                if (unlockedPlants == null) { Seeds.Add(id); continue; }
                for (int i = 0; i < unlockedPlants.Count; i++)
                    if (unlockedPlants[i] == id) { Seeds.Add(id); break; }
            }
            if (Seeds.Count == 0) Seeds.AddRange(level.Seeds);         // совсем без открытого — играем чем умеем

            TotalZombies = level.TotalZombies;
            if (TotalZombies <= 0)
            {
                int n = 0;
                foreach (var w in level.Waves) n += w.Zombies.Count;
                TotalZombies = n;
            }
            SpawnGap = CFG.GAME.SeedGapInWave;
            _nextSkySun = level.SkySun.First;
        }

        /// <summary>Открыть полосу (false — уже была открыта).</summary>
        public bool UnlockRow(int row)
        {
            if (UnlockedRows.Contains(row)) return false;
            UnlockedRows.Add(row);
            return true;
        }

        /// <summary>Случайная открытая полоса (тот же порядок RNG, что в JS).</summary>
        public int PickRow()
        {
            if (UnlockedRows.Count == 0) return Geo.ROWS / 2;
            UnlockedRows.Sort();
            return UnlockedRows[(int)(Rng.Next() * UnlockedRows.Count)];
        }

        /// <summary>Случайный зомби: выбор из Roster'а уровня по весам.</summary>
        public string PickRosterType()
        {
            var roster = Level.Roster;
            if (roster == null || roster.Count == 0) return "basic";
            int sum = 0;
            for (int i = 0; i < roster.Count; i++) sum += roster[i].Weight > 0 ? roster[i].Weight : 1;
            double r = Rng.Next() * sum;
            for (int i = 0; i < roster.Count; i++)
            {
                double w = roster[i].Weight > 0 ? roster[i].Weight : 1;
                if (r < w) return roster[i].Type;
                r -= w;
            }
            return roster[roster.Count - 1].Type;
        }

        // --- события ---------------------------------------------------------
        private void Emit(EvKind kind, Action<Ev> fill = null)
        {
            var e = new Ev(); e.Kind = kind;
            if (fill != null) fill(e);
            Events.Add(e);
        }
        public List<Ev> DrainEvents() { var e = new List<Ev>(Events); Events.Clear(); return e; }

        // --- сетка -----------------------------------------------------------
        public bool IsUnlocked(int row) { return UnlockedRows.Contains(row); }

        /// <summary>Можно ли сажать это семя на этом уровне (есть в пачке).</summary>
        public bool Allows(string plantId)
        {
            for (int i = 0; i < Seeds.Count; i++) if (Seeds[i] == plantId) return true;
            return false;
        }

        /// <summary>Сколько секунд карточка ещё «отдыхает» (0 = готова).</summary>
        public double CooldownLeft(string plantId)
        {
            double v;
            return _cool.TryGetValue(plantId, out v) ? v : 0.0;
        }

        public bool Ready(string plantId) { return CooldownLeft(plantId) <= 0; }

        /// <summary>Мгновенно зарядить все карточки (чит-клавиша C и офлайн-харнесс).</summary>
        public void RechargeAll()
        {
            _cool.Clear();
            _coolKeys.Clear();
        }
        public Plant PlantAt(int row, int col) { Plant p; return PlantsAt.TryGetValue(Key(row, col), out p) ? p : null; }

        public Fail CanPlant(int row, int col, string type)
        {
            if (State != WorldState.Playing) return Fail.Idle;
            if (!Geo.InLawn(row, col)) return Fail.Out;
            if (!IsUnlocked(row)) return Fail.Locked;
            if (PlantAt(row, col) != null) return Fail.Occupied;
            var def = CFG.Plant(type);
            if (def == null) return Fail.Unknown;
            if (CooldownLeft(type) > 0) return Fail.Cool;
            if (SunCount < def.Cost) return Fail.NoSun;
            return Fail.None;
        }

        /// <summary>Посадка семени (world.plant в JS).</summary>
        public Plant Place(int row, int col, string type, out Fail fail)
        {
            fail = CanPlant(row, col, type);
            if (fail != Fail.None) return null;
            var def = CFG.Plant(type);
            var p = new Plant(row, col, def);
            Plants.Add(p);
            PlantsAt[Key(row, col)] = p;
            int have;
            PlantedCount.TryGetValue(type, out have);
            PlantedCount[type] = have + 1;
            SunCount -= def.Cost;
            // карточка уходит на перезарядку (ключ в словарь добавляем ЗДЕСЬ, вне тика)
            if (def.Cooldown > 0)
            {
                if (!_cool.ContainsKey(type)) _coolKeys.Add(type);
                _cool[type] = def.Cooldown;
            }
            var pl = p;
            Emit(EvKind.Planted, e => { e.Plant = pl; e.X = pl.Cx; e.Y = pl.Cy; });
            return p;
        }

        /// <summary>Лопата: убрать своё растение. Солнце НЕ возвращается — как в оригинале.</summary>
        public Plant Dig(int row, int col)
        {
            Plant p;
            if (!PlantsAt.TryGetValue(Key(row, col), out p)) return null;
            RemovePlant(p);
            var pp = p; var rr = row; var cc = col;
            Emit(EvKind.Dig, e => { e.Plant = pp; e.X = pp.Cx; e.Y = pp.Cy; e.Row = rr; e.Value = cc; });
            return pp;
        }

        public void RemovePlant(Plant p)
        {
            p.Alive = false;
            PlantsAt.Remove(Key(p.Row, p.Col));
            Plants.Remove(p);
        }

        // --- солнце ----------------------------------------------------------
        public void SpawnSkySun()
        {
            var cfg = Level.SkySun;
            double x = (Geo.LAWN_X + 24 + Rng.Next() * (Geo.LAWN_RIGHT - Geo.LAWN_X - 48));
            double restY = (Geo.LAWN_Y + 40 + Rng.Next() * (Geo.LAWN_BOTTOM - Geo.LAWN_Y - 80));
            var s = new Sun(x, Geo.LAWN_Y - 70, cfg.Value, "sky", restY, Rng);
            Suns.Add(s);
            var su = s;
            Emit(EvKind.SunSpawn, e => { e.Sun = su; e.Type = "sky"; });
        }

        public void SpawnPlantSun(Plant p)
        {
            // садится в правый нижний угол клетки: там трава, а не листья/лицо подсолнуха
            double x = Math.Min(Math.Max(p.Cx + 18 + ((Rng.Next() - 0.5) * 10), Geo.LAWN_X + 18), Geo.LAWN_RIGHT - 18);
            double y = Math.Min(p.Y + Geo.TILE - 12, Geo.LAWN_BOTTOM - 12);
            var s = new Sun(x, y, p.Def.Produce.Value, "plant", y, Rng);
            Suns.Add(s);
            var su = s; var pl = p;
            Emit(EvKind.SunSpawn, e => { e.Sun = su; e.Type = "plant"; e.Plant = pl; });
            Emit(EvKind.Produce, e => { e.Plant = pl; });
        }

        public bool PickSun(double x, double y)
        {
            Sun best = null;
            double bestD = CFG.SUN.HitRadius * CFG.SUN.HitRadius;
            for (int i = 0; i < Suns.Count; i++)
            {
                var s = Suns[i];
                if (s.State == "collect") continue;
                double d = (s.X - x) * (s.X - x) + (s.Y - y) * (s.Y - y);
                if (d <= bestD) { bestD = d; best = s; }
            }
            if (best == null) return false;
            best.State = "collect";
            best.Collect = 0;
            best.FromX = best.X;
            best.FromY = best.Y;
            var su = best;
            Emit(EvKind.SunGrab, e => { e.Sun = su; });
            return true;
        }

        /// <summary>«собери всё» — удобно в тестах и для кнопки-подсказки.</summary>
        public void CollectAllSuns()
        {
            var copy = new List<Sun>(Suns);
            foreach (var s in copy) if (s.State != "collect") PickSun(s.X, s.Y);
        }

        public void AddSun(int value)
        {
            SunCount += value;
            int total = SunCount;
            Emit(EvKind.SunBanked, e => { e.Value = value; e.Total = total; });
        }

        public void UpdateSuns(double dt)
        {
            for (int i = 0; i < Suns.Count; i++)
            {
                var s = Suns[i];
                if (s.State == "fall")
                {
                    s.Y += (s.Vy * dt);
                    s.X += (s.Vx * dt);
                    if (s.Y >= s.RestY) { s.Y = s.RestY; s.State = "rest"; }
                }
                else if (s.State == "pop")
                {
                    s.Vy += (CFG.SUN.Gravity * dt);
                    s.Y += (s.Vy * dt);
                    s.X += (s.Vx * dt);
                    if (s.Vy > 0 && s.Y >= s.RestY) { s.Y = s.RestY; s.State = "rest"; }
                }
                else if (s.State == "rest")
                {
                    s.Life -= dt;
                    s.Fade = s.Life < CFG.SUN.FadeTime ? Math.Max(0.0, (s.Life / CFG.SUN.FadeTime)) : 1;
                    if (s.Life <= 0) s.Alive = false;     // солнце сгорело, никто не наступил
                }
                else if (s.State == "collect")
                {
                    s.Collect += dt / CFG.SUN.CollectTime;
                    double t = Math.Min(1.0, s.Collect);
                    double e = t * t * (3 - 2 * t);       // smoothstep
                    s.X = (s.FromX + (Bank.x - s.FromX) * e);
                    s.Y = (s.FromY + (Bank.y - s.FromY) * e - Math.Sin(t * Math.PI) * 12);
                    if (t >= 1) { s.Alive = false; AddSun(s.Value); }
                }
                s.Spin += dt * 1.5;
            }
            Suns.RemoveAll(q => !q.Alive);
        }

        // --- растения --------------------------------------------------------
        public void UpdatePlants(double dt)
        {
            for (int i = 0; i < Plants.Count; i++)
            {
                var p = Plants[i];
                p.Age += dt;
                p.Recoil = Math.Max(0.0, p.Recoil - dt);
                p.Hurt = Math.Max(0.0, p.Hurt - dt);
                p.LimbT = Math.Max(0.0, p.LimbT - dt);   // толчок после нового куска скорлупы

                if (p.Def.Explode != null)
                {
                    p.FuseTimer -= dt;
                    if (p.FuseTimer <= 0) Explode(p);
                    continue;                       // взрывчатка и не светит, и не стреляет
                }

                if (p.Def.Produce != null)
                {
                    p.ProduceTimer -= dt;
                    if (p.ProduceTimer <= 0)
                    {
                        p.ProduceTimer = p.Def.Produce.Interval;
                        SpawnPlantSun(p);
                    }
                }

                if (p.Def.Chomp != null)
                {
                    // Хищник: один зомби в пределах двух КЛЕТОК ВПЕРЕД (c+1 и c+2) — и он его сжуёт.
                    // Пока жуёт (20 с), не атакует вообще: это и есть цена «мгновенной смерти».
                    if (p.ChewTimer > 0) { p.ChewTimer = Math.Max(0.0, p.ChewTimer - dt); continue; }
                    var tz = FirstZombieInRow(p.Row, p.EatEdge - 6.0);
                    // как в js/world.js: дистанция от ПЕРЕДНЕГО края клетки, иначе
                    // «две клетки» сжимаются в одну за счёт ширины самой клетки
                    double reach = p.X + Geo.TILE + p.Def.Chomp.Tiles * Geo.TILE;
                    if (tz != null && tz.X <= reach)
                    {
                        p.ChewTimer = p.Def.Chomp.Chew;
                        p.Recoil = 0.5;                  // рывок головой — та же ось, что у «плевка»
                        HurtZombie(tz, p.Def.Chomp.Damage);
                        var pc = p; var zc = tz;
                        Emit(EvKind.Chomp, e => { e.Plant = pc; e.Zombie = zc; e.X = pc.Cx; e.Y = pc.Cy; });
                    }
                    continue;                           // хищник не стреляет и не светит
                }

                if (p.Def.Fire != null)
                {
                    p.FireTimer -= dt;
                    if (p.FireTimer <= 0)
                    {
                        var z = FirstZombieInRow(p.Row, p.EatEdge);
                        if (z != null)
                        {
                            p.FireTimer = p.Def.Fire.Interval;
                            p.Recoil = 0.16;
                            var pea = new Pea(p.Row, p.X + p.Def.Muzzle.x, p.Y + p.Def.Muzzle.y, p.Def.Fire.Damage);
                            Peas.Add(pea);
                            var pp = p; var pe = pea;
                            Emit(EvKind.Shoot, e => { e.Plant = pp; e.Pea = pe; });
                        }
                        else
                        {
                            p.FireTimer = 0.12;   // тихо поглядываем в сторону дороги
                        }
                    }
                }
            }
        }

        /// <summary>Вишня: сносит всё в квадрате (2*Tiles+1)² вокруг своей клетки.</summary>
        public void Explode(Plant p)
        {
            var ex = p.Def.Explode;
            int hit = 0;
            for (int i = 0; i < Zombies.Count; i++)
            {
                var z = Zombies[i];
                if (!z.Alive || z.State == "die") continue;
                if (System.Math.Abs(z.Row - p.Row) > ex.Tiles) continue;
                int zc = Geo.ColAt(z.X);
                if (zc < p.Col - ex.Tiles || zc > p.Col + ex.Tiles) continue;
                HurtZombie(z, ex.Damage);
                hit++;
            }
            RemovePlant(p);
            var pp = p;
            Emit(EvKind.Explode, e =>
            {
                e.Plant = pp; e.X = pp.Cx; e.Y = pp.Cy; e.Count = hit; e.Value = ex.Damage; e.Row = pp.Row;
            });
        }

        /// <summary>Первый (ближайший слева) живой зомби в дорожке, который правее xFrom.</summary>
        public Zombie FirstZombieInRow(int row, double xFrom)
        {
            Zombie best = null;
            for (int i = 0; i < Zombies.Count; i++)
            {
                var z = Zombies[i];
                if (!z.Alive || z.State == "die" || z.Row != row) continue;
                if (z.HurtRight < xFrom) continue;             // уже за спиной растения
                if (best == null || z.X < best.X) best = z;
            }
            return best;
        }

        // --- зомби -----------------------------------------------------------
        public Zombie SpawnZombie(string type, int row)
        {
            var def = CFG.Zombie(type);
            var z = new Zombie(row, def, Rng);
            z.SpawnedAt = Time;
            Zombies.Add(z);
            SpawnedZombies++;
            var zz = z;
            Emit(EvKind.ZombieSpawn, e => { e.Zombie = zz; e.Row = row; e.Type = type; });
            return z;
        }

        /// <summary>Растение, на которое наткнулась пасть зомби (правое в дорожке).</summary>
        public Plant PlantInFront(Zombie z)
        {
            Plant best = null;
            for (int i = 0; i < Plants.Count; i++)
            {
                var p = Plants[i];
                if (p.Row != z.Row) continue;
                if (z.Front > p.EatEdge) continue;             // ещё не дотянулся
                if (z.X < p.X) continue;                       // прошёл мимо/за спину
                if (best == null || p.X > best.X) best = p;
            }
            return best;
        }

        public void UpdateZombies(double dt)
        {
            for (int i = 0; i < Zombies.Count; i++)
            {
                var z = Zombies[i];
                z.Hurt = Math.Max(0.0, z.Hurt - dt);
                z.LimbT = Math.Max(0.0, z.LimbT - dt);

                if (z.State == "die")
                {
                    z.DieT += dt;
                    if (z.DieT > 0.7) z.Alive = false;
                    continue;
                }

                var target = PlantInFront(z);
                z.Target = target;

                if (target != null)
                {
                    z.State = "eat";
                    int stageBefore = target.Stage;
                    target.Hp -= (z.Def.EatDps * dt);
                    target.Hurt = 0.18;
                    // новый укус = новый скол: дёргаемся и сыплем осколками (View по event'у)
                    if (target.Stage > stageBefore)
                    {
                        target.LimbT = 0.34;
                        var pc = target;
                        Emit(EvKind.PlantCrack, e => { e.Plant = pc; e.X = pc.Cx; e.Y = pc.Cy; e.Stage = pc.Stage; });
                    }
                    if (target.Hp <= 0)
                    {
                        var eaten = target;
                        RemovePlant(eaten);
                        Emit(EvKind.PlantEaten, e => { e.Plant = eaten; e.Zombie = z; });
                        z.Target = null;
                        z.State = "walk";
                    }
                }
                else
                {
                    z.State = "walk";
                    z.X -= (z.Def.Speed * dt);
                    z.Phase += dt * 3.2;
                    if (z.X <= CFG.GAME.LoseAtX)
                    {
                        State = WorldState.Lost;
                        var zz = z;
                        Emit(EvKind.Lose, e => { e.Zombie = zz; });
                    }
                }
            }
            Zombies.RemoveAll(q => !q.Alive);
        }

        public void HurtZombie(Zombie z, double damage)
        {
            int stageBefore = z.Stage;

            if (z.ArmorHp > 0)
            {
                if (damage >= z.ArmorHp)
                {
                    damage -= z.ArmorHp;
                    z.ArmorHp = 0;
                    var zz0 = z;
                    Emit(EvKind.ArmorLost, e => { e.Zombie = zz0; e.X = zz0.X; e.Y = zz0.FootY - 58; });
                }
                else
                {
                    z.ArmorHp -= damage;
                    damage = 0;
                }
            }

            z.Hp -= damage;
            z.Hurt = 0.09;
            if (z.Hp <= 0 && z.State != "die")
            {
                z.State = "die";
                z.DieT = 0.0;
                z.Hp = 0.0;
                z.LimbT = 0.34;
                KilledZombies++;
                var zz = z;
                Emit(EvKind.ZombieDie, e => { e.Zombie = zz; });
            }
            // потеря конечности — отдельное событие: на него вешаются куски тела
            if (z.Stage > stageBefore && z.State != "die")
            {
                z.LimbT = 0.34;
                var zz = z;
                int stage = z.Stage;
                Emit(EvKind.ZombieLimb, e =>
                {
                    e.Zombie = zz; e.Stage = stage; e.Part = zz.Def.Dmg[stage - 1].Part;
                });
            }
        }

        // --- горох -----------------------------------------------------------
        public void UpdatePeas(double dt)
        {
            for (int i = 0; i < Peas.Count; i++)
            {
                var pea = Peas[i];
                pea.X += (CFG.PEA.Speed * dt);
                pea.Life -= dt;
                if (pea.Life <= 0 || pea.X > Geo.LAWN_RIGHT + 40) { pea.Alive = false; continue; }
                for (int j = 0; j < Zombies.Count; j++)
                {
                    var z = Zombies[j];
                    if (!z.Alive || z.State == "die" || z.Row != pea.Row) continue;
                    if (pea.X + CFG.PEA.Size / 2 >= z.HurtLeft && pea.X - CFG.PEA.Size / 2 <= z.HurtRight)
                    {
                        HurtZombie(z, pea.Damage);
                        pea.Alive = false;
                        var zz = z; var pp = pea;
                        Emit(EvKind.PeaHit, e => { e.Zombie = zz; e.Pea = pp; e.Value = pp.Damage; });
                        break;
                    }
                }
            }
            Peas.RemoveAll(q => !q.Alive);
        }

        // --- волны ------------------------------------------------------------
        public bool GateOk(WaveDef wave)
        {
            if (wave.GatePlanted == null) return true;
            foreach (var kv in wave.GatePlanted)
            {
                int have;
                PlantedCount.TryGetValue(kv.Key, out have);
                if (have < kv.Value) return false;
            }
            return true;
        }

        public void UpdateWaves(double dt)
        {
            // доспавн зомби текущей волны
            for (int i = 0; i < _spawnQueue.Count; i++)
            {
                var item = _spawnQueue[i];
                item.T -= dt;
                if (item.T <= 0 && !item.Done)
                {
                    item.Done = true;
                    SpawnZombie(item.Type, item.Row);
                }
            }
            _spawnQueue.RemoveAll(q => q.Done);

            if (WaveIndex >= Level.Waves.Count) return;
            var wave = Level.Waves[WaveIndex];
            bool timeOk = wave.Time <= Time;
            if (!timeOk || !GateOk(wave)) return;

            // волна может открыть новые дорожки (как в 1-2, где их становится три)
            if (wave.UnlockRows != null)
            {
                var opened = new List<int>();
                foreach (int row in wave.UnlockRows)
                {
                    if (UnlockRow(row)) { opened.Add(row); Mowers.Add(new Mower(row)); }
                }
                if (opened.Count > 0)
                {
                    var op = opened;
                    Emit(EvKind.RowsUnlock, e => { e.Rows = op; e.Count = op.Count; });
                }
            }

            WaveIndex++;
            double gap = wave.SpawnGap >= 0 ? wave.SpawnGap : SpawnGap;
            for (int i = 0; i < wave.Zombies.Count; i++)
            {
                var spec = wave.Zombies[i];
                // row < 0 → случайная открытая полоса; type == "random" → из Roster'а.
                // Поэтому каждая волна (и каждый R) выглядят по-разному.
                int row = spec.Row >= 0 ? spec.Row : PickRow();
                string type = spec.Type == "random" ? PickRosterType() : spec.Type;
                _spawnQueue.Add(new SpawnItem { Type = type, Row = row, T = i * gap, Done = false });
            }
            Emit(EvKind.Wave, e =>
            {
                e.Index = WaveIndex;
                e.Count = Level.Waves.Count;
                e.Final = wave.Final;
                e.Value = wave.Zombies.Count;
                e.Hint = wave.Hint;
            });
        }

        public int SpawnQueueCount { get { return _spawnQueue.Count; } }

        // --- косилки ---------------------------------------------------------
        public void UpdateMowers(double dt)
        {
            for (int i = 0; i < Mowers.Count; i++)
            {
                var m = Mowers[i];
                if (m.State == "run")
                {
                    m.X += (CFG.MOWER.Speed * dt);
                    m.Spin += dt * 22;
                    for (int j = 0; j < Zombies.Count; j++)
                    {
                        var z = Zombies[j];
                        if (z.Row != m.Row || z.State == "die") continue;
                        if (Math.Abs(z.X - (m.X + 14)) > CFG.MOWER.HitW / 2) continue;
                        var zz = z; var mm = m;
                        Emit(EvKind.ZombieMowed, e => { e.Zombie = zz; e.Mower = mm; });
                        HurtZombie(z, z.Hp + 1);        // скашивает насмерть
                    }
                    if (m.X > Geo.LAWN_RIGHT + 30) m.Gone = true;   // уехала за поле и пропала
                }
                else
                {
                    for (int j = 0; j < Zombies.Count; j++)
                    {
                        var z = Zombies[j];
                        if (z.Row != m.Row || z.State == "die") continue;
                        if (z.Front > CFG.MOWER.At) continue;
                        m.State = "run";
                        var mm = m;
                        Emit(EvKind.MowerStart, e => { e.Mower = mm; e.Row = mm.Row; });
                        break;
                    }
                }
            }
            Mowers.RemoveAll(q => q.Gone);
        }

        // --- главный тик -----------------------------------------------------
        public void Update(double dt)
        {
            if (State != WorldState.Playing)
            {
                // после победы/поражения всё равно досчитываем солнышко, трупы и косилку — красиво
                UpdateSuns(dt);
                UpdateZombies(dt);
                UpdateMowers(dt);
                return;
            }

            Time += dt;

            // перезарядка карточек: идёт по всем заведённым (не только по пачке — тесты и
            // чит-клавиша C работают с типами вне Seeds), обнуляем на месте: присваивание
            // существующего ключа версию словаря не меняет, итератор не рвётся.
            for (int i = 0; i < _coolKeys.Count; i++)
            {
                double v;
                string k = _coolKeys[i];
                if (!_cool.TryGetValue(k, out v) || v <= 0) continue;
                v -= dt;
                _cool[k] = v < 0 ? 0 : v;
            }

            _nextSkySun -= dt;
            if (_nextSkySun <= 0)
            {
                _nextSkySun = Level.SkySun.Interval;
                SpawnSkySun();
            }

            UpdateWaves(dt);
            UpdatePlants(dt);
            UpdateZombies(dt);
            UpdateMowers(dt);         // после зомби: косилка скашивает ровно в тот же тик
            UpdatePeas(dt);
            UpdateSuns(dt);

            // победа: все волны запущены, поле чисто, все зомби со спавна учтены
            if (WaveIndex >= Level.Waves.Count && _spawnQueue.Count == 0 &&
                Zombies.Count == 0 && SpawnedZombies >= TotalZombies)
            {
                EndTimer += dt;
                if (EndTimer >= CFG.GAME.WinDelay)
                {
                    State = WorldState.Won;
                    Emit(EvKind.Win);
                }
            }
        }
    }
}
