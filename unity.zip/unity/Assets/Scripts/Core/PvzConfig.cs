// ============================================================================
//  КОНФИГ. Порт js/config.js — цифры те же, один-в-один.
//  Всё, что хочется крутить, живёт только здесь.
//  В Unity 2022.3 (C# 9): никаких file-scoped namespace, никаких required.
// ============================================================================
using System.Collections.Generic;

namespace Pvz.Core
{
    // --- геометрия -----------------------------------------------------------
    public static class Geo
    {
        public const int TILE = 64;                 // клетка поля = размер спрайта
        public const int COLS = 9;
        public const int ROWS = 5;
        public const int LAWN_X = 32;
        public const int LAWN_Y = 88;
        public const int VIEW_W = 640;
        public const int VIEW_H = 416;

        public const int LAWN_RIGHT = LAWN_X + COLS * TILE;    // 608
        public const int LAWN_BOTTOM = LAWN_Y + ROWS * TILE;   // 408

        public static int CellX(int col) { return LAWN_X + col * TILE; }
        public static int CellY(int row) { return LAWN_Y + row * TILE; }
        public static int ColAt(double x) { return (int)System.Math.Floor((x - LAWN_X) / TILE); }
        public static int RowAt(double y) { return (int)System.Math.Floor((y - LAWN_Y) / TILE); }
        public static bool InLawn(int row, int col) { return row >= 0 && row < ROWS && col >= 0 && col < COLS; }
    }

    // --- палитра (те же 16+ цветов, что и в web-версии) ----------------------
    public static class Pal
    {
        public static UnityEngine.Color32 C(string hex)
        {
            // маленькая помощь для вьюхи: '#rrggbb' → Color32
            if (hex == null) return new UnityEngine.Color32(255, 0, 255, 255);
            string h = hex.StartsWith("#") ? hex.Substring(1) : hex;
            // битый/короткий hex — не падаем: пускай будет магента, её видно на экране
            if (h.Length < 6) return new UnityEngine.Color32(255, 0, 255, 255);
            try
            {
                byte r = System.Convert.ToByte(h.Substring(0, 2), 16);
                byte g = System.Convert.ToByte(h.Substring(2, 2), 16);
                byte b = System.Convert.ToByte(h.Substring(4, 2), 16);
                return new UnityEngine.Color32(r, g, b, 255);
            }
            catch (System.FormatException) { return new UnityEngine.Color32(255, 0, 255, 255); }
        }

        public const string INK = "#151113";
        public const string TEXT = "#ffffff";
        public const string SKY = "#c8edff";
        public const string HEDGE = "#2f7d38";
        public const string HEDGE_D = "#256229";
        public const string HOUSE = "#c9905a";
        public const string HOUSE_D = "#a06f3e";
        public const string STREET = "#9aa6ac";
        public const string STREET_D = "#7c888f";
        public const string SOIL = "#8a5a34";
        public const string SOIL_D = "#5e3d22";
        public const string LOCK = "#8b5a33";
        public const string LOCK_D = "#6b4325";
        public const string WOOD = "#b8783a";
        public const string WOOD_DARK = "#7c4a1e";
        public const string CARD = "#f7e7b4";
        public const string CARD_DARK = "#dfc38b";
        public const string GRASS_A = "#4faa33";
        public const string GRASS_B = "#58bb3a";
        public const string GRASS_BLADE = "#7fd45f";
        public const string SUN = "#f4d723";
        public const string SUN_LIGHT = "#fdefa2";
        public const string SUN_DEEP = "#f8a219";
        public const string OK = "#8ef07a";
        public const string NO = "#ff7a6b";
        public const string GOOD = "#5cc63c";
        public const string BAD = "#c8322f";
    }

    // --- определения ---------------------------------------------------------
    public sealed class ProduceDef
    {
        public int Value = 25;
        public double First = 8;
        public double Interval = 24;
    }

    public sealed class FireDef
    {
        public int Damage = 20;
        public double Interval = 1.4;
        public double First = 0.35;
    }

    public sealed class DrawOffset { public int Dx; public int Dy; }

    /// <summary>Укус на скорлупе ореха: прямоугольник в пикселях спрайта (64×64).
    /// Позиции лежат в конфиге, а не вычисляются во View, — иначе Canvas и Unity
    /// начали бы расставлять сколы по-разному и «как в оригинале» разошлось бы.</summary>
    public sealed class BiteMark
    {
        public int X, Y, W, H;
        public BiteMark(int x, int y, int w, int h) { X = x; Y = y; W = w; H = h; }
    }

    public sealed class DmgStage
    {
        public double At;
        public string Sprite;
        public string Part;
        public DmgStage(double at, string sprite, string part) { At = at; Sprite = sprite; Part = part; }
    }

    /// <summary>Вишня: стоит секунду и бабахает по площади 3×3.</summary>
    public sealed class ExplodeDef
    {
        public double Fuse = 1.1;
        public int Damage = 1800;
        public int Tiles = 1;               // радиус в клетках (1 = 3×3)
        public int Sun = 0;                 // сколько солнца вернуть при взрыве (0 = ничего)
    }

    /// <summary>Проглатывание (Чемпер): один укус = massive-урон, потом долгая жвачка.</summary>
    public sealed class ChompDef
    {
        public int Damage = 1800;           // «Massive» из альманаха: переживает и ведро
        public double Chew = 20.0;          // с, пока жуёт — в это время беззащитен
        public int Tiles = 2;               // клеток ВПЕРЕД растения (от его переднего края)
    }

    public sealed class PlantDef
    {
        public string Id;
        public string Name;
        public string Sprite;
        public int Cost;
        public int Hp;
        public ProduceDef Produce;          // null = не производит
        public FireDef Fire;                // null = не стреляет
        public ExplodeDef Explode;          // null = не взрывается
        public ChompDef Chomp;              // null = не проглатывает
        public double Cooldown = 7.5;       // перезарядка карточки после посадки, с (в оригинале 7.5)
        // стадии расколотой скорлупы (у ореха) — тот же приём, что Dmg у зомби
        public List<DmgStage> Dmg = new List<DmgStage>();
        public List<BiteMark> Bites = new List<BiteMark>();
        public UnityEngine.Vector2 Muzzle = UnityEngine.Vector2.zero;
        public DrawOffset Draw = new DrawOffset();
        public string Tip = "";
    }

    public sealed class ZombieDef
    {
        public string Id;
        public string Name;
        public string Sprite;
        public int Hp = 200;
        public double Speed = 12.8;
        public double EatDps = 100;
        public int HitW = 30;
        public int Mouth = 22;
        // броня (конус/ведро): урон сначала снимает её, тело не портится
        public int Armor = 0;
        public string ArmorSprite = "";
        public string ArmorSpriteDmg = "";
        public double ArmorAt = 0.5;              // ниже этой доли брони конус побит
        public DrawOffset Draw = new DrawOffset();
        public List<DmgStage> Dmg = new List<DmgStage>();
    }

    /// <summary>Кто может прийти на уровне: type + вес.</summary>
    public sealed class RosterEntry
    {
        public string Type = "basic";
        public int Weight = 1;
        public RosterEntry() { }
        public RosterEntry(string type, int weight) { Type = type; Weight = weight; }
    }

    public sealed class ZombieSpec
    {
        public string Type = "basic";
        public int Row = -1;                // -1 = случайная полоса
        public ZombieSpec() { }
        public ZombieSpec(string type, int row = -1) { Type = type; Row = row; }
    }

    public sealed class WaveDef
    {
        public List<ZombieSpec> Zombies = new List<ZombieSpec>();
        public double Time = 0.0;                     // волна идёт по часам
        public bool Final = false;
        public double SpawnGap = -1;                // <0 → GAME.seedGapInWave
        public int[] UnlockRows = null;
        public string Hint = null;
        public Dictionary<string, int> GatePlanted = null;   // есть в движке, в 1-1 не используется
    }

    public sealed class SkySunDef
    {
        public double First = 5;
        public double Interval = 10;
        public int Value = 25;
    }

    public sealed class LevelDef
    {
        public string Id = "1-1";
        public string Name = "Солнечная лужайка";
        public string Subtitle = "уровень 1-1";
        public int StartSun = 150;
        public List<string> Seeds = new List<string> { "sunflower", "peashooter" };
        public List<int> Rows = new List<int> { 2 };
        public SkySunDef SkySun = new SkySunDef();
        public int TotalZombies = 5;
        public List<WaveDef> Waves = new List<WaveDef>();
        // пустой roster + type="random" в волне → зомби берётся равномерно из Levels
        public List<RosterEntry> Roster = new List<RosterEntry>();
        public List<string> Rewards = new List<string>();   // что дают за победу (растения)
        public List<string> Tools = new List<string>();     // инструменты за победу (лопата) — не растения
        public string WinTip = "";
    }

    public sealed class MowerDef
    {
        public string Sprite = "assets/mowers/mower.png";
        public double Speed = 340;
        public double At = Geo.LAWN_X + 6;
        public int HitW = 54;
        public double IdleX = Geo.LAWN_X - 26;
    }

    public sealed class PeaDef
    {
        public string Sprite = "assets/fx/pea.png";
        public int Size = 14;
        public int MinSize = 14;
        public double Speed = 320;
        public double Life = 3;
    }

    public sealed class SunDef
    {
        public string Sprite = "assets/fx/sun.png";
        public int Size = 27;
        public int MinSize = 27;
        public double FallSpeed = 62;
        public double PopUp = 60;
        public double Gravity = 240;
        public double IdleTime = 9;
        public double FadeTime = 1.6;
        public double HitRadius = 24;
        public double CollectTime = 0.45;
    }

        public sealed class HudRect
    {
        public double X, Y, W, H;
        public double Gap;                                     // шаг карточек в панели (0 если не панель)
        public HudRect(double x, double y, double w, double h) { X = x; Y = y; W = w; H = h; }
        public HudRect GapBy(double g) { Gap = g; return this; }
    }

    public sealed class HudDef
    {
        public HudRect Bank = new HudRect(8, 8, 78, 66);
        public HudRect Packet = new HudRect(92, 8, 54, 66).GapBy(6);
        public double PacketGap = 6;
        public HudRect Progress = new HudRect(350, 58, 200, 12);
        public UnityEngine.Vector2 LevelText = new UnityEngine.Vector2(214, 26);
        public UnityEngine.Vector2 SunIconAt = new UnityEngine.Vector2(30, 26);
    }

    public sealed class GameDef
    {
        public double FixedStep = 1.0 / 120.0;   // именно 1.0: в C# 1/120 — целочисленное деление (ноль)
        public double MaxStepPerFrame = 0.25;
        public double LoseAtX = Geo.LAWN_X + 6;
        public double WinDelay = 1;
        public double SeedGapInWave = 3.2;
    }

    /// /// --- все данные игры в одном месте (аналог `import * as CFG`) ------------
    public static class CFG
    {
        public static readonly Dictionary<string, PlantDef> PLANTS = BuildPlants();
        public static readonly Dictionary<string, ZombieDef> ZOMBIES = BuildZombies();
        public static readonly PeaDef PEA = new PeaDef();
        public static readonly SunDef SUN = new SunDef();
        public static readonly MowerDef MOWER = new MowerDef();
        public static readonly GameDef GAME = new GameDef();
        public static readonly HudDef HUD = new HudDef();

        public static readonly List<LevelDef> LEVELS = BuildLevels();

        /// <summary>Без Unity-зависимостей: PPU/пивот решают вьюха и импортёр.</summary>
        public static PlantDef Plant(string id) { PlantDef d; return PLANTS.TryGetValue(id, out d) ? d : null; }
        public static ZombieDef Zombie(string id) { ZombieDef d; return ZOMBIES.TryGetValue(id, out d) ? d : null; }

        private static Dictionary<string, PlantDef> BuildPlants()
        {
            var sunflower = new PlantDef
            {
                Id = "sunflower",
                Name = "Подсолнух",
                Sprite = "assets/plants/sunflower.png",
                Cost = 50,
                Hp = 300,
                Produce = new ProduceDef { Value = 50, First = 8, Interval = 24 },  // у нас 50, не 25
                Tip = "даёт 50 солнца каждые 24 с",
            };
            var peashooter = new PlantDef
            {
                Id = "peashooter",
                Name = "Горохострел",
                Sprite = "assets/plants/peashooter.png",
                Cost = 100,
                Hp = 300,
                Fire = new FireDef { Damage = 20, Interval = 1.4, First = 0.35 },
                Muzzle = new UnityEngine.Vector2(58, 28),
                Tip = "стреляет по своей полосе вправо",
            };
            var cherry = new PlantDef
            {
                Id = "cherry",
                Name = "Вишня",
                Sprite = "assets/plants/cherry.png",
                Cost = 150,
                Hp = 400,
                Explode = new ExplodeDef { Fuse = 1.1, Damage = 1800, Tiles = 1 },
                Cooldown = 30,            // дорогая игрушка: в оригинале 30 секунд
                Tip = "бабахает через секунду: сносит всё в 3×3, включая конус",
            };
            // Орех — чистая стена: ни Fire, ни Produce, ни Explode. Зомби доходит до
            // него, встаёт и грызёт 4000 HP ≈ 40 с (eatDps 100), как в оригинале.
            var wallnut = new PlantDef
            {
                Id = "wallnut",
                Name = "Орех",
                Sprite = "assets/plants/wallnut.png",
                Cost = 50,
                Hp = 4000,
                Cooldown = 30,            // в оригинале перезарядка «медленная»
                // Полоски HP нет: вместо неё скорлупа бьётся. Пороги доли остатка:
                // ~2900 трещины, ~2000 откушена макушка, ~1000 орех держится наполовину.
                Dmg = new List<DmgStage> {
                    new DmgStage(0.72, "assets/plants/wallnut_dmg1.png", "shell"),
                    new DmgStage(0.5, "assets/plants/wallnut_dmg2.png", "top"),
                    new DmgStage(0.25, "assets/plants/wallnut_dmg3.png", "side"),
                },
                Bites = new List<BiteMark> {
                    new BiteMark(41, 21, 7, 4), new BiteMark(17, 11, 8, 5),
                    new BiteMark(44, 39, 6, 5), new BiteMark(23, 47, 9, 5),
                    new BiteMark(11, 29, 5, 7),
                },
                Tip = "стена: 4000 HP, не стреляет — зомби останавливается и грызёт его",
            };
            var chomper = new PlantDef
            {
                Id = "chomper",
                Name = "Чемпер",
                Sprite = "assets/plants/chomper.png",
                Cost = 150,
                Hp = 300,
                Chomp = new ChompDef { Damage = 1800, Chew = 20.0, Tiles = 2 },
                Cooldown = 7.5,             // в оригинале перезарядка карты «быстрая»
                Tip = "проглатывает зомби целиком, потом жуёт 20 с — в это время беззащитен",
            };
            return new Dictionary<string, PlantDef>
            {
                { "sunflower", sunflower }, { "peashooter", peashooter },
                { "cherry", cherry }, { "wallnut", wallnut }, { "chomper", chomper },
            };
        }

        private static Dictionary<string, ZombieDef> BuildZombies()
        {
            var basic = new ZombieDef
            {
                Id = "basic",
                Name = "Зомби",
                Sprite = "assets/zombies/basic.png",
                Hp = 200,               // = 10 горошин
                Speed = 12.8,          // 5 секунд на клетку
                EatDps = 100,          // 300 hp растения за 3 секунды
                HitW = 30,
                Mouth = 22,
                Dmg = new List<DmgStage>
                {
                    new DmgStage(0.66, "assets/zombies/basic-arm.png", "arm"),
                    new DmgStage(0.34, "assets/zombies/basic-limp.png", "leg"),
                    new DmgStage(0.12, "assets/zombies/basic-headless.png", "head"),
                },
            };
            var conehead = new ZombieDef
            {
                Id = "conehead",
                Name = "Зомби в конусе",
                Sprite = "assets/zombies/basic.png",
                Hp = 200,
                Armor = 440,                              // 200 + 440 = 640, как в оригинале
                ArmorSprite = "assets/zombies/cone.png",
                ArmorSpriteDmg = "assets/zombies/cone-dmg.png",
                Speed = 12.8,
                EatDps = 100,
                HitW = 30,
                Mouth = 22,
                Dmg = new List<DmgStage>
                {
                    new DmgStage(0.66, "assets/zombies/basic-arm.png", "arm"),
                    new DmgStage(0.34, "assets/zombies/basic-limp.png", "leg"),
                    new DmgStage(0.12, "assets/zombies/basic-headless.png", "head"),
                },
            };
            // Ведро: в оригинале 1100 против 370 у конуса (×2.97). Наш конус 440 →
            // 440 × 1100/370 ≈ 1308 → 1300. Итого с телом 1500 = 75 горошин.
            var buckethead = new ZombieDef
            {
                Id = "buckethead",
                Name = "Зомби в ведре",
                Sprite = "assets/zombies/basic.png",
                Hp = 200,
                Armor = 1300,
                ArmorSprite = "assets/zombies/bucket.png",
                ArmorSpriteDmg = "assets/zombies/bucket-dmg.png",
                ArmorAt = 0.55,                       // вмятины на 600/1100, как в оригинале
                Speed = 12.8,                          // ведро не меняет скорость
                EatDps = 100,
                HitW = 30,
                Mouth = 22,
                Dmg = new List<DmgStage>
                {
                    new DmgStage(0.66, "assets/zombies/basic-arm.png", "arm"),
                    new DmgStage(0.34, "assets/zombies/basic-limp.png", "leg"),
                    new DmgStage(0.12, "assets/zombies/basic-headless.png", "head"),
                },
            };
            return new Dictionary<string, ZombieDef>
            {
                { "basic", basic }, { "conehead", conehead }, { "buckethead", buckethead },
            };
        }

        private static List<LevelDef> BuildLevels()
        {
            // ---------------------------------------------------------- 1-1
            // В оригинале 1-1 — обучение: только горохострел, одна полоса,
            // подсолнух дают ПОСЛЕ победы (см. Rewards), вишню — за 1-2.
            var l1 = new LevelDef
            {
                Id = "1-1",
                Name = "Солнечная лужайка",
                Subtitle = "уровень 1-1",
                StartSun = 150,
                Seeds = new List<string> { "peashooter" },
                Rows = new List<int> { 2 },
                SkySun = new SkySunDef { First = 4, Interval = 9, Value = 25 },
                TotalZombies = 9,
                Rewards = new List<string> { "sunflower" },     // за 1-1 — только подсолнух
                Tools = new List<string> { "shovel" },          // и лопата: выкапывать растения
                WinTip = "ПОДСОЛНУХ ОТКРЫТ",
            };
            // Размер волны растёт лесенкой (1, 1, 2, 2, 3): зомби стало больше, но
            // они не приходят стеной сразу — первый вал по-прежнему один зомби.
            l1.Waves.Add(new WaveDef
            {
                Zombies = new List<ZombieSpec> { new ZombieSpec("basic", 2) },
                Time = 24,          // была 18: +6 с на «успеть посадить и собрать»
                Hint = "Зомби наступают — собирай солнце и ставь горохострел.",
            });
            l1.Waves.Add(new WaveDef { Zombies = new List<ZombieSpec> { new ZombieSpec("basic", 2) }, Time = 50 });
            l1.Waves.Add(new WaveDef
            {
                Zombies = new List<ZombieSpec> { new ZombieSpec("basic", 2), new ZombieSpec("basic", 2) },
                Time = 78,
            });
            l1.Waves.Add(new WaveDef
            {
                Zombies = new List<ZombieSpec> { new ZombieSpec("basic", 2), new ZombieSpec("basic", 2) },
                Time = 106,
            });
            l1.Waves.Add(new WaveDef
            {
                Zombies = new List<ZombieSpec>
                {
                    new ZombieSpec("basic", 2), new ZombieSpec("basic", 2), new ZombieSpec("basic", 2),
                },
                Time = 140,
                Final = true,
                SpawnGap = 2.4,
            });

            // ---------------------------------------------------------- 1-2
            // Три полосы, 20 зомби, среди них конуноголовые. Состав каждой волны
            // не прописан вручную, а тянется из Roster'а случайным образом —
            // каждый запуск (и каждая перезагрузка R) выглядят по-разному.
            var l2 = new LevelDef
            {
                Id = "1-2",
                Name = "Соседний газон",
                Subtitle = "уровень 1-2",
                StartSun = 100,
                Seeds = new List<string> { "peashooter", "sunflower", "cherry" },
                Rows = new List<int> { 1, 2, 3 },
                SkySun = new SkySunDef { First = 4, Interval = 9, Value = 25 },
                TotalZombies = 21,
                Roster = new List<RosterEntry> { new RosterEntry("basic", 3), new RosterEntry("conehead", 1) },
                Rewards = new List<string> { "cherry" },       // вишня — награда за 1-2
                WinTip = "ГАЗОН ЧИСТ · ВИШНЯ ОТКРЫТА",
            };
            l2.Waves.Add(new WaveDef
            {
                Zombies = Any(1),
                Time = 26,
                Hint = "Три полосы и конуноголовые: конус сносится первым, не жалей гороха.",
            });
            l2.Waves.Add(new WaveDef { Zombies = Any(2), Time = 54 });
            l2.Waves.Add(new WaveDef { Zombies = Any(3), Time = 84 });
            l2.Waves.Add(new WaveDef { Zombies = Any(4), Time = 116, Hint = "Их всё больше — вишня — на крайний случай." });
            l2.Waves.Add(new WaveDef { Zombies = Any(5), Time = 152 });
            l2.Waves.Add(new WaveDef { Zombies = Any(6), Time = 192, Final = true, SpawnGap = 2.4 });

            // ---------------------------------------------------------- 1-3
            // «Большой газон»: ПЯТЬ полос открыты с первой секунды (без волн-разблокировок,
            // в отличие от 1-2), впервые выходят ведроголовые. Орех — награда за уровень,
            // поэтому в пачке его нет: полосу пока держим горохом и вишней.
            var l3 = new LevelDef
            {
                Id = "1-3",
                Name = "Большой газон",
                Subtitle = "уровень 1-3",
                StartSun = 100,
                // орех перечислен в пачке, но открывается только наградой: World
                // строит Seeds ∩ Progress.Plants() (тот же приём, что с вишней на 1-2)
                Seeds = new List<string> { "peashooter", "sunflower", "cherry", "wallnut" },
                Rows = new List<int> { 0, 1, 2, 3, 4 },
                SkySun = new SkySunDef { First = 4, Interval = 9, Value = 25 },
                TotalZombies = 28,
                Roster = new List<RosterEntry>
                {
                    new RosterEntry("basic", 3), new RosterEntry("conehead", 2), new RosterEntry("buckethead", 1),
                },
                Rewards = new List<string> { "wallnut" },        // орех — за 1-3
                WinTip = "ОРЁХ ОТКРЫТ",
            };
            // Подготовка самая длинная из всех: пять полос надо засеять до первого
            // вала — 44 с (подсолнух успевает отдать два сбора, небо роняет солнце
            // пять раз). Дальше размер волны растёт лесенкой 1→2→3→5→7→10, финал
            // на 198 с, зазоры 28…34 с — зомби больше, но не все сразу.
            l3.Waves.Add(new WaveDef
            {
                Zombies = Any(1), Time = 44,
                Hint = "Пять полос с самого начала. Ведро держит 1300 — сбивай его, не жалей гороха.",
            });
            l3.Waves.Add(new WaveDef { Zombies = Any(2), Time = 72 });
            l3.Waves.Add(new WaveDef { Zombies = Any(3), Time = 100, Hint = "За уровнем откроется орех: пока просто тяни время горохом." });
            l3.Waves.Add(new WaveDef { Zombies = Any(5), Time = 130 });
            l3.Waves.Add(new WaveDef { Zombies = Any(7), Time = 164 });
            l3.Waves.Add(new WaveDef { Zombies = Any(10), Time = 198, Final = true, SpawnGap = 2.6,
                                      Hint = "Последняя волна — держи центр." });

            // ---------------------------------------------------------- 1-4
            // «Хищная лужайка»: уровень, за который отдают ЧЕМПЕР. Полос пять, брони
            // больше (конус и ведро чаще), чемпера в пачке первым прохождением нет —
            // он в Seeds только как будущая награда (World фильтрует по открытому).
            var l4 = new LevelDef
            {
                Id = "1-4",
                Name = "Хищная лужайка",
                Subtitle = "уровень 1-4",
                StartSun = 100,
                Seeds = new List<string> { "peashooter", "sunflower", "cherry", "wallnut", "chomper" },
                Rows = new List<int> { 0, 1, 2, 3, 4 },
                SkySun = new SkySunDef { First = 4, Interval = 9, Value = 25 },
                TotalZombies = 32,
                Roster = new List<RosterEntry>
                {
                    new RosterEntry("basic", 3), new RosterEntry("conehead", 3), new RosterEntry("buckethead", 2),
                },
                Rewards = new List<string> { "chomper" },       // чемпер — за 1-4
                WinTip = "ЧЕМПЕР ОТКРЫТ",
            };
            l4.Waves.Add(new WaveDef
            {
                Zombies = Any(1), Time = 40,
                Hint = "Здесь много брони. Через уровень появится чемпер — он глотает любого целиком.",
            });
            l4.Waves.Add(new WaveDef { Zombies = Any(2), Time = 70 });
            l4.Waves.Add(new WaveDef { Zombies = Any(4), Time = 100 });
            l4.Waves.Add(new WaveDef { Zombies = Any(6), Time = 134, Hint = "Орех держит полосу, чемпер работает по одному — не ставь его впритык к краю." });
            l4.Waves.Add(new WaveDef { Zombies = Any(8), Time = 168 });
            l4.Waves.Add(new WaveDef { Zombies = Any(11), Time = 206, Final = true, SpawnGap = 2.8,
                                      Hint = "Последний вал: держи чемперов наготове, жуём они долго." });
            return new List<LevelDef> { l1, l2, l3, l4 };
        }

        /// <summary>n штук «кто попало»: тип и полосу выбирает мир из Roster'а.</summary>
        private static List<ZombieSpec> Any(int n)
        {
            var list = new List<ZombieSpec>();
            for (int i = 0; i < n; i++) list.Add(new ZombieSpec("random", -1));
            return list;
        }
    }
}
