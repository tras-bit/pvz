// ============================================================================
//  GAME ROOT — точка входа в Unity: цикл с фиксированным шагом, ввод мышью,
//  экраны (заголовок → меню режима → игра), события мира → звук/частицы.
//
//  Это перенос js/game.js + js/main.js. Логика игры при этом живёт в
//  Pvz.Core.World ( Assets/Scripts/Core ) и не знает про Unity вообще.
// ============================================================================
using System.Collections.Generic;
using UnityEngine;
using Pvz.Core;

namespace Pvz.View
{
    [DefaultExecutionOrder(-10)]
    public sealed class GameRoot : MonoBehaviour
    {
        public static GameRoot Instance { get; private set; }

        public int LevelIndex = 0;
        public bool PixelPerfect = true;
        public bool StartInMenu = true;              // false → сразу заголовок, как в вебе
        public KeyCode KeyPause = KeyCode.P;
        public KeyCode KeyRestart = KeyCode.R;
        public KeyCode KeyRecharge = KeyCode.C;         // чит: мгновенная перезарядка карточек
        public KeyCode KeyShovel = KeyCode.X;           // лопата: взять в руку / убрать
        public KeyCode KeyMute = KeyCode.M;

        private World _world;
        private SpriteLib _lib;
        private WorldViews _views;
        private FxView _fx;
        private AudioBank _sfx;
        private Camera _cam;
        private Transform _root;

        private TexLayer _bg, _hud, _tip, _toast, _overlay, _hint;
        private QuadPool _quads;
        private readonly UiState _ui = new UiState();

        private enum Scr { Title, Menu, Adventure, Play }
        private Scr _scr = Scr.Title;
        private bool _paused;
        private int _menuHover = -1;
        private int _adSel = -1;               // выбранный узел на экране «выбор уровня» (-1 = ещё не трогали)
        private double _acc;
        private float _clock;
        private string _toastText; private float _toastT = 99f; private bool _toastFinal;

        // -1 — не использовать как «нужно перепечь»: у hash'ей бывает значение -1
        // (например, на экране Title ovHash = 0*4 + 0 + 0 - 1 = -1 → панель не появилась).
        private const int Dirty = int.MinValue;
        private int _hudHash = Dirty, _bgHash = Dirty, _overlayHash = Dirty, _tipHash = Dirty;
        private const int Off = -4000000;      // «панель спрятана» (не в экране Play)
        private bool _running;

        // ------------------------------------------------------------------ жизнь
        private void Awake()
        {
            Instance = this;
            _lib = SpriteLib.Load();
            _sfx = gameObject.AddComponent<AudioBank>();
            _fx = new FxView(_lib);
            BuildScene();
            NewWorld();
            _scr = StartInMenu ? Scr.Menu : Scr.Title;   // true → сразу меню, как в PvZ
            _running = true;
        }

        private void OnDestroy() { if (_bg != null && _bg.Tex != null) _bg.Tex.Dispose(); }

        private void BuildScene()
        {
            _cam = Camera.main;
            if (_cam == null)
            {
                var go = new GameObject("Main Camera") { tag = "MainCamera" };
                _cam = go.AddComponent<Camera>();
            }
            // Без AudioListener в сцене Unity пишет «There are no audio listeners in the
            // scene available to receive this audio clip» и молчит. Камеру мы создаём сами,
            // значит и слушателя вешаем сами (если сцену Someone собрал вручную — не дублируем).
            if (Object.FindObjectOfType<AudioListener>() == null) _cam.gameObject.AddComponent<AudioListener>();
            _cam.orthographic = true;
            _cam.clearFlags = CameraClearFlags.SolidColor;
            _cam.backgroundColor = new Color(0.06f, 0.10f, 0.06f, 1f);

            var rootGo = new GameObject("Pvz");
            _root = rootGo.transform;

            var lawn = new Layer("lawn", Sort.Lawn, _root, -20);
            _bg = new TexLayer("bg", lawn);
            _views = new WorldViews(_lib, _root);
            _quads = new QuadPool(_views.Pixel, _root, Sort.Fx, 10);

            var hud = new Layer("hud", Sort.Hud, _root);
            _hud = new TexLayer("hud", hud);
            var ov = new Layer("overlay", Sort.Overlay, _root);
            _overlay = new TexLayer("overlay", ov);
            _toast = new TexLayer("toast", ov, 5);
            _tip = new TexLayer("tooltip", ov, 6);
            _hint = new TexLayer("hint", ov, 7);
        }

        private void NewWorld()
        {
            var level = CFG.LEVELS[Mathf.Clamp(LevelIndex, 0, CFG.LEVELS.Count - 1)];
            _world = new World(level, (uint)(System.Environment.TickCount & 0x7fffffff), Progress.Plants());
            _fx.Clear();
            _ui.Selected = null;
            _ui.DragActive = false;
            _bgHash = _hudHash = _overlayHash = _tipHash = Dirty;
            _paused = false;
        }

        // --------------------------------------------------------------- доступ
        public World World { get { return _world; } }
        public SpriteLib Lib { get { return _lib; } }
        public UiState Ui { get { return _ui; } }
        public void GiveSun(int v) { _world.AddSun(v); }
        public void Restart() { NewWorld(); _scr = Scr.Play; _ui.Shovel = false; Say("ЗАНОВО"); }

        // --- лопата (награда за 1-1): взял в руку → кликнул своё растение → выкопано.
        // Солнце не возвращается, как в оригинале; состояние живёт в _ui, чтобы HUD
        // и ввод смотрели в один флаг (два флага = рассинхрон, как с кнопкой победы).
        public bool ShovelArmed { get { return _ui.Shovel; } }

        public void ToggleShovel()
        {
            _ui.Shovel = !_ui.Shovel;
            if (_ui.Shovel) _ui.Selected = null;         // в руке или лопата, не оба сразу
            _sfx.Play(_ui.Shovel ? "plant" : "collect", 0.7f);
            Say(_ui.Shovel ? "ЛОПАТА: КЛИКНИ СВОЁ РАСТЕНИЕ" : "ЛОПАТА УБРАНА");
            _overlayHash = Dirty;
        }

        private void DigAt(Vector2 p)
        {
            var dug = _world.Dig(Geo.RowAt(p.y), Geo.ColAt(p.x));
            _ui.Shovel = false;
            _ui.MouseDown = true;                          // этот клик не должен ещё и семя посадить
            if (dug == null)
            {
                _sfx.Play("error", 0.6f);
                Say("ТУТ НЕЧЕГО КОПАТЬ");
            }
            else
            {
                _sfx.Play("chomp", 0.8f);
                var def = CFG.Plant(dug.Type);
                Say("ВЫКОПАНО: " + (def != null ? def.Name.ToUpperInvariant() : "ГРЯЗЬ"));
            }
            _overlayHash = Dirty;
        }

        /// <summary>Клик по экрану победы/поражения. По кнопке «ДАЛЬШЕ» — переход на
        /// следующий уровень, в любое другое место — «заново». Раньше здесь всегда был
        /// Restart, и кнопка, на которой написано «ENTER — 1-2», при клике по ней
        /// перезапускала текущий уровень.</summary>
        private void FinishedClick(Vector2 p)
        {
            if (_world.State == WorldState.Won && Paint.WinHasNext(_world) && Paint.WinButtonRect(_world).Contains(p))
            {
                NextLevel();
                return;
            }
            Restart();
        }

        /// <summary>Следующий уровень, если он уже открыт (проигрывается на Enter после победы).</summary>
        public void NextLevel()
        {
            int next = LevelIndex + 1;
            if (next >= CFG.LEVELS.Count || !Progress.LevelOpen(next))
            {
                _sfx.Play("error", 0.7f);
                Say("ДАЛЬШЕ УРОВНЕЙ НЕТ");
                return;
            }
            LevelIndex = next;
            NewWorld();
            _ui.Shovel = false;
            _scr = Scr.Play;
            Say("УРОВЕНЬ " + CFG.LEVELS[next].Id + ": " + CFG.LEVELS[next].Name.ToUpperInvariant());
        }
        public void ToMenu() { _scr = Scr.Menu; _paused = false; _ui.Shovel = false; _overlayHash = Dirty; }

        private void Update()
        {
            if (!_running) return;
            double dt = Time.deltaTime;
            if (dt > CFG.GAME.MaxStepPerFrame) dt = CFG.GAME.MaxStepPerFrame;
            _clock += (float)dt;
            _ui.Clock = _clock;

            ReadMouse();
            ReadKeys();

            bool sim = _scr == Scr.Play && !_paused;
            if (sim)
            {
                _acc += dt;
                int guard = 0;
                while (_acc >= CFG.GAME.FixedStep && guard++ < 400)
                {
                    _acc -= CFG.GAME.FixedStep;
                    _world.Bank = new Vector2((float)(CFG.HUD.Bank.X + 20), (float)(CFG.HUD.Bank.Y + 20));
                    _world.Update(CFG.GAME.FixedStep);
                    HandleEvents();
                }
            }
            _fx.Update(dt);
            if (_toastT < 3.4f) { _toastT += (float)dt; if (_toastT > 3.4f) _toastText = null; }

            RebuildUi();
            Fit();
        }

        // ---------------------------------------------------------------- ввод
        private void ReadMouse()
        {
            Vector2 p = LogicalMouse();
            _ui.HasMouse = true;
            _ui.MouseX = p.x; _ui.MouseY = p.y;
            _ui.HoverRow = Geo.RowAt(p.y);
            _ui.HoverCol = Geo.ColAt(p.x);
            _ui.HoverValid = Geo.InLawn(_ui.HoverRow, _ui.HoverCol);

            if (_scr == Scr.Menu || _scr == Scr.Adventure)
            {
                int n = _scr == Scr.Menu ? MenuLayout.Modes.Length : AdventureLayout.Count;
                int hover = -1;
                for (int i = 0; i < n; i++)
                {
                    var r = _scr == Scr.Menu ? MenuLayout.Card(i) : AdventureLayout.Node(i);
                    if (r.Contains(p)) hover = i;
                }
                if (hover != _menuHover)
                {
                    _menuHover = hover;
                    _overlayHash = Dirty;
                    if (hover >= 0) _sfx.Play("sunDrop", 0.35f);
                    // на экране выбора уровня наведение = выбор (как рамка в оригинале).
                    // ТОЛЬКО на смену наведения: иначе мышь, оставшаяся на узле, каждый
                    // кадр возвращала бы рамку и стрелки «боролась» с ней.
                    if (_scr == Scr.Adventure && hover >= 0) _adSel = hover;
                }
            }

            if (Input.GetMouseButtonDown(1))
            {
                CancelDrag();
                _ui.Selected = null;
                return;
            }

            if (Input.GetMouseButtonDown(0))
            {
                _sfx.Play("sunDrop", 0.0f);                 // разблокировать микшер по клику
                OnDown(p);
            }
            if (Input.GetMouseButtonUp(0)) OnUp(p);

            if (_ui.DragActive)
            {
                var d = _ui.DragDown;
                if (Mathf.Abs(p.x - d.x) > 2f || Mathf.Abs(p.y - d.y) > 2f) _ui.DragMoved = true;
            }
        }

        private Vector2 LogicalMouse()
        {
            Vector3 wp = _cam.ScreenToWorldPoint(Input.mousePosition);
            return new Vector2(wp.x, -wp.y);                 // y у нас вниз (как в canvas)
        }

        private void OnDown(Vector2 p)
        {
            if (_scr == Scr.Title) { _scr = Scr.Menu; _overlayHash = Dirty; return; }
            if (_scr == Scr.Menu) { MenuClick(p); return; }
            if (_scr == Scr.Adventure) { AdventureClick(p); return; }
            if (_world.State != WorldState.Playing) { FinishedClick(p); return; }
            if (_paused) return;

            // лопата первее карточек: пока она в руке, посадка невозможна (в оригинале
            // то же самое — лопата перехватывает клик по газону)
            if (Progress.HasTool("shovel"))
            {
                if (Paint.ShovelRect(_world.Seeds.Count).Contains(p)) { ToggleShovel(); return; }
                if (_ui.Shovel) { DigAt(p); return; }
            }

            string card = CardAt(p);
            if (card != null)
            {
                // карточка на перезарядке — её не взять (как в оригинале: серая и некликабельная)
                double cd = _world.CooldownLeft(card);
                if (cd > 0)
                {
                    _sfx.Play("error", 0.6f);
                    Say(CFG.Plant(card).Name.ToUpperInvariant() + ": ПЕРЕЗАРЯДКА " + cd.ToString("0.0") + " С", true);
                    _ui.MouseDown = true;
                    return;
                }
                _ui.DragActive = true;
                _ui.DragMoved = false;
                _ui.DragType = card;
                _ui.DragDown = p;
                _ui.Selected = card;
                _sfx.Play("sunDrop", 0.45f);
            }
            _ui.MouseDown = true;
        }

        private void OnUp(Vector2 p)
        {
            _ui.MouseDown = false;
            if (_scr != Scr.Play) return;
            if (!_ui.DragActive) { Click(p); return; }
            _ui.DragActive = false;
            if (!_ui.DragMoved)
            {
                // «тап по карточке» больше не сажает: семя берётся только перетаскиванием
                _ui.Selected = null;
                _sfx.Play("error", 0.5f);
                Say("КАРТОЧКУ НУЖНО ПЕРЕТАЩИТЬ НА ГАЗОН");
                return;
            }
            if (!_ui.HoverValid || _world.CanPlant(_ui.HoverRow, _ui.HoverCol, _ui.DragType) != Fail.None)
            {
                CancelDrag(true);
                return;
            }
            PlantAt(p.x, p.y, _ui.DragType);
        }

        private void Click(Vector2 p)
        {
            if (_paused) return;
            if (_ui.Shovel) return;                        // клик уже отработан лопатой
            // тот же путь, что и в OnDown: иначе «отпустил» на экране победы тащит Restart
            if (_world.State != WorldState.Playing) { FinishedClick(p); return; }
            _world.PickSun(p.x, p.y);       // солнце — по клику; садим только перетаскиванием
        }

        /// <summary>Главное меню: «ПРИКЛЮЧЕНИЕ» ведёт на выбор уровня, «МУЛЬТИПЛЕЕР» —
        /// заглушка. Номера уровней из меню убраны специально: их два, и прятать их в
        /// ряд кнопок «1-1 / 1-2» выглядело как ярлык, а не как режим.</summary>
        private void MenuClick(Vector2 p)
        {
            for (int i = 0; i < MenuLayout.Modes.Length; i++)
            {
                if (!MenuLayout.Card(i).Contains(p)) continue;
                if (!MenuLayout.IsOpen(i))
                {
                    _sfx.Play("error", 0.7f);
                    Say(MenuLayout.Modes[i].Title + " ЕЩЁ НЕ СОБРАН", true);
                    return;
                }
                OpenAdventure();
                return;
            }
        }

        private void OpenAdventure()
        {
            _scr = Scr.Adventure;
            _adSel = -1;
            _menuHover = -1;
            _overlayHash = Dirty;
            _sfx.Play("sunDrop", 0.5f);
            Say("ВЫБЕРИ УРОВЕНЬ · ENTER — В БОЙ");
        }

        /// <summary>Экран выбора уровня: узел открыт → стартуем, заперт → говорим, что
        /// пройти сначала, и всё равно ставим на него рамку (видно замок и подпись).</summary>
        private void AdventureClick(Vector2 p)
        {
            for (int i = 0; i < AdventureLayout.Count; i++)
            {
                if (!AdventureLayout.Node(i).Contains(p)) continue;
                _adSel = i;
                _overlayHash = Dirty;
                StartAdventureLevel(i);
                return;
            }
        }

        private void StartAdventureLevel(int i)
        {
            if (!AdventureLayout.IsOpen(i))
            {
                _sfx.Play("error", 0.7f);
                Say("СНАЧАЛА ПРОЙДИ " + CFG.LEVELS[i - 1].Id, true);
                return;
            }
            StartLevel(i);
        }

        /// <summary>Запуск уровня i (один путь и для меню, и для Enter на экране победы).</summary>
        private void StartLevel(int i)
        {
            LevelIndex = i;
            _sfx.Play("plant", 0.8f);
            NewWorld();
            _scr = Scr.Play;
            _paused = false;
            _overlayHash = Dirty;
            Say(i == 0 ? "СОБЕРИ СОЛНЦЕ И ПОСАДИ ГОРОХОСТРЕЛ" : "ПОЛОСЫ ПО ОТКРЫТИЮ · КОНУС ДЕРЖИТ УДАР ПЕРВЫМ");
        }

        private string CardAt(Vector2 p)
        {
            var pk = CFG.HUD.Packet;
            for (int i = 0; i < _world.Seeds.Count; i++)
            {
                float x = (float)(pk.X + i * (pk.W + pk.Gap));
                var r = new Rect(x, (float)pk.Y - (_ui.Selected == _world.Seeds[i] ? 3f : 0f), (float)pk.W, (float)pk.H);
                if (r.Contains(p)) return _world.Seeds[i];
            }
            return null;
        }

        private void CancelDrag(bool snapBack = false)
        {
            _ui.DragActive = false;
            _ui.DragMoved = false;
            _ui.Selected = null;
            if (snapBack) _sfx.Play("error", 0.45f);
        }

        private bool PlantAt(float x, float y, string type)
        {
            if (type == null) return false;
            int row = Geo.RowAt(y), col = Geo.ColAt(x);
            if (!Geo.InLawn(row, col)) { _ui.Selected = null; return false; }
            Fail fail;
            var p = _world.Place(row, col, type, out fail);
            if (p != null)
            {
                _ui.Selected = null;
                _fx.SoilPuff(p.Cx, p.Y + Geo.TILE - 8);
                _sfx.Play("plant");
                int sunflowers;
                _world.PlantedCount.TryGetValue("sunflower", out sunflowers);
                if (sunflowers == 0) Say("ПОДСОЛНУХ = ДЕНЬГИ. ПОСАДИ ЕГО ПЕРВЫМ ДЕЛОМ");
                return true;
            }
            _sfx.Play("error");
            Say(ReasonText(fail), true);
            return false;
        }

        private static string ReasonText(Fail f)
        {
            switch (f)
            {
                case Fail.Locked: return "ПОЛОСА ЗАКРЫТА";
                case Fail.Occupied: return "КЛЕТКА ЗАНЯТА";
                case Fail.NoSun: return "МАЛО СОЛНЦА";
                case Fail.Cool: return "КАРТОЧКА ЕЩЁ НЕ ЗАРЯЖЕНА";
                case Fail.Out: return "МИМО ГАЗОНА";
                case Fail.Idle: return "НЕ СЕЙЧАС";
                default: return "НЕ ПОЛУЧАЕТСЯ";
            }
        }

        /// <summary>Узел, на котором стоит рамка: выбранный руками или последний
        /// открытый (то есть «продолжить с того места, где остановился»).</summary>
        private int AdventureSel()
        {
            if (_adSel >= 0) return _adSel;
            int last = 0;
            for (int i = 0; i < AdventureLayout.Count; i++) if (AdventureLayout.IsOpen(i)) last = i;
            return last;
        }

        private static int ClampSel(int i, int n) { return i < 0 ? n - 1 : (i >= n ? 0 : i); }

        private void ReadKeys()
        {
            if (Input.GetKeyDown(KeyMute)) Say(_sfx.ToggleMute() ? "ЗВУК ВЫКЛЮЧЕН" : "ЗВУК ВКЛЮЧЁН");
            if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter))
            {
                if (_scr == Scr.Title) { _scr = Scr.Menu; _overlayHash = Dirty; }
                else if (_scr == Scr.Menu) OpenAdventure();
                else if (_scr == Scr.Adventure) StartAdventureLevel(AdventureSel());
                else if (_world.State == WorldState.Won) NextLevel();
            }
            if (_scr == Scr.Adventure)
            {
                int dir = 0;
                // карта двухмерная, но порядок линейный: ←/↓ назад по дороге, →/↑ вперёд
                if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A) ||
                    Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) dir = -1;
                if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D) ||
                    Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W)) dir = 1;
                if (dir != 0)
                {
                    int n = AdventureLayout.Count;
                    int i = ClampSel(AdventureSel() + dir, n);
                    if (i != _adSel) { _adSel = i; _overlayHash = Dirty; _sfx.Play("sunDrop", 0.35f); }
                }
            }
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                // во время боя Esc сначала бросает семя, и только на паузе или на
                // финальном экране уводит в меню (кнопка «ESC В МЕНЮ» на победе была
                // недостижима: return случался раньше)
                if (_scr == Scr.Play)
                {
                    CancelDrag();
                    _ui.Selected = null;
                    _ui.Shovel = false;                    // Esc сначала роняет лопату
                    if (!_paused && _world.State == WorldState.Playing) return;
                }
                if (_scr == Scr.Adventure) { _scr = Scr.Menu; _overlayHash = Dirty; return; }
                if (_scr == Scr.Menu) { _scr = Scr.Title; _overlayHash = Dirty; return; }
                if (_scr == Scr.Play) ToMenu();
                _paused = false;
                _overlayHash = Dirty;
            }
            if (Input.GetKeyDown(KeyPause))
            {
                if (_scr == Scr.Title || _world.State != WorldState.Playing) return;
                _paused = !_paused;
                _overlayHash = Dirty;
            }
            if (Input.GetKeyDown(KeyRestart)) Restart();
            // 1/2/3 раньше «брали» семя в руку, теперь сажаем только перетаскиванием —
            // номера с карточек убраны, а вместо них осталась одна чит-клавиша.
            // X — лопата: как в оригинале, инструмент берётся в руку и перехватывает
            // клик по газону; на паузе и на финальных экранах не срабатывает
            if (Input.GetKeyDown(KeyShovel) && !_paused && _world.State == WorldState.Playing &&
                Progress.HasTool("shovel"))
                ToggleShovel();

            if (Input.GetKeyDown(KeyRecharge))
            {
                _world.RechargeAll();
                _sfx.Play("collect", 0.6f);
                Say("ЧИТ: ВСЕ КАРТОЧКИ ЗАРЯЖЕНЫ");
            }
        }

        private void Say(string text, bool bad = false)
        {
            _toastText = text; _toastT = 0f; _toastFinal = bad;
        }

        // -------------------------------------------------- события мира → fx/звук
        private void HandleEvents()
        {
            var evs = _world.DrainEvents();
            for (int i = 0; i < evs.Count; i++)
            {
                var e = evs[i];
                switch (e.Kind)
                {
                    case EvKind.SunSpawn: _sfx.Play("sunDrop", e.Type == "plant" ? 0.6f : 0.3f); break;
                    case EvKind.SunGrab: _sfx.Play("collect", 0.7f); break;
                    case EvKind.SunBanked:
                        _fx.Text(_world.Bank.x + 46, _world.Bank.y + 8, "+" + e.Value, Pal.C("#ffd94a"), -14f);
                        break;
                    case EvKind.Shoot:
                        _sfx.Play("shoot", 0.5f);
                        _fx.HitSpark(e.Pea.X, e.Pea.Y, Pal.C("#9fe86a"));
                        break;
                    case EvKind.PeaHit:
                        _sfx.Play("hit", 0.6f);
                        _fx.HitSpark(e.Zombie.X - 14, e.Pea.Y, Pal.C("#e8f7a0"));
                        break;
                    case EvKind.ZombieDie:
                    {
                        _sfx.Play("die");
                        var z = e.Zombie;
                        if (z.Stage < 3)
                        {
                            _fx.Limb(z.X - 6, z.FootY - 56, Pal.C("#93a281"), 16, 13, z.FootY - 3, -120f, -170f);
                            _fx.Limb(z.X - 14, z.FootY - 32, Pal.C("#b0bf9a"), 9, 5, z.FootY - 3, -60f, -120f);
                        }
                        _fx.Poof(z.X, z.Y + 34, 16);
                        _fx.Poof(z.X - 12, z.Y + 44, 11, Pal.C("#d8d2c0"));
                        _fx.Burst(z.X, z.Y + 40, Pal.C("#b7c4a0"), 5, 96f, 6f);
                        _fx.Shake = 0.12f;
                        break;
                    }
                    case EvKind.ZombieLimb:
                    {
                        var z = e.Zombie;
                        string part = e.Part;
                        double y = z.FootY - (part == "head" ? 56 : part == "leg" ? 12 : 34);
                        var col = Pal.C(part == "leg" ? "#37529e" : part == "head" ? "#93a281" : "#b0bf9a");
                        _fx.Limb(z.X - 10, y, col, part == "head" ? 16 : part == "leg" ? 8 : 10,
                                 part == "head" ? 13 : part == "leg" ? 6 : 5, z.FootY - 3,
                                 -60f - (float)_world.Rng.Next() * 70f, part == "head" ? -110f : -150f);
                        _fx.Poof(z.X - 10, y, part == "head" ? 14 : 9, Pal.C("#e6ded0"));
                        _fx.Burst(z.X - 10, y, Pal.C("#c8322f"), part == "head" ? 6 : 4, 96f, 4f);
                        _sfx.Play(part == "head" ? "die" : "hit", 0.75f);
                        if (part == "head") _fx.Shake = 0.16f;
                        break;
                    }
                    case EvKind.MowerStart:
                        _sfx.Play("mower");
                        _fx.Burst(e.Mower.X + 12, e.Mower.GroundY - 14, Pal.C("#7fd45f"), 9, 130f, 3f);
                        Say("КОСИЛКА ПОЕХАЛА! ПОЛОСА СПАСЕНА — НО ТОЛЬКО В ЭТОТ РАЗ");
                        break;
                    case EvKind.ZombieMowed:
                        _sfx.Play("hit", 0.85f);
                        _fx.Burst(e.Zombie.X, e.Zombie.FootY - 26, Pal.C("#b7c4a0"), 8, 160f, 5f);
                        _fx.Burst(e.Zombie.X, e.Zombie.FootY - 42, Pal.C("#c8322f"), 6, 140f, 4f);
                        _fx.Shake = 0.1f;
                        break;
                    case EvKind.PlantEaten:
                        _sfx.Play("chomp");
                        _fx.Burst(e.Plant.Cx, e.Plant.Y + 30, Pal.C("#3fbf4a"), 8, 70f, 4f);
                        _fx.Shake = 0.1f;
                        break;
                    case EvKind.PlantCrack:
                        // новый укус ореха: щепки скорлупы + маленький осколок потемнее
                        _sfx.Play("chomp", 0.5f);
                        _fx.Burst(e.X, e.Y, Pal.C("#b8912f"), 6, 70f, 3f);
                        _fx.Burst(e.X, e.Y, Pal.C("#151113"), 3, 55f, 2f);
                        break;
                    case EvKind.RowsUnlock:
                        _sfx.Play("wave", 0.6f);
                        Say("ОТКРЫТЫ ПОЛОСЫ: " + string.Join(", ", RowsToStrings(e.Rows)));
                        _bgHash = -1;
                        break;
                    case EvKind.Wave:
                        _sfx.Play("wave");
                        Say(e.Final ? "ПОСЛЕДНЯЯ ВОЛНА" : (e.Hint != null ? e.Hint.ToUpperInvariant() : "ЗОМБИ ИДУТ..."), e.Final);
                        break;
                    case EvKind.Win:
                        _sfx.Play("win");
                        // награды уровня (Подсолнух/Вишня) выдаются здесь, а не «всегда есть»
                        if (Progress.Won(LevelIndex, _world.Level))
                        {
                            string got = Progress.RewardNames(_world.Level);
                            string tools = Progress.ToolNames(_world.Level);
                            if (tools.Length > 0) got = got.Length > 0 ? (got + " · " + tools) : tools;
                            if (got.Length > 0) Say("ПОЛУЧЕНО: " + got);
                        }
                        _overlayHash = Dirty;
                        break;
                    case EvKind.Chomp:
                        _sfx.Play("chomp", 0.9f);
                        _fx.Burst(e.X, e.Y, Pal.C("#93a281"), 10, 80f, 3f, 260f);   // цвет кожи зомби
                        _fx.Text((float)e.X, (float)e.Y - 26, "СЖУЮ!", Pal.C(Pal.SUN));
                        _overlayHash = Dirty;
                        break;
                    case EvKind.Dig:
                        _fx.SoilPuff(e.X, e.Y + Geo.TILE / 2.0);
                        break;
                    case EvKind.Explode:
                        _sfx.Play("boom");
                        _fx.Boom(e.X, e.Y, Geo.TILE * 1.5);
                        if (e.Count > 0) Say("ВЗРЫВ: СНЕСЕНО " + e.Count, e.Final);
                        break;
                    case EvKind.ArmorLost:
                        _sfx.Play("hit", 0.8f);
                        _fx.Limb(e.X, e.Y, Pal.C(Pal.WOOD), 12f, 8f, e.Y + 40, -120f, -150f, 0.8f);
                        _fx.Poof(e.X, e.Y, 12, Pal.C(Pal.SUN));
                        break;
                    case EvKind.Lose: _sfx.Play("lose"); _fx.Shake = 0.35f; _overlayHash = Dirty; break;
                }
            }
        }

        private static string[] RowsToStrings(List<int> rows)
        {
            if (rows == null) return new string[0];
            var s = new string[rows.Count];
            for (int i = 0; i < rows.Count; i++) s[i] = (rows[i] + 1).ToString();
            return s;
        }

        // ------------------------------------------------------------- отрисовка
        private void RebuildUi()
        {
            // фон/газон — только когда состав полос изменился
            int bgHash = 0;
            foreach (int r in _world.UnlockedRows) bgHash += 1 << r;
            if (bgHash != _bgHash)
            {
                _bgHash = bgHash;
                _bg.Ensure(Geo.VIEW_W, Geo.VIEW_H);
                _bg.Tex.Clear(Pal.C(Pal.SKY));
                Paint.Backdrop(_bg.Tex, _world, _lib);
                _bg.Present();
            }

            // HUD — по изменению «видимых» чисел, не каждый кадр
            if (_scr != Scr.Play)
            {
                // на заголовке и в меню панель семян мешается: гасим её (и тултип)
                if (_hudHash != Off) { _hud.Hide(); _tip.Hide(); _hudHash = Off; _tipHash = Off; }
            }
            int hash = 0;
            unchecked
            {
                hash = _world.SunCount * 7 + _world.WaveIndex * 131 + _world.KilledZombies * 1009;
                if (_ui != null && _ui.Shovel) hash += 17;                 // подсветка слота
                if (Progress.HasTool("shovel")) hash += 3;                 // слот появился
                hash ^= (_ui.Selected != null ? 8191 : 0) + (_ui.HoveredCard != null ? 131071 : 0);
                hash ^= (_ui.DragActive && _ui.DragMoved ? 32749 : 0) + (_world.UnlockedRows.Count << 3);
                for (int i = 0; i < _world.Seeds.Count; i++) hash += (int)(_world.CooldownLeft(_world.Seeds[i]) * 4);
                                     // 4 обновления в секунду, иначе «тень» перезарядки замерла бы
            }
            if (hash != _hudHash)
            {
                _hudHash = hash;
                _hud.Ensure(Geo.VIEW_W, Geo.LAWN_Y);
                Paint.Hud(_hud.Tex, _world, _ui, _lib);
                _hud.Present();
            }

            // тултип карточки
            _ui.HoveredCard = HoverCard();
            int tipHash = _ui.HoveredCard == null ? 0 : _ui.HoveredCard.GetHashCode() * 31 + _world.SunCount;
            if (tipHash != _tipHash && _scr == Scr.Play)
            {
                _tipHash = tipHash;
                var def = _ui.HoveredCard != null ? CFG.Plant(_ui.HoveredCard) : null;
                if (def == null) { _tip.Hide(); }
                else
                {
                    string l1 = def.Name + " — " + def.Cost + " СОЛНЦА";
                    string l2 = def.Tip.ToUpperInvariant();
                    int w = Mathf.Max(Glyphs.Width(l1), Glyphs.Width(l2)) + 22;
                    _tip.Ensure(w, 34);
                    Paint.Tooltip(_tip.Tex, l1, l2);
                    _tip.Present();
                    _tip.Sr.transform.localPosition = new Vector3(
                        Mathf.Clamp(Mathf.RoundToInt(_ui.MouseX + 10), 4, Geo.VIEW_W - w - 4),
                        -Geo.LAWN_Y - 6, 0f);
                }
            }
            if (_ui.HoveredCard == null && _tipHash != 0) { _tipHash = 0; _tip.Hide(); }

            // всплывашка
            if (_toastText != null)
            {
                int w = Mathf.Max(150, Glyphs.Width(_toastText) + 44);
                _toast.Ensure(w, 28);
                Paint.Toast(_toast.Tex, _toastText, _toastFinal);
                _toast.Present();
                float a = _toastT < 0.22f ? _toastT / 0.22f : Mathf.Max(0f, 1f - (_toastT - 2.5f) / 0.9f);
                _toast.Sr.color = new Color(1f, 1f, 1f, Mathf.Clamp01(a));
                _toast.Sr.transform.localPosition = new Vector3(
                    Mathf.RoundToInt((Geo.VIEW_W - w) / 2f), -(Geo.LAWN_Y + Geo.ROWS * Geo.TILE - 64), 0f);
            }
            else _toast.Hide();

            // экраны и меню
            int ovHash = ((int)_scr) * 4 + (_paused ? 2 : 0) + (int)_world.State * 17 + _menuHover + (_adSel + 1) * 3 +
                         (int)(_clock * 4);                              // пульсация подсказки
            if (ovHash != _overlayHash)
            {
                _overlayHash = ovHash;
                _overlay.Ensure(Geo.VIEW_W, Geo.VIEW_H);
                _overlay.Tex.ClearTransparent();
                bool show = false;
                if (_scr == Scr.Title) { Paint.Title(_overlay.Tex, _world, _lib); show = true; }
                else if (_scr == Scr.Menu) { Paint.Menu(_overlay.Tex, _menuHover, _lib); show = true; }
                else if (_scr == Scr.Adventure) { Paint.Adventure(_overlay.Tex, _menuHover, AdventureSel(), _lib); show = true; }
                else if (_paused) { Paint.Pause(_overlay.Tex); show = true; }
                else if (_world.State == WorldState.Won) { Paint.Win(_overlay.Tex, _world, _lib); show = true; }
                else if (_world.State == WorldState.Lost) { Paint.Lose(_overlay.Tex, _world); show = true; }
                if (show) _overlay.Present(); else _overlay.Hide();

                // бегущая строка-подсказка внизу панелей (отдельно, чтобы не перепекать всё)
                _hint.Ensure(Geo.VIEW_W, 16);
                _hint.Tex.ClearTransparent();
                string hint = _scr == Scr.Title ? Paint.TitleHint
                    : (_scr == Scr.Menu ? Paint.MenuHint
                    : (_scr == Scr.Adventure ? Paint.AdventureHint : null));
                if (hint != null)
                {
                    _hint.Tex.Text(Geo.VIEW_W / 2, 12, hint, new Color32(168, 216, 138, 255), 1, 0, null);
                    _hint.Present();
                    float pulse = 0.55f + 0.45f * Mathf.Sin(_clock * 4f);
                    _hint.Sr.color = new Color(1f, 1f, 1f, pulse);
                    // смещение по экрану: строка не должна залезать под панель.
                    // На карте панель кончается на 374-й, поэтому подсказку уводим за неё.
                    float hintY = _scr == Scr.Title ? 348f
                                : (_scr == Scr.Adventure ? Pvz.View.AdventureLayout.PanelY + Pvz.View.AdventureLayout.PanelH + 16f : 310f);
                    _hint.Sr.transform.localPosition = new Vector3(0f, -hintY, 0f);
                }
                else _hint.Hide();
            }

            // мир
            _views.BeginFrame();
            _quads.Begin();
            if (_scr == Scr.Play)
            {
                _views.DrawPlacement(_world, _ui, _clock);
                _views.DrawPlants(_world);
                _views.DrawMowers(_world);
                _views.DrawPeas(_world);
                _views.DrawZombies(_world);
                _views.DrawSuns(_world);
                _views.DrawDragged(_world, _ui);
            }
            _fx.Draw(_quads, _views.Pixel);
            _quads.End();
            _views.EndFrame();

            // текст частиц — маленький Tex поверх
            if (_fx.Count > 0)
            {
                _hud.Ensure(Geo.VIEW_W, Geo.LAWN_Y);
                _fx.DrawText(_hud.Tex);
                _hud.Present();
                _hudHash = -1;                                   // в следующем кадре HUD перепечётся начисто
            }
        }

        private string HoverCard()
        {
            if (!_ui.HasMouse) return null;
            var pk = CFG.HUD.Packet;
            for (int i = 0; i < _world.Seeds.Count; i++)
            {
                float x = (float)(pk.X + i * (pk.W + pk.Gap));
                var r = new Rect(x, (float)pk.Y - 4f, (float)pk.W, (float)pk.H + 8f);
                if (r.Contains(new Vector2(_ui.MouseX, _ui.MouseY))) return _world.Seeds[i];
            }
            return null;
        }

        // ------------------------------------------------------- пиксель-перфект
        private void Fit()
        {
            int pw = Mathf.Max(1, _cam.pixelWidth), ph = Mathf.Max(1, _cam.pixelHeight);
            double k = System.Math.Min(pw / (double)Geo.VIEW_W, ph / (double)Geo.VIEW_H);
            float s = k >= 1.0 ? Mathf.Floor((float)k) : Mathf.Max(0.05f, (float)k);
            if (!PixelPerfect && k < 1.0) s = (float)k;
            _root.localScale = new Vector3(s, s, 1f);
            _cam.orthographicSize = (ph / s) * 0.5f;
            Vector3 shake = _fx.Shake > 0f
                ? new Vector3(Random.Range(-2.5f, 2.5f) * _fx.Shake * 10f, Random.Range(-2.5f, 2.5f) * _fx.Shake * 10f, 0f)
                : Vector3.zero;
            _cam.transform.position = new Vector3(Geo.VIEW_W * 0.5f, -Geo.VIEW_H * 0.5f, -10f) + shake / s;
            _cam.transform.rotation = Quaternion.identity;
        }

        private void OnGUI()
        {
            // маленький уголок подсказок — чтобы было видно, что кликабельно (в билде не рисуем)
            if (!Debug.isDebugBuild) return;
        }
    }
}
