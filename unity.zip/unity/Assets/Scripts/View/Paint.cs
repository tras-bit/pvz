// ============================================================================
//  PAINT — перенос рисования статичных кусков из render.js в программный буфер:
//  фон/газон, балка HUD с карточками, тултип, всплывашка, экраны и меню.
//  Композиция и числа те же, что в браузере, — сверял скриншотами.
// ============================================================================
using System.Collections.Generic;
using UnityEngine;
using Pvz.Core;

namespace Pvz.View
{
    /// <summary>Раскладка меню — общая для отрисовки и для проверки кликов.</summary>
    public static class MenuLayout
    {
        /// <summary>Пункт главного меню. Уровни сюда не выписаны: они на экране
        /// «ВЫБОР УРОВНЯ» (AdventureLayout) — меню только ведёт туда.</summary>
        public struct Mode { public string Title; public string Sub; public bool Locked; public string Art; }

        public static readonly Mode[] Modes =
        {
            new Mode { Title = "ПРИКЛЮЧЕНИЕ", Sub = "ВЫБОР УРОВНЯ · " + LevelsWord(Core.CFG.LEVELS.Count), Locked = false,
                       Art = "assets/plants/peashooter.png" },
            new Mode { Title = "МУЛЬТИПЛЕЕР", Sub = "НЕ В ЭТОЙ СБОРКЕ", Locked = true, Art = "" },
        };

        /// <summary>Пункт доступен? (мультиплеер — никогда, он заглушка)</summary>
        public static bool IsOpen(int i) { return !Modes[i].Locked; }

        public const int CW = 236, CH = 76, GAPX = 20, COLS = 2;
        public static readonly int PanelX = (Core.Geo.VIEW_W - (COLS * CW + (COLS - 1) * GAPX)) / 2;
        public static readonly int CardY = 158;

        public static Rect Card(int i)
        {
            int c = i % COLS, r = i / COLS;
            return new Rect(PanelX + c * (CW + GAPX), CardY + r * (CH + 14), CW, CH);
        }
        public static int Rows { get { return (Modes.Length + COLS - 1) / COLS; } }
        public static int PanelH { get { return 96 + Rows * CH + (Rows - 1) * 14; } }

        /// <summary>«3 УРОВНЯ» в подзаголовке пункта меню: число берём из конфига,
        /// чтобы добавление уровня не требовало правки строки.</summary>
        public static string LevelsWord(int n)
        {
            if (n == 1) return "1 УРОВЕНЬ";
            if (n <= 4) return n + " УРОВНЯ";
            return n + " УРОВНЕЙ";
        }
    }

    /// <summary>Карта приключения: узлы уровней стоят на извилистой дорожке, как в
    /// оригинале. Геометрия считается от числа уровней в конфиге — добавишь уровень в
    /// CFG.LEVELS, и он сам встанет в конец дороги; узлы не «карточки в ряд», а точки
    /// маршрута, поэтому и попадание мышью берётся от того же CenterX/CenterY.</summary>
    public static class AdventureLayout
    {
        public const int NW = 80, NH = 84;                      // прямоугольник вокруг узла (по нему клики)
        public const int PanelX = 28, PanelY = 46, PanelW = 584, PanelH = 328;
        public const int HeaderH = 52, FooterH = 32;

        public static int Count { get { return Core.CFG.LEVELS.Count; } }
        public static int LawnY { get { return PanelY + HeaderH; } }
        public static int LawnH { get { return PanelH - HeaderH - FooterH; } }

        /// <summary>Высота волны: дороги не идут линейкой, узлы скачут вверх-вниз.</summary>
        static readonly int[] WAVE = { 6, -40, 34, -14, 24, -30, 16, -4 };

        public static int CenterX(int i)
        {
            int pad = 92, usable = PanelW - 2 * pad;
            return Count <= 1 ? PanelX + PanelW / 2 : PanelX + pad + usable * i / (Count - 1);
        }

        public static int CenterY(int i)
        {
            return LawnY + LawnH / 2 + WAVE[((i % WAVE.Length) + WAVE.Length) % WAVE.Length];
        }

        public static Rect Node(int i)
        {
            return new Rect(CenterX(i) - NW / 2, CenterY(i) - NH / 2, NW, NH);
        }

        public static bool IsOpen(int i) { return Progress.LevelOpen(i); }
        public static bool Done(int i) { return i < Progress.LevelsDone; }

        /// <summary>Первый открытый и непройденный узел — на него рисуют стрелку
        /// «СЛЕДУЮЩИЙ УРОВЕНЬ» (-1 = всё пройдено).</summary>
        public static int Next
        {
            get
            {
                for (int i = 0; i < Count; i++) if (IsOpen(i) && !Done(i)) return i;
                return -1;
            }
        }

        public static string Title(int i) { return Core.CFG.LEVELS[i].Id; }
        public static string Sub(int i)
        {
            var lvl = Core.CFG.LEVELS[i];
            // «сколько зомби было» на карте не показываем: это не описание уровня,
            // а счётчик (игрок просил убрать), а полос и волн — видно, сколько готовиться
            return RowsWord(lvl.Rows.Count) + " · " + lvl.Waves.Count + " ВОЛН";
        }
        /// <summary>Картинка узла — первое растение пачки уровня (тем и играем).</summary>
        public static string Art(int i)
        {
            var seeds = Core.CFG.LEVELS[i].Seeds;
            if (seeds == null || seeds.Count == 0) return "";
            var def = Core.CFG.Plant(seeds[0]);
            return def == null ? "" : def.Sprite;
        }
        public static string RowsWord(int n)
        {
            if (n == 1) return "1 ПОЛОСА";
            if (n < 5) return n + " ПОЛОСЫ";
            return n + " ПОЛОС";
        }
    }


    public static class Paint
    {
        private static Color32 P(string hex) { return Pal.C(hex); }
        private static Color32 A(string hex, byte a) { var c = Pal.C(hex); c.a = a; return c; }
        private static Color32 Ink(byte a) { return new Color32(21, 17, 19, a); }

        // ------------------------------------------------------------------ фон
        public static void Backdrop(Tex t, World w, SpriteLib lib)
        {
            int VIEW_W = Core.Geo.VIEW_W, LAWN_Y = Core.Geo.LAWN_Y, LAWN_X = Core.Geo.LAWN_X;
            int RIGHT = Core.Geo.LAWN_RIGHT, BOTTOM = Core.Geo.LAWN_BOTTOM, TILE = Core.Geo.TILE;

            t.Clear(P(Pal.SKY));
            t.FillRect(0, 0, VIEW_W, LAWN_Y, P(Pal.SKY));
            // кусты
            t.FillRect(0, LAWN_Y - 12, VIEW_W, 12, P(Pal.HEDGE));
            for (int x = -6; x < VIEW_W; x += 16) t.Tri(x, LAWN_Y, x + 8, LAWN_Y - 14, x + 16, LAWN_Y, P(Pal.HEDGE_D));
            t.FillRect(0, LAWN_Y - 1, VIEW_W, 2, P(Pal.INK));

            // стена дома слева с окошком
            t.FillRect(0, LAWN_Y, LAWN_X, BOTTOM - LAWN_Y, P(Pal.HOUSE));
            for (int y = LAWN_Y + 6; y < BOTTOM; y += 14) t.FillRect(0, y, LAWN_X, 3, P(Pal.HOUSE_D));
            t.FillRect(LAWN_X - 3, LAWN_Y, 3, BOTTOM - LAWN_Y, P(Pal.INK));
            int wy = LAWN_Y + 70;
            t.Panel(6, wy, 20, 20, P("#bfe8f7"), P(Pal.INK), 2, 3, false, false);
            t.FillRect(6 + 9, wy + 2, 2, 16, P(Pal.INK));
            t.FillRect(8, wy + 9, 16, 2, P(Pal.INK));

            // асфальт справа, откуда идут зомби
            t.FillRect(RIGHT, LAWN_Y, VIEW_W - RIGHT, BOTTOM - LAWN_Y, P(Pal.STREET));
            t.FillRect(RIGHT, LAWN_Y, 3, BOTTOM - LAWN_Y, P(Pal.STREET_D));
            for (int y = LAWN_Y + 14; y < BOTTOM; y += 40) t.FillRect(RIGHT + 8, y, 14, 3, P(Pal.STREET_D));
            t.FillRect(RIGHT - 1, LAWN_Y, 1, BOTTOM - LAWN_Y, P(Pal.INK));

            // земля под газоном
            t.FillRect(0, BOTTOM, VIEW_W, Core.Geo.VIEW_H - BOTTOM, P(Pal.SOIL));
            t.FillRect(0, BOTTOM, VIEW_W, 3, P(Pal.SOIL_D));

            // сам газон: открытые клетки — тайлы, закрытые — дощатый щит
            var g0 = lib.Get("assets/lawn/grass-0.png");
            var g1 = lib.Get("assets/lawn/grass-1.png");
            for (int row = 0; row < Core.Geo.ROWS; row++)
            {
                int y = LAWN_Y + row * TILE;
                bool open = w.IsUnlocked(row);
                for (int col = 0; col < Core.Geo.COLS; col++)
                {
                    int x = LAWN_X + col * TILE;
                    if (!open)
                    {
                        t.FillRect(x, y, TILE, TILE, P(Pal.LOCK));
                        for (int i = 0; i < TILE; i += 16) t.FillRect(x, y + i + 4, TILE, 5, P(Pal.LOCK_D));
                        t.FillRect(x, y + 1, TILE, 2, A("#ffffff", 26));
                        continue;
                    }
                    var e = (row + col) % 2 == 1 ? g1 : g0;
                    if (!e.Missing) t.Draw(e.Base, x, y);
                    else t.FillRect(x, y, TILE, TILE, (row + col) % 2 == 1 ? P(Pal.GRASS_B) : P(Pal.GRASS_A));
                }
                t.FillRect(LAWN_X, y, Core.Geo.COLS * TILE, 1, Ink(71));          // rgba(21,17,19,0.28)
            }
            if (!w.IsUnlocked(0)) t.FillRect(LAWN_X, LAWN_Y, Core.Geo.COLS * TILE, 1, P(Pal.INK));

            // «линия дома»: за неё пускать нельзя
            for (int y = LAWN_Y; y < BOTTOM; y += 8) t.FillRect(LAWN_X, y, 2, 4, A(Pal.NO, 128));
        }

        // ------------------------------------------------------------------ HUD
        public static void Hud(Tex t, World w, UiState ui, SpriteLib lib)
        {
            var hud = Core.CFG.HUD;
            int VIEW_W = Core.Geo.VIEW_W;
            int barH = Core.Geo.LAWN_Y - 8;

            t.ClearTransparent();
            t.FillRect(0, 0, VIEW_W, barH, P(Pal.WOOD_DARK));
            t.FillRect(0, 0, VIEW_W, barH - 6, P(Pal.WOOD));
            t.FillRect(0, 0, VIEW_W, 3, A("#ffffff", 36));
            for (int x = 12; x < VIEW_W; x += 46) t.FillRect(x, 6, 2, barH - 14, Ink(90));
            t.FillRect(0, barH - 3, VIEW_W, 3, P(Pal.INK));

            // счётчик солнца
            var b = hud.Bank;
            t.Panel((int)b.X, (int)b.Y, (int)b.W, (int)b.H, P(Pal.CARD), P(Pal.INK), 3, 6);
            SunIcon(t, (int)(b.X + 20), (int)(b.Y + 20), 11);
            // 4+ разряда в панель не влезают — мелким шрифтом, но целиком
            string sunTxt = ((int)w.SunCount).ToString();
            t.Text((int)b.X + 40, (int)b.Y + 27, sunTxt, P("#3a2a10"), sunTxt.Length >= 4 ? 1 : 2);
            t.Text((int)(b.X + b.W / 2), (int)(b.Y + b.H - 9), "СОЛНЦЕ", P("#6b4a2f"), 1, 0);

            // карточки семян
            var pk = hud.Packet;
            for (int i = 0; i < w.Seeds.Count; i++)
            {
                string type = w.Seeds[i];
                var def = CFG.Plant(type);
                int x = (int)(pk.X + i * (pk.W + pk.Gap));
                bool sel = ui.Selected == type;
                bool afford = w.SunCount >= def.Cost;
                bool inHand = ui.DragActive && ui.DragMoved && ui.DragType == type;
                double cool = w.CooldownLeft(type);
                bool ready = cool <= 0;
                int y = (int)(pk.Y - (sel ? 3 : 0));
                t.Panel(x, y, (int)pk.W, (int)pk.H, sel ? P("#fff6cf") : P(Pal.CARD),
                        sel ? P(Pal.SUN) : P(Pal.INK), sel ? 4 : 3, 6);

                var e = lib.Get(def.Sprite);
                int k = System.Math.Max(e.W, e.H) > 46 ? 1 : 1;
                double half = System.Math.Max(e.W, e.H) > 46 ? 0.5 : 1.0;
                float dw = (float)(e.W * half * k), dh = (float)(e.H * half * k);
                t.FillRect(x + 3, y + 3, (int)pk.W - 6, (int)pk.H - 20, P("#9fd8f0"));
                t.FillRect(x + 3, y + (int)pk.H - 22, (int)pk.W - 6, 6, P(Pal.GRASS_B));
                t.Draw(e.Base, (int)(x + (pk.W - dw) / 2), (int)(y + pk.H - 20 - dh + 5),
                       null, inHand ? 0.22f : (afford && ready ? 1f : 0.5f), false, half);
                t.StrokeRect(x + 3, y + 3, (int)pk.W - 6, (int)pk.H - 20, 2, P(Pal.INK));

                bool showCost = afford && ready;
                t.Panel(x + 6, y + (int)pk.H - 16, (int)pk.W - 12, 13, showCost ? P(Pal.SUN) : P("#c9c2b4"),
                        P(Pal.INK), 2, 3, false, false);
                // пока карточка отдыхает — вместо цены показываем секунды до перезарядки
                t.Text(x + (int)(pk.W / 2), y + (int)pk.H - 6, ready ? def.Cost.ToString() : cool.ToString("0.0"),
                       showCost ? P("#3a2a10") : P("#5a4a3a"), 1, 0);
                if (!ready)
                {
                    // «недозаряженная» часть сверху: тень уходит вниз по мере перезарядки
                    double frac = def.Cooldown > 0 ? System.Math.Min(1.0, cool / def.Cooldown) : 0;
                    int hh = Mathf.Clamp(Mathf.RoundToInt((float)(pk.H - 4) * (float)frac), 0, (int)pk.H - 4);
                    t.FillRect(x + 2, y + 2, (int)pk.W - 4, hh, new Color32(18, 26, 14, 176));
                    t.FillRect(x + 2, y + 2 + hh, (int)pk.W - 4, 1, A(Pal.SUN, 150));
                }
                if (inHand) t.RoundRectFill(x, y, (int)pk.W, (int)pk.H, 6, Ink(115));
                else if (!afford) t.RoundRectFill(x, y, (int)pk.W, (int)pk.H, 6, Ink(102));
                if (!ready) t.Text(x + 8, y + 13, "zzz", P("#cfe6ff"), 1, -1, A("#141a10", 153), 2);
            }

            // лопата: отдельный слот справа от пачки (как в оригинале). Пока не
            // заработана — слота нет вовсе: пустая кнопка обещала бы то, чего нет
            bool hasShovel = Progress.HasTool("shovel");
            var sr = ShovelRect(w.Seeds.Count);
            if (hasShovel)
            {
                t.Panel((int)sr.x, (int)sr.y, (int)sr.width, (int)sr.height,
                        ui.Shovel ? P("#fff6cf") : P(Pal.CARD), ui.Shovel ? P(Pal.SUN) : P(Pal.INK),
                        ui.Shovel ? 4 : 3, 6);
                var se = lib.Get("assets/fx/shovel.png");
                t.Draw(se.Base, (int)(sr.x + (sr.width - 32) / 2), (int)(sr.y + 10), null, 1f, false, 1f);
                t.StrokeRect((int)sr.x + 3, (int)sr.y + 3, (int)sr.width - 6, (int)sr.height - 6, 2, P(Pal.INK));
                t.Text((int)(sr.x + sr.width / 2), (int)(sr.y + sr.height - 9),
                       ui.Shovel ? "КОПАЕМ" : "ЛОПАТА", ui.Shovel ? P("#4a3410") : P("#6b4a2f"), 1, 0);
                if (ui.Shovel) t.FillRect((int)sr.x, (int)sr.y, (int)sr.width, (int)sr.height, A(Pal.SUN, 40));
            }

            // Название уровня + подсказка по выбранной карточке. Левый край — за пачкой:
            // с 3–4 карточками подпись стартовала прямо поверх последней карты. Если и за
            // пачкой текст не влезает — оставляем только номер уровня, а не режем по правому краю.
            int lx = (int)hud.LevelText.x;
            int pkRight = (int)(hud.Packet.X + w.Seeds.Count * (hud.Packet.W + hud.Packet.Gap));
            if (hasShovel && (int)sr.x + (int)sr.width > pkRight) pkRight = (int)sr.x + (int)sr.width;
            if (pkRight + 12 > lx) lx = pkRight + 12;
            int capLimit = Core.Geo.VIEW_W - 12;
            string cap = w.Level.Subtitle + " · " + w.Level.Name;
            if (lx + Glyphs.Width(cap) > capLimit) cap = w.Level.Subtitle;
            if (lx + Glyphs.Width(cap) > capLimit) lx = (int)hud.LevelText.x;
            t.Text(lx, (int)hud.LevelText.y, cap, P("#ffe9a8"), 1);
            string hintType = ui.DragActive ? null : (ui.Selected ?? ui.HoveredCard);   // в руке — не мешаем
            if (hintType != null && CFG.Plant(hintType) != null)
                t.Text(lx, (int)hud.LevelText.y + 15, "→ " + CFG.Plant(hintType).Tip.ToUpperInvariant(),
                       P("#cfe8b8"), 1, -1, null);

            // прогресс волны
            var pr = hud.Progress;
            int px = (int)pr.X, py = (int)pr.Y, pw = (int)pr.W, ph = (int)pr.H;
            // с лопатой (и с пятью карточками на 1-4) пачка упирается в полосу прогресса —
            //двигаем её и урезаем так, чтобы в экран гарантированно влезла
            if (hasShovel && (int)sr.x + (int)sr.width + 12 > px) px = (int)sr.x + (int)sr.width + 12;
            pw = Mathf.Min(pw, Core.Geo.VIEW_W - 20 - px);
            if (pw < 60) pw = 60;
            t.Panel(px - 2, py - 2, pw + 4, ph + 4, P("#3d2c1a"), P(Pal.INK), 2, 4, false, false);
            float done = Mathf.Clamp01((float)w.KilledZombies / Mathf.Max(1, w.TotalZombies));
            t.FillRect(px, py, pw, ph, P("#6b5233"));
            int fw = Mathf.RoundToInt(pw * done);
            t.FillRect(px, py, fw, ph, P(Pal.GOOD));
            t.FillRect(px, py + 1, fw, 2, A("#ffffff", 64));
            t.FillRect(px + pw + 2, py - 10, 2, 10 + ph, P(Pal.INK));
            bool fin = false;
            var waves = w.Level.Waves;
            if (waves.Count > 0) fin = waves[waves.Count - 1].Final;
            t.FillRect(px + pw + 4, py - 10, 9, 6, fin ? P(Pal.BAD) : P("#d8d2c4"));
            for (int i = 1; i < waves.Count; i++)
                t.FillRect(px + Mathf.RoundToInt(pw * ((float)i / waves.Count)), py, 1, ph, Ink(128));
            t.Text(px, py - 8, "ВОЛНА " + Mathf.Min(w.WaveIndex, waves.Count) + "/" + waves.Count, P(Pal.TEXT), 1, -1, Ink(255), 1);
            // «ЗОМБИ x/y» здесь больше не рисуем: счётчик убитых — не часть газона,
            // полоса прогресса и флаг говорят ровно то же самое и не мигают цифрами
        }

        private static void SunIcon(Tex t, int cx, int cy, int r)
        {
            for (int i = 0; i < 8; i++)
            {
                double a = i * System.Math.PI / 4;
                int x0 = cx + (int)System.Math.Round(System.Math.Cos(a) * (r + 2));
                int y0 = cy + (int)System.Math.Round(System.Math.Sin(a) * (r + 2));
                int x1 = cx + (int)System.Math.Round(System.Math.Cos(a + 0.34) * (r - 3));
                int y1 = cy + (int)System.Math.Round(System.Math.Sin(a + 0.34) * (r - 3));
                int x2 = cx + (int)System.Math.Round(System.Math.Cos(a - 0.34) * (r - 3));
                int y2 = cy + (int)System.Math.Round(System.Math.Sin(a - 0.34) * (r - 3));
                t.Tri(x0, y0, x1, y1, x2, y2, P(Pal.INK));
            }
            t.Ellipse(cx, cy, r, r, P(Pal.SUN));
            for (int i = 0; i < 8; i++)
            {
                double a = i * System.Math.PI / 4;
                int x0 = cx + (int)System.Math.Round(System.Math.Cos(a) * (r + 2));
                int y0 = cy + (int)System.Math.Round(System.Math.Sin(a) * (r + 2));
                int x1 = cx + (int)System.Math.Round(System.Math.Cos(a + 0.34) * (r - 3));
                int y1 = cy + (int)System.Math.Round(System.Math.Sin(a + 0.34) * (r - 3));
                int x2 = cx + (int)System.Math.Round(System.Math.Cos(a - 0.34) * (r - 3));
                int y2 = cy + (int)System.Math.Round(System.Math.Sin(a - 0.34) * (r - 3));
                t.Tri(x0, y0, x1, y1, x2, y2, P(Pal.INK));
            }
            t.Ellipse(cx, cy, r, r, P(Pal.SUN));
            t.Ellipse(cx - r / 3, cy - r / 3, (int)(r * 0.32f), (int)(r * 0.32f), P(Pal.SUN_LIGHT));
            OutlineCircle(t, cx, cy, r, P(Pal.INK));
        }

        private static void OutlineCircle(Tex t, int cx, int cy, int r, Color32 c)
        {
            for (int a = 0; a < 360; a += 3)
            {
                double rad = a * System.Math.PI / 180.0;
                t.FillRect(cx + (int)System.Math.Round(System.Math.Cos(rad) * r), cy + (int)System.Math.Round(System.Math.Sin(rad) * r), 1, 1, c);
            }
        }

        // ------------------------------------------------------- тултип/всплывашка
        public static void Tooltip(Tex t, string title, string sub)
        {
            t.ClearTransparent();
            int w = t.W, h = t.H;
            t.Panel(0, 0, w, h, P("#241d12"), P(Pal.SUN), 2, 6, false, false);
            t.Text(10, 14, title, P(Pal.SUN), 1, -1, null);
            t.Text(10, 26, sub, P("#e8f0d8"), 1, -1, null);
        }

        public static void Toast(Tex t, string text, bool final)
        {
            t.ClearTransparent();
            t.Panel(0, 0, t.W, t.H, final ? P("#8c2a22") : P("#2f2a24"),
                    final ? P(Pal.BAD) : P(Pal.INK), 3, 8, true, true);
            t.Text(t.W / 2, t.H - 9, text, final ? P("#ffd7cf") : P("#fff4c4"), 1, 0, null);
        }

        // ---------------------------------------------------------------- экраны
        public static void Dim(Tex t, byte alpha) { t.FillRect(0, 0, t.W, t.H, new Color32(12, 20, 10, alpha)); }

        public static void BigTitle(Tex t, string s, int cx, int baseline, int scale, Color32 fill)
        {
            t.Text(cx, baseline, s, fill, scale, 0, Ink(230), scale);
        }

        public static void Title(Tex t, World w, SpriteLib lib)
        {
            int VIEW_W = Core.Geo.VIEW_W;
            Dim(t, 128);
            int pw = 424, ph = 268, px = (VIEW_W - pw) / 2, py = 66;
            t.Panel(px, py, pw, ph, P("#1f2a18"), P(Pal.SUN), 4, 14);
            t.Panel(px + 6, py + 6, pw - 12, ph - 12, P("#1f2a18"), A(Pal.SUN, 90), 2, 10, false, false);
            BigTitle(t, "ПИКСЕЛЬНАЯ ЛУЖАЙКА", VIEW_W / 2, py + 48, 3, P(Pal.SUN));
            t.Text(VIEW_W / 2, py + 68, w.Level.Subtitle + " · " + w.Level.Name, P("#a8d88a"), 1, 0, null);

            string[] lines = {
                "1. КАРТОЧКУ ПЕРЕТАЩИ НА ГАЗОН", "2. ПО КЛИКУ ОНА НЕ САЖАЕТ", "3. СОБИРАЙ СОЛНЦЕ КЛИКОМ",
                "4. ПОДСОЛНУХ: 50 СОЛНЦА", "5. КАРТОЧКА ПОСЛЕ ПОСАДКИ ОТДЫХАЕТ", "6. C — ЗАРЯДИТЬ ВСЕ СРАЗУ (ЧИТ)",
            };
            for (int i = 0; i < lines.Length; i++) t.Text(px + 24, py + 96 + i * 15, lines[i], P("#e8f0d8"), 1, -1, null);
            t.Text(VIEW_W / 2, py + 200, "СТАРТ: " + w.Level.StartSun + " СОЛНЦА · ПЕРЕЗАРЯДКА КАРТОЧКИ 7.5 С · C — ЧИТ-ЗАРЯД",
                   P("#8fb475"), 1, 0, null);

            // мини-сцена с героями
            int sx = px + pw - 212, sy = py + 90, sw = 196, sh = 90;
            t.FillRect(sx, sy + sh - 16, sw, 16, P(Pal.GRASS_B));
            t.FillRect(sx, sy + sh - 18, sw, 2, P(Pal.INK));
            var z = lib.Get(CFG.Zombie("basic").Sprite);
            var sf = lib.Get(CFG.Plant("sunflower").Sprite);
            var ps = lib.Get(CFG.Plant("peashooter").Sprite);
            t.Draw(ps.Base, sx + 4, sy + sh - 16 - ps.H);
            t.Draw(sf.Base, sx + 70, sy + sh - 18 - sf.H);
            t.Draw(z.Base, sx + 134, sy + sh - 18 - z.H);
            t.StrokeRect(sx - 1, sy - 1, sw + 2, sh + 2, 2, P(Pal.SUN));

            t.Panel(VIEW_W / 2 - 80, py + ph - 56, 160, 34, P(Pal.GOOD), P(Pal.INK), 3, 10);
            t.Text(VIEW_W / 2, py + ph - 33, "> НАЧАТЬ", P("#0f2a08"), 2, 0, new Color32(255, 255, 255, 140), 2);
        }

        public static string TitleHint { get { return "ENTER ИЛИ КЛИК · P ПАУЗА · R ЗАНОВО · M ЗВУК"; } }

        /// <summary>Главное меню в духе оригинала: сетка режимов, активен один.</summary>
        public static void Menu(Tex t, int hover, SpriteLib lib)
        {
            int VIEW_W = Core.Geo.VIEW_W;
            Dim(t, 150);
            int pw = MenuLayout.COLS * MenuLayout.CW + (MenuLayout.COLS - 1) * MenuLayout.GAPX + 48;
            int ph = MenuLayout.PanelH;
            int px = (VIEW_W - pw) / 2, py = 82;
            t.Panel(px, py, pw, ph, P("#1f2a18"), P(Pal.SUN), 4, 14);
            BigTitle(t, "ГЛАВНОЕ МЕНЮ", VIEW_W / 2, py + 44, 2, P(Pal.SUN));
            t.Text(VIEW_W / 2, py + 62,
                   "УРОВНЕЙ " + Core.CFG.LEVELS.Count + " · ОТКРЫТО РАСТЕНИЙ " + UnlockedCount() +
                   " · ПРОЙДЕНО " + Progress.LevelsDone,
                   P("#a8d88a"), 1, 0, null);

            for (int i = 0; i < MenuLayout.Modes.Length; i++)
            {
                var m = MenuLayout.Modes[i];
                bool locked = !MenuLayout.IsOpen(i);
                var r = MenuLayout.Card(i);
                // r уже в абсолютных координатах экрана (он же используется для кликов)
                int x = (int)r.x, y = (int)r.y;
                bool hot = hover == i && !locked;
                t.Panel(x, y, (int)r.width, (int)r.height,
                        locked ? P("#2b3324") : (hot ? P("#7fd45f") : P(Pal.GRASS_A)),
                        hot ? P(Pal.SUN) : P(Pal.INK), hot ? 3 : 2, 8, false, true);
                for (int gx = 4; gx < r.width - 4; gx += 8)
                    t.FillRect(x + gx, y + (int)r.height - 8, 4, 4, locked ? A("#000000", 40) : A("#7fd45f", 90));
                t.Text(x + 14, y + 28, m.Title, locked ? P("#6d7a63") : P("#12280c"), 2, -1, hot ? null : Ink(60), 1);
                t.Text(x + 14, y + 54, m.Sub, locked ? P("#5d6a55") : P("#1c3a12"), 1, -1, null);
                if (locked) DrawLock(t, x + (int)r.width - 34, y + (int)r.height / 2 - 6, 1f);
                else if (m.Art.Length > 0)
                {
                    var e = lib.Get(m.Art);
                    if (!e.Missing) t.Draw(e.Base, x + (int)r.width - 40, y + 8, null, 1f, false, 0.5);
                }
            }
        }

        private static void DrawLock(Tex t, int x, int y, float k)
        {
            t.FillRect(x, y, (int)(12 * k), (int)(9 * k), P("#c9b46a"));
            t.StrokeRect(x - 1, y - 1, (int)(14 * k), (int)(11 * k), 1, P(Pal.INK));
            t.StrokeRect(x + 2, y - 5, (int)(8 * k), (int)(6 * k), 2, P("#c9b46a"));
            t.StrokeRect(x + 3, y - 6, (int)(6 * k), (int)(6 * k), 1, P(Pal.INK));
        }

        /// <summary>Экран «ПРИКЛЮЧЕНИЕ»: карта с дорожкой. Пройденные узлы соединены
        /// утоптанной тропой, дальше она пунктирная; на запертых — замок, на пройденных —
        /// солнце, на выбранном — жёлтое кольцо, перед следующим горит стрелка.</summary>
        public static void Adventure(Tex t, int hover, int sel, SpriteLib lib)
        {
            int VIEW_W = Core.Geo.VIEW_W;
            Dim(t, 150);
            int px = AdventureLayout.PanelX, py = AdventureLayout.PanelY;
            int pw = AdventureLayout.PanelW, ph = AdventureLayout.PanelH;
            t.Panel(px, py, pw, ph, P("#1f2a18"), P(Pal.SUN), 4, 14);
            BigTitle(t, "ПРИКЛЮЧЕНИЕ", VIEW_W / 2, py + 30, 2, P(Pal.SUN));
            int nxt = AdventureLayout.Next;
            t.Text(VIEW_W / 2, py + 48,
                   "ВЫБОР УРОВНЯ · " + AdventureLayout.Count + " · ПРОЙДЕНО " + Progress.LevelsDone +
                   (nxt < 0 ? " · ВСЁ ПРОЙДЕНО" : " · ДАЛЬШЕ " + AdventureLayout.Title(nxt)) +
                   " · РАСТЕНИЙ " + UnlockedCount(), P("#a8d88a"), 1, 0, null);

            // --- газон, в шахматку как на поле, с травинками ---
            int ly = AdventureLayout.LawnY, lh = AdventureLayout.LawnH;
            int by = py + ph - AdventureLayout.FooterH;
            int row = 0;
            for (int y = ly; y < by; y += 24, row++)
            {
                int h = y + 24 > by ? by - y : 24;
                for (int x = px + 8, col = 0; x < px + pw - 8; x += 24, col++)
                {
                    int w = x + 24 > px + pw - 8 ? px + pw - 8 - x : 24;
                    t.FillRect(x, y, w, h, (row + col) % 2 == 0 ? P(Pal.GRASS_A) : P(Pal.GRASS_B));
                    if (((row * 7 + col * 5) % 6) == 0)
                        t.FillRect(x + 6, y + 15, 2, 4, A(Pal.GRASS_BLADE, 190));
                }
            }
            t.StrokeRect(px + 8, ly, pw - 16, by - ly, 2, Ink(120));

            // --- тропа между узлами: пройденная часть светлая и «топтаная»,
            //     остальная — тусклая пунктирная (ещё не хожено) ---
            for (int i = 0; i + 1 < AdventureLayout.Count; i++)
            {
                int ax = AdventureLayout.CenterX(i), ay = AdventureLayout.CenterY(i) + 26;
                int bx = AdventureLayout.CenterX(i + 1), by2 = AdventureLayout.CenterY(i + 1) + 26;
                bool walked = AdventureLayout.Done(i);
                int steps = 14, seg = (bx - ax) / steps;
                for (int k = 1; k < steps; k++)
                {
                    int tx = ax + seg * k, ty = ay + (by2 - ay) * k / steps;
                    if (!walked && k % 2 == 1) continue;                     // пунктир вперёд
                    t.FillRect(tx - 11, ty - 6, 22, 13, walked ? A(Pal.SOIL, 235) : A("#6d5b47", 190));
                    t.FillRect(tx - 11, ty + 5, 22, 2, walked ? A(Pal.SOIL_D, 210) : A("#4c3f31", 170));
                    if (walked && k % 3 == 0)
                    {
                        t.FillRect(tx - 5, ty - 2, 3, 3, A(Pal.SOIL_D, 200));
                        t.FillRect(tx + 3, ty + 1, 3, 3, A(Pal.SOIL_D, 200));
                    }
                }
            }

            // --- узлы (рисуем справа налево, чтобы левый — ближайший к дому — был поверх) ---
            for (int i = AdventureLayout.Count - 1; i >= 0; i--)
            {
                int cx = AdventureLayout.CenterX(i), cy = AdventureLayout.CenterY(i);
                bool open = AdventureLayout.IsOpen(i), done = AdventureLayout.Done(i);
                bool hot = hover == i || sel == i;

                t.Ellipse(cx, cy + 6, 34, 12, Ink(110));                     // тень под «пузырём»
                t.Ellipse(cx, cy, 33, 27, P(Pal.INK));                        // обводка
                t.Ellipse(cx, cy - 1, 30, 24,
                          open ? P(hot ? Pal.GRASS_BLADE : (i == nxt ? "#7fd45f" : Pal.GRASS_A)) : P("#46523c"));
                t.Ellipse(cx, cy - 8, 22, 13, A("#eaffd0", open ? (byte)110 : (byte)50));   // блик
                if (hot) t.Ellipse(cx, cy, 37, 31, A(Pal.SUN, 220));         // жёлтое кольцо выбора

                t.Text(cx, cy - 2, AdventureLayout.Title(i), open ? P("#12280c") : P("#8a9580"),
                       hot ? 3 : 2, 0, Ink(open ? (byte)70 : (byte)40), 1);
                if (!open) DrawLock(t, cx - 7, cy + 8, 1.2f);
                else
                {
                    string art = AdventureLayout.Art(i);
                    if (art.Length > 0)
                    {
                        var e = lib.Get(art);
                        if (!e.Missing) t.Draw(e.Base, cx - 13, cy + 6, null, 1f, false, 0.4);
                    }
                }
                if (done) SunIcon(t, cx + 25, cy - 21, 8);

                t.Text(cx, cy + 44, AdventureLayout.Sub(i), A(open ? "#f2ffe0" : "#93a08a", 255), 1, 0,
                       Ink(150), 1);
                if (i == nxt)
                {
                    // стрелка «сюда идти дальше»: треугольник + подпись над узлом
                    t.Tri(cx - 9, cy - 52, cx + 9, cy - 52, cx, cy - 40, P(Pal.SUN));
                    t.Tri(cx - 6, cy - 51, cx + 6, cy - 51, cx, cy - 43, A("#fff8c8", 255));
                    t.Text(cx, cy - 56, "СЛЕДУЮЩИЙ", A(Pal.SUN, 255), 1, 0, Ink(160), 1);
                }
            }

            // нижняя строка панели — не дубль подсказки управления (она и так внизу
            // экрана), а то, что выбрано: узел, название уровня и его состав
            int show = sel >= 0 ? sel : nxt;
            string foot = show < 0 ? "ВСЕ УРОВНИ ПРОЙДЕНЫ · ESC В МЕНЮ"
                : AdventureLayout.Title(show) + " · " + Core.CFG.LEVELS[show].Name.ToUpperInvariant() +
                  " · " + AdventureLayout.Sub(show) + (AdventureLayout.IsOpen(show) ? "" : " · ЗАПЕРТ");
            t.Text(VIEW_W / 2, by + 20, foot, P("#c8e0b0"), 1, 0, null);
        }

        /// <summary>Сколько растений уже открыто (для подзаголовков меню и карты).</summary>
        private static int UnlockedCount()
        {
            int n = 0;
            foreach (var kv in Core.CFG.PLANTS) if (Progress.Has(kv.Value.Id)) n++;
            return n;
        }

        public static string MenuHint { get { return "КЛИК ПО ПУНКТУ · ENTER — ВЫБРАТЬ УРОВЕНЬ · ESC — НАЗАД · M — ЗВУК"; } }

        /// <summary>Подсказка на экране выбора уровня.</summary>
        public static string AdventureHint { get { return "← → ↑ ↓ ПО ДОРОГЕ · ENTER В БОЙ · КЛИК ПО УЗЛУ · ESC В МЕНЮ"; } }

        public static void Pause(Tex t)
        {
            int VIEW_W = Core.Geo.VIEW_W, VIEW_H = Core.Geo.VIEW_H;
            Dim(t, 128);
            t.Panel(VIEW_W / 2 - 110, VIEW_H / 2 - 54, 220, 96, P("#1f2a18"), P(Pal.SUN), 4, 12);
            BigTitle(t, "ПАУЗА", VIEW_W / 2, VIEW_H / 2 - 8, 3, P(Pal.SUN));
            t.Text(VIEW_W / 2, VIEW_H / 2 + 22, "P ПРОДОЛЖИТЬ · R ЗАНОВО · ESC В МЕНЮ", P("#c8e0b0"), 1, 0, null);
        }

        // --- экран победы: одна геометрия на отрисовку и на клик (GameRoot) ---
        public const int WinPW = 340, WinPH = 206, WinPY = 110;

        /// <summary>Иконка лопаты в HUD. Прямоугольник — общий для отрисовки и для
        /// клика (как кнопка на экране победы): считается от числа карточек, потому что
        /// на 1-4 их пять и пачка доезжает почти до середины экрана.</summary>
        public static Rect ShovelRect(int seedCount)
        {
            var pk = Core.CFG.HUD.Packet;
            int x = (int)(pk.X + seedCount * (pk.W + pk.Gap)) + 6;
            return new Rect(x, (int)pk.Y, 46, (int)pk.H);
        }

        /// <summary>Индекс уровня этого мира в конфиге (-1 — не нашли).</summary>
        public static int WinLevelIndex(World w)
        {
            if (w == null) return -1;
            for (int i = 0; i < Core.CFG.LEVELS.Count; i++) if (Core.CFG.LEVELS[i] == w.Level) return i;
            return -1;
        }

        /// <summary>Есть ли куда идти после победы: следующий уровень есть и открыт.</summary>
        public static bool WinHasNext(World w)
        {
            int li = WinLevelIndex(w);
            return li >= 0 && li + 1 < Core.CFG.LEVELS.Count && Progress.LevelOpen(li + 1);
        }

        /// <summary>Кнопка на экране победы. Прямоугольник считается отсюда и для
        /// рисования, и для проверки клика: пока ширина кнопки жила прямо в Win(),
        /// клик по нарисованной кнопке «ДАЛЬШЕ» попадал в общий обработчик «заново»
        /// и перезапускал текущий уровень.</summary>
        public static Rect WinButtonRect(World w)
        {
            int bw = WinHasNext(w) ? 200 : 220;
            return new Rect((Core.Geo.VIEW_W - bw) / 2, WinPY + WinPH - 40, bw, 28);
        }

        public static void Win(Tex t, World w, SpriteLib lib)
        {
            int VIEW_W = Core.Geo.VIEW_W;
            Dim(t, 140);
            int pw = WinPW, ph = WinPH, px = (VIEW_W - pw) / 2, py = WinPY;
            t.Panel(px, py, pw, ph, P("#1f2a18"), P(Pal.GOOD), 4, 12);
            BigTitle(t, "УРОВЕНЬ ПРОЙДЕН", VIEW_W / 2, py + 46, 2, P("#9ff07a"));
            t.Text(VIEW_W / 2, py + 68, "ЗА " + w.Time.ToString("0.0") + " С", P(Pal.TEXT), 1, 0, null);
            int planted = 0;
            foreach (var kv in w.PlantedCount) planted += kv.Value;
            t.Text(VIEW_W / 2, py + 86, "ПОСАЖЕНО РАСТЕНИЙ: " + planted, P("#c8e0b0"), 1, 0, null);
            // награда: что уровень выдаёт (LevelDef.Rewards) — и уже реально открыто
            var rw = w.Level.Rewards;
            bool any = rw != null && rw.Count > 0;
            var tl = w.Level.Tools;
            bool anyTool = tl != null && tl.Count > 0;
            t.Panel(VIEW_W / 2 - 110, py + 100, 220, anyTool ? 58 : 40, P(Pal.CARD), P(Pal.INK), 3, 8);
            if (any || anyTool)
            {
                t.Text(VIEW_W / 2 - 96, py + 116, rw.Count > 1 ? "НОВЫЕ РАСТЕНИЯ" : "НОВОЕ РАСТЕНИЕ",
                       P("#6b4a2f"), 1, -1, null);
                t.Text(VIEW_W / 2 - 96, py + 130, Progress.RewardNames(w.Level), P("#3a2a12"), 1, -1, null);
                if (anyTool)
                    t.Text(VIEW_W / 2 - 96, py + 146, "ИНСТРУМЕНТ · " + Progress.ToolNames(w.Level),
                           P("#6b4a2f"), 1, -1, null);
                int dx = VIEW_W / 2 + 58 - (rw.Count - 1) * 17;
                for (int i = 0; i < rw.Count && i < 3; i++)
                {
                    var d = CFG.Plant(rw[i]);
                    if (d == null) continue;
                    var e = lib.Get(d.Sprite);
                    if (!e.Missing) t.Draw(e.Base, dx + i * 34, py + 100, null, 1f, false, 0.5);
                }
            }
            else
            {
                t.Text(VIEW_W / 2 - 96, py + 122, "НОВЫХ РАСТЕНИЙ НЕТ", P("#6b4a2f"), 1, -1, null);
            }

            // кнопка: если впереди ещё уровень — идём дальше (Enter ИЛИ клик, оба пути
            // настоящие:прямоугольник тот же, что проверяет GameRoot.OnDown)
            int li = WinLevelIndex(w);
            bool more = WinHasNext(w);
            string btn = more ? "ДАЛЬШЕ " + Core.CFG.LEVELS[li + 1].Id + " · ENTER ИЛИ КЛИК"
                              : "R — ЕЩЁ РАЗ · ESC В МЕНЮ";
            var br = WinButtonRect(w);
            t.Panel((int)br.x, (int)br.y, (int)br.width, (int)br.height, P(Pal.SUN), P(Pal.INK), 3, 8);
            t.Text(VIEW_W / 2, py + ph - 21, btn, P("#4a3410"), 1, 0, null);
        }

        public static void Lose(Tex t, World w)
        {
            int VIEW_W = Core.Geo.VIEW_W;
            Dim(t, 158);
            int pw = 320, ph = 150, px = (VIEW_W - pw) / 2, py = 120;
            t.Panel(px, py, pw, ph, P("#2a1414"), P(Pal.BAD), 4, 12);
            BigTitle(t, "ЗОМБИ СЪЕЛИ", VIEW_W / 2, py + 48, 2, P("#ff9a8a"));
            BigTitle(t, "ТВОЙ МОЗГ", VIEW_W / 2, py + 74, 2, P("#ff9a8a"));
            t.Text(VIEW_W / 2, py + 96, "ПРОДЕРЖАЛСЯ " + w.Time.ToString("0.0") + " С", P("#e8c8c0"), 1, 0, null);
            t.Panel(VIEW_W / 2 - 70, py + ph - 42, 140, 28, P(Pal.BAD), P(Pal.INK), 3, 8);
            t.Text(VIEW_W / 2, py + ph - 23, "R — СНОВА", P("#ffffff"), 1, 0, null);
        }
    }
}
