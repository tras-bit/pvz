// ============================================================================
//  SPRITELIB — аналог js/assets.js: кэш спрайтов, авто-подхват анимации по
//  именам файлов, целые масштабы, магента вместо отсутствующего файла.
//
//  Пути те же, что в веб-версии: 'assets/plants/sunflower.png' →
//  Resources/Pvz/assets/plants/sunflower.png. Кадры анимации ищутся по
//  соседству: basic.png + basic_walk_0.png, basic_walk_1.png, … (минимум 2),
//  ровно как в tools/scan_assets.py. Никаких манифестов в рантайме.
// ============================================================================
using System.Collections.Generic;
using UnityEngine;

namespace Pvz.View
{
    public sealed class SpriteLib
    {
        public const string Root = "Pvz";             // Assets/Resources/Pvz
        private static readonly string[] GROUP_NAMES = { "idle", "walk", "eat", "shoot", "death", "hurt", "chew" };

        public sealed class Entry
        {
            public string Url;
            public Sprite Base;
            public int W, H;
            public bool Missing;
            public int Fps = 6;
            public readonly Dictionary<string, List<Sprite>> Groups = new Dictionary<string, List<Sprite>>();

            public List<Sprite> Group(string name)
            {
                List<Sprite> g;
                return Groups.TryGetValue(name, out g) && g.Count > 1 ? g : null;
            }

            /// <summary>Кадр группы по времени (0, если группы нет — статика).</summary>
            /// <param name="fps">Кадров в секунду; 0 = сколько записано в Fps. Дробное,
            /// чтобы редкий кадр (шаг зомби = 2.4/с) задавался прямо здесь, а не через
            /// «домноженный» t — иначе фаза и масштаб разъезжаются на разных экранах.</param>
            public Sprite Pick(string group, double t, double fps)
            {
                var g = Group(group);
                if (g == null) return Base;
                double f = fps > 0 ? fps : Fps;
                int idx = (int)(System.Math.Abs(System.Math.Floor(t * f)) % g.Count);
                return g[idx];
            }
        }

        private readonly Dictionary<string, Entry> _cache = new Dictionary<string, Entry>();
        private readonly Dictionary<string, Dictionary<string, List<Sprite>>> _folderGroups =
            new Dictionary<string, Dictionary<string, List<Sprite>>>();
        private Sprite _placeholder;

        public static SpriteLib Load()
        {
            var lib = new SpriteLib();
            lib.ScanFolders();
            return lib;
        }

        private void ScanFolders()
        {
            // один LoadAll на папку: дёшево и не требует манифеста
            string[] folders = { "assets/plants", "assets/zombies", "assets/fx", "assets/lawn", "assets/mowers" };
            foreach (string folder in folders)
            {
                var map = new Dictionary<string, List<Sprite>>();
                var all = Resources.LoadAll<Sprite>(Root + "/" + folder);
                if (all == null) continue;
                foreach (var s in all)
                {
                    foreach (string gname in GROUP_NAMES)
                    {
                        string suffix = "_" + gname + "_";
                        int at = s.name.IndexOf(suffix);
                        if (at < 0) continue;
                        int num = 0;
                        if (!int.TryParse(s.name.Substring(at + suffix.Length), out num)) continue;
                        string baseName = s.name.Substring(0, at);
                        List<Sprite> list;
                        if (!map.TryGetValue(baseName + "|" + gname, out list))
                        {
                            list = new List<Sprite>();
                            map[baseName + "|" + gname] = list;
                        }
                        while (list.Count <= num) list.Add(null);
                        list[num] = s;
                    }
                }
                // дырки в нумерации → выкидываем хвост, чтобы кадры не «прыгали»
                var keys = new List<string>(map.Keys);
                foreach (var k in keys)
                {
                    var list = map[k];
                    while (list.Count > 0 && list[list.Count - 1] == null) list.RemoveAt(list.Count - 1);
                    if (list.Count < 2) map.Remove(k);
                }
                _folderGroups[folder] = map;
            }
        }

        public Entry Get(string url)
        {
            Entry e;
            if (_cache.TryGetValue(url, out e)) return e;
            e = new Entry { Url = url };
            string res = Root + "/" + url.Substring(0, url.Length - 4);   // снять .png
            int slash = res.LastIndexOf('/');
            string folder = url.Substring(0, url.LastIndexOf('/'));
            string fileName = url.Substring(url.LastIndexOf('/') + 1);
            fileName = fileName.Substring(0, fileName.Length - 4);

            var sp = Resources.Load<Sprite>(res);
            if (sp != null)
            {
                e.Base = sp;
                e.W = (int)sp.rect.width; e.H = (int)sp.rect.height; e.Missing = false;
                Dictionary<string, List<Sprite>> map;
                if (_folderGroups.TryGetValue(folder, out map))
                {
                    foreach (string gname in GROUP_NAMES)
                    {
                        List<Sprite> list;
                        if (map.TryGetValue(fileName + "|" + gname, out list)) e.Groups[gname] = list;
                    }
                }
            }
            else
            {
                e.Missing = true;
                e.Base = Placeholder();
                e.W = 64; e.H = 64;
                Debug.LogWarning("[PvZ] нет спрайта: " + url + " → положи в Assets/Resources/" + res + ".png");
            }
            _cache[url] = e;
            return e;
        }

        /// <summary>Целый масштаб: мелкий арт можно увеличить, уменьшить — нельзя.</summary>
        public static int Fit(Entry e, int minSize)
        {
            int m = Mathf.Max(e.W, e.H);
            if (m <= 0 || minSize <= 0) return 1;
            return Mathf.Max(1, minSize / m);
        }

        private Sprite Placeholder()
        {
            if (_placeholder != null) return _placeholder;
            var t = new Texture2D(64, 64, TextureFormat.RGBA32, false);
            var px = new Color32[64 * 64];
            var mag = new Color32(255, 0, 255, 64);
            var edge = new Color32(255, 0, 255, 255);
            for (int y = 0; y < 64; y++)
                for (int x = 0; x < 64; x++)
                {
                    bool border = x == 0 || y == 0 || x == 63 || y == 63;
                    px[y * 64 + x] = border ? edge : mag;
                }
            t.SetPixels32(px);
            t.filterMode = FilterMode.Point;
            t.Apply();
            _placeholder = Sprite.Create(t, new Rect(0, 0, 64, 64), new Vector2(0, 1f), 1f);
            return _placeholder;
        }

        // --------------------------------------------------- рисование в SR ---
        public static Material Additive
        {
            get
            {
                if (_add == null && !_addMissing)
                {
                    // в билде шейдер может быть вырезан (stripped): тогда добавляем
                    // «Legacy Shaders/Particles/Additive» в Always Included Shaders,
                    // а пока — вспышка просто рисуется обычным спрайтовым шейдером.
                    var sh = Shader.Find("Legacy Shaders/Particles/Additive");
                    if (sh == null) sh = Shader.Find("Sprites/Default");
                    if (sh == null) { _addMissing = true; return null; }
                    _add = new Material(sh) { name = "PvzAdditive" };
                }
                return _add;
            }
        }
        private static Material _add;
        private static bool _addMissing;

        /// <summary>
        /// Поставить спрайт в SpriteRenderer: левый-верхний угол в (x,y) логических
        /// пикселей (y вниз), целый масштаб k, при необходимости — аддитивная вспышка
        /// во второй SR (её создаёт вызывающий код, см. UnitView).
        /// </summary>
        public static void Place(SpriteRenderer sr, Sprite sprite, float x, float y, int scale = 1)
        {
            if (sr == null) return;
            sr.sprite = sprite;
            sr.transform.localPosition = new Vector3(R(x), -R(y), 0f);
            sr.transform.localScale = new Vector3(scale, scale, 1f);
        }

        public static float R(double v) { return (float)System.Math.Floor(v + 0.5); }
    }
}
