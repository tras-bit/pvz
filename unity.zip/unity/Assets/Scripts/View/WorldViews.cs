// ============================================================================
//  МИР НА ЭКРАНЕ: растения, зомби, горох, солнце, косилки — ровно те же
//  формулы покачивания/вспышек/якорей, что в render.js (там комментарии,
//  зачем каждая строка). Порядок слоёв: Lawn < Plants < Mowers < Peas <
//  Zombies < Suns < Fx.
// ============================================================================
using System.Collections.Generic;
using UnityEngine;
using Pvz.Core;

namespace Pvz.View
{
    public sealed class WorldViews
    {
        private readonly SpriteLib _lib;
        private readonly Layer _lawn, _plants, _mowers, _peas, _zombies, _suns, _fx;

        private readonly ViewPool<SpriteView> _poolPlants, _poolZombies, _poolPeas, _poolSuns, _poolMowers, _poolGhost, _poolArmor;
        private readonly List<Quad> _quads = new List<Quad>();
        private int _quadUsed;

        public readonly Sprite Pixel;     // 1×1 белый — все «пиксельные» прямоугольники
        public readonly Sprite ShadowBlob;
        public readonly Sprite Ring;

        private sealed class Quad
        {
            public SpriteRenderer Sr;
            public void Set(Sprite s, double x, double y, double w, double h, Color c, string layer, int order, Transform parent, bool center = false)
            {
                if (Sr == null)
                {
                    var go = new GameObject("quad");
                    go.transform.SetParent(parent, false);
                    Sr = go.AddComponent<SpriteRenderer>();
                    Sr.sortingLayerName = layer;
                    Sr.sortingOrder = Sort.OrderFor(layer, order);
                }
                Sr.enabled = true;
                Sr.sprite = s;
                Sr.color = c;
                // w,h — размер в пикселях: для 1×1 пикселя это масштаб, для спрайтов вида
                // Ring (24×24, pivot 0.5) — масштаб = нужный размер / размер спрайта.
                double px = center ? x - w / 2 : x;
                double py = center ? y - h / 2 : y;
                double sw = s != null && s.rect.width > 0f ? s.rect.width : 1.0;
                double sh = s != null && s.rect.height > 0f ? s.rect.height : 1.0;
                Sr.transform.localPosition = new Vector3(SpriteLib.R(px), -SpriteLib.R(py), 0f);
                Sr.transform.localScale = new Vector3((float)(w / sw), (float)(h / sh), 1f);
            }
            public void Hide() { if (Sr != null) Sr.enabled = false; }
        }

        public WorldViews(SpriteLib lib, Transform root)
        {
            _lib = lib;
            _lawn = new Layer("lawn", Sort.Lawn, root);
            _plants = new Layer("plants", Sort.Plants, root);
            _mowers = new Layer("mowers", Sort.Mowers, root);
            _peas = new Layer("peas", Sort.Peas, root);
            _zombies = new Layer("zombies", Sort.Zombies, root);
            _suns = new Layer("suns", Sort.Suns, root);
            _fx = new Layer("fx", Sort.Fx, root);

            _poolPlants = new ViewPool<SpriteView>(() => new SpriteView("plant", _plants, 0));
            _poolZombies = new ViewPool<SpriteView>(() => new SpriteView("zombie", _zombies, 0));
            _poolPeas = new ViewPool<SpriteView>(() => new SpriteView("pea", _peas, 0, false, false));
            _poolSuns = new ViewPool<SpriteView>(() => new SpriteView("sun", _suns, 0, false, false));
            _poolMowers = new ViewPool<SpriteView>(() => new SpriteView("mower", _mowers, 0));
            _poolGhost = GhostPool(_plants, -2);
            _poolArmor = new ViewPool<SpriteView>(() => new SpriteView("armor", _zombies, 2, false, false));

            Pixel = MakePixel();
            ShadowBlob = MakeBlob();
            Ring = MakeRing();
        }

        private static ViewPool<SpriteView> GhostPool(Layer l, int order)
        {
            return new ViewPool<SpriteView>(() => new SpriteView("ghost", l, order, false, false));
        }

        // ------------------------------------------------------------- примитивы
        private static Sprite MakePixel()
        {
            var t = new Texture2D(1, 1, TextureFormat.RGBA32, false);
            t.SetPixel(0, 0, Color.white);
            t.filterMode = FilterMode.Point;
            t.Apply();
            return Sprite.Create(t, new Rect(0, 0, 1, 1), new Vector2(0f, 1f), 1f);
        }

        private static Sprite MakeBlob()
        {
            int w = 32, h = 8;
            var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
            var px = new Color32[w * h];
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                {
                    double dx = (x - (w - 1) / 2.0) / (w / 2.0);
                    double dy = (y - (h - 1) / 2.0) / (h / 2.0);
                    float v = (float)(1.0 - System.Math.Min(1.0, dx * dx + dy * dy));
                    px[y * w + x] = new Color32(12, 42, 8, (byte)(255 * Mathf.Clamp01(v * v * 2.2f)));
                }
            t.SetPixels32(px);
            t.filterMode = FilterMode.Point;
            t.Apply();
            return Sprite.Create(t, new Rect(0, 0, w, h), new Vector2(0.5f, 0.5f), 1f);
        }

        private static Sprite MakeRing()
        {
            int s = 24;
            var t = new Texture2D(s, s, TextureFormat.RGBA32, false);
            var px = new Color32[s * s];
            float cx = (s - 1) / 2f, cy = (s - 1) / 2f, r = s * 0.38f;
            for (int y = 0; y < s; y++)
                for (int x = 0; x < s; x++)
                {
                    float d = Mathf.Abs(Mathf.Sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) - r);
                    px[y * s + x] = d <= 1.1f ? new Color32(255, 255, 255, 255) : new Color32(0, 0, 0, 0);
                }
            t.SetPixels32(px);
            t.filterMode = FilterMode.Point;
            t.Apply();
            return Sprite.Create(t, new Rect(0, 0, s, s), new Vector2(0.5f, 0.5f), 1f);
        }

        private Quad NextQuad()
        {
            while (_quads.Count <= _quadUsed) _quads.Add(new Quad());
            return _quads[_quadUsed++];
        }

        private void Q(Sprite s, double x, double y, double w, double h, Color c, string layer, int order, Transform parent)
        {
            NextQuad().Set(s, x, y, w, h, c, layer, order, parent);
        }

        /// <summary>То же, но x,y — центр (для спрайтов с пивотом 0.5).</summary>
        private void Qc(Sprite s, double cx, double cy, double w, double h, Color c, string layer, int order, Transform parent)
        {
            NextQuad().Set(s, cx, cy, w, h, c, layer, order, parent, true);
        }

        // ------------------------------------------------------------------ кадр
        public void BeginFrame()
        {
            _poolPlants.Reset(); _poolZombies.Reset(); _poolPeas.Reset();
            _poolSuns.Reset(); _poolMowers.Reset(); _poolGhost.Reset();
            _poolArmor.Reset();           // а то конусы последних кадров так и висят на газоне
            _quadUsed = 0;
        }

        public void EndFrame()
        {
            for (int i = _quadUsed; i < _quads.Count; i++) _quads[i].Hide();
        }

        /// <summary>Подсветка клетки под курсором + «призрачное» растение (drawPlacement).</summary>
        public void DrawPlacement(World w, UiState ui, double clock)
        {
            if (ui.Selected == null || !ui.HoverValid) return;
            int row = ui.HoverRow, col = ui.HoverCol;
            if (!Geo.InLawn(row, col)) return;
            bool ok = w.CanPlant(row, col, ui.Selected) == Fail.None;
            float x = Geo.LAWN_X + col * Geo.TILE, y = Geo.LAWN_Y + row * Geo.TILE;
            double pulse = 0.5 + 0.5 * System.Math.Sin(clock * 7);
            var fill = ok ? new Color(0.55f, 0.94f, 0.48f, (float)(0.2 + pulse * 0.14)) : new Color(1f, 0.48f, 0.42f, 0.26f);
            var line = ok ? Pal.C(Pal.OK) : Pal.C(Pal.NO);
            Q(Pixel, x, y, Geo.TILE, Geo.TILE, fill, Sort.Lawn, 5, _lawn.Tr);
            Q(Pixel, x + 1, y + 1, Geo.TILE - 3, 3, line, Sort.Lawn, 6, _lawn.Tr);
            Q(Pixel, x + 1, y + Geo.TILE - 4, Geo.TILE - 3, 3, line, Sort.Lawn, 6, _lawn.Tr);
            Q(Pixel, x + 1, y + 1, 3, Geo.TILE - 3, line, Sort.Lawn, 6, _lawn.Tr);
            Q(Pixel, x + Geo.TILE - 4, y + 1, 3, Geo.TILE - 3, line, Sort.Lawn, 6, _lawn.Tr);

            var def = CFG.Plant(ui.Selected);
            var e = _lib.Get(def.Sprite);
            int k = SpriteLib.Fit(e, 0);
            float dw = e.W * k, dh = e.H * k;
            var ghost = _poolGhost.Next();
            ghost.Begin(x + (Geo.TILE - dw) / 2f + def.Draw.Dx, y + Geo.TILE - dh + def.Draw.Dy);
            ghost.Put(e.Base, ghost.LastAx, ghost.LastAy, k, 0.85f, Color.white, 0f);
        }

        /// <summary>Кадр по стадии расколотой скорлупы — то же, что ZombieEntry для зомби:
        /// нет файла, молча остаёмся на базовом (орех не должен превращаться в магента-плашку).</summary>
        private SpriteLib.Entry PlantEntry(Plant p)
        {
            var e = _lib.Get(p.Def.Sprite);
            var list = p.Def.Dmg;
            for (int i = 0; i < list.Count && i < p.Stage; i++)
            {
                var alt = _lib.Get(list[i].Sprite);
                if (alt != null && !alt.Missing) e = alt;
            }
            return e;
        }

        public void DrawPlants(World w)
        {
            foreach (var p in w.Plants)
            {
                var e = PlantEntry(p);
                int k = SpriteLib.Fit(e, 0);
                float dw = e.W * k, dh = e.H * k;
                double bob = System.Math.Round(System.Math.Sin((w.Time + p.Id * 0.7) * 2.2) * 1);
                float dx = 0;
                if (p.Recoil > 0) dx -= (float)System.Math.Round(p.Recoil * 26);
                if (p.Hurt > 0) dx += (float)System.Math.Round(System.Math.Sin(p.Hurt * 90) * 1.5);
                // треснула скорлупа — дёрнулся всем телом: тот же толчок, что у зомби при потере куска
                if (p.LimbT > 0) dx += (float)System.Math.Round(System.Math.Sin(p.LimbT * 52) * 2);
                double left = p.X + (Geo.TILE - dw) / 2 + p.Def.Draw.Dx + dx;
                double top = p.Y + Geo.TILE - dh + p.Def.Draw.Dy + bob;

                var v = _poolPlants.Next();
                v.Begin(left, top);
                v.Shadow(ShadowBlob, p.X + Geo.TILE / 2f - left, p.Y + Geo.TILE - 4 - top, 16, 4, 0.2f);
                // цикл активности: хищник жуёт (3 кадра пасти, медленно), стреляет или
                // отдаёт солнце — 2 кадра. Подсолнух «отдаёт» по таймеру produce: своего
                // поля-вспышки у него нет, и заводить его в ядре ради анимации незачем.
                string group = "idle";
                double pfps = 0;
                bool chewing = p.Def.Chomp != null && p.ChewTimer > 0;
                if (chewing)
                {
                    // те же две фазы, что в js/render.js: 0.9 с выпадa ('eat'), потом
                    // сидит и пережёвывает ('chew', 4 кадра по 2 в секунду)
                    bool grab = p.ChewTimer > p.Def.Chomp.Chew - 0.9;
                    if (grab && e.Group("eat") != null) { group = "eat"; pfps = 3.4; }
                    else if (e.Group("chew") != null) { group = "chew"; pfps = 2.0; }
                    else if (e.Group("eat") != null) { group = "eat"; pfps = 2.0; }
                }
                else if (p.Recoil > 0 && e.Group("shoot") != null) group = "shoot";
                else if (p.Def.Produce != null && p.Def.Produce.Interval > 0
                         && p.ProduceTimer > p.Def.Produce.Interval - 0.5 && e.Group("shoot") != null) group = "shoot";
                var spr = e.Pick(group, w.Time + p.Id * 0.37, pfps);
                float flash = p.Hurt > 0 ? 0.1f + 0.2f * (float)System.Math.Abs(System.Math.Sin(p.Hurt * 55)) : 0f;
                Color tint = Color.white;
                if (chewing)
                {
                    // жуёт: оседает к земле, тон становится кислее по мере пережёвывания,
                    // мигание идёт в такт кадрам челюстей, а не отдельно от них
                    double c = System.Math.Min(1.0, p.ChewTimer / System.Math.Max(1.0, p.Def.Chomp.Chew));
                    double cyc = (w.Time + p.Id * 0.37) * pfps;
                    flash = System.Math.Max(flash, 0.08f + 0.1f * (float)System.Math.Abs(System.Math.Sin(cyc * System.Math.PI)));
                    tint = new Color(1f, 1f - 0.22f * (float)c, 1f - 0.06f * (float)c);
                    top += group == "chew" ? 2 : 1;
                }
                if (p.Def.Explode != null && p.Fuse > 0)
                {
                    // фитиль: чем ближе к бабаху, тем сильнее красное мигание
                    double f = p.Fuse;
                    flash = System.Math.Max(flash, (float)(0.15 + 0.75 * f * System.Math.Abs(System.Math.Sin(f * 26.0))));
                    float ft = (float)(f * 0.65);                  // красный по мере сгорания фитиля
                    tint = new Color(1f, 1f - 0.55f * ft, 1f - 0.8f * ft);
                    if (f > 0.72) top -= 1;                       // и чуть набухает перед взрывом
                }
                v.Put(spr, left, top, k, 1f, tint, flash);
                DrawBites(p, left, top, k);
            }
        }

        /// <summary>Чем меньше HP ореха, тем больше укусов: тёмный скол + светлый
        /// обломок по краю. Позиции — из конфига (пиксели спрайта), поэтому Canvas и
        /// Unity рисуют их на одних и тех же местах.</summary>
        private void DrawBites(Plant p, double left, double top, float k)
        {
            var marks = p.Def.Bites;
            int n = p.Bites;
            if (marks.Count == 0 || n <= 0) return;
            var ink = Pal.C("#151113");
            var chip = Pal.C("#f0e0a8");
            var edge = Pal.C("#7c5a1c");
            for (int i = 0; i < n && i < marks.Count; i++)
            {
                var m = marks[i];
                float x = (float)(left + System.Math.Round(m.X * k));
                float y = (float)(top + System.Math.Round(m.Y * k));
                float w = System.Math.Max(2f, (float)System.Math.Round(m.W * k));
                float h = System.Math.Max(2f, (float)System.Math.Round(m.H * k));
                float lip = System.Math.Max(1f, k);
                Q(Pixel, x, y, w, h, ink, Sort.Plants, 6, _plants.Tr);
                Q(Pixel, x, y - lip, w - k, lip, chip, Sort.Plants, 7, _plants.Tr);
                Q(Pixel, x + w, y + 1, System.Math.Max(1f, k), System.Math.Max(1f, h - 2), edge, Sort.Plants, 7, _plants.Tr);
            }
        }

        public void DrawMowers(World w)
        {
            var e = _lib.Get(CFG.MOWER.Sprite);
            int k = SpriteLib.Fit(e, 0);
            float dw = e.W * k, dh = e.H * k;
            foreach (var m in w.Mowers)
            {
                bool running = m.State == "run";
                float y = SpriteLib.R(m.GroundY - dh) + (running ? (float)System.Math.Round(System.Math.Sin(m.Spin * 1.7)) : 0f);
                float x = SpriteLib.R(m.X);
                var v = _poolMowers.Next();
                v.Begin(x, y);
                v.Shadow(ShadowBlob, dw / 2f, -3, dw * 0.4f, 4, 0.22f);
                float flash = running ? 0.1f + 0.1f * (float)System.Math.Abs(System.Math.Sin(m.Spin * 3)) : 0f;
                v.Put(e.Base, x, y, k, 1f, Pal.C("#fff2b0"), flash);
                if (!running) continue;
                for (int i = 0; i < 3; i++)      // травинки из-под ножей
                {
                    var c = (i % 2 == 1 ? Pal.C(Pal.GRASS_BLADE) : Pal.C(Pal.GRASS_A));
                    float gx = x - 3 - i * 4;
                    float gy = y + dh - 6 + (float)System.Math.Round(System.Math.Sin(m.Spin + i * 2) * 3);
                    Q(Pixel, gx, gy, 2, 2, c, Sort.Mowers, 3, _mowers.Tr);
                }
            }
        }

        public void DrawZombies(World w)
        {
            foreach (var z in w.Zombies)
            {
                var e = ZombieEntry(z);
                int k = SpriteLib.Fit(e, 0);
                float dw = e.W * k, dh = e.H * k;
                bool dying = z.State == "die";
                bool hasDeath = e.Group("death") != null;
                float jolt = z.LimbT > 0 ? (float)System.Math.Round(System.Math.Sin(z.LimbT * 46) * 2) : 0f;
                // шаг — 4 кадра и медленно (2.4/с ≈ 1.7 с на цикл): с двумя кадрами на
                // 6 fps зомби не шёл, а дрожжи. bob/lurch привязаны к тому же циклу.
                double wf = dying ? 4.0 : (z.State == "eat" ? 2.2 : 2.4);
                double zoff = z.Id * 0.29;
                double cyc = (w.Time + zoff) * wf;
                // приседание уже в кадрах шага (dip в арте), второй пиксель сверху
                // дал бы тряску вместо шага — поэтому bob только если групп нет
                float bob = (dying || e.Group("walk") != null)
                    ? 0f : (float)System.Math.Round(System.Math.Sin(cyc * System.Math.PI / 2) * 1);
                float lurch = z.State == "eat" ? (float)System.Math.Round(System.Math.Sin(cyc * System.Math.PI / 2) * 2) : 0f;
                double x = z.X - dw / 2 + z.Def.Draw.Dx + lurch + jolt;
                double y = z.FootY - dh + z.Def.Draw.Dy + bob + (dying && !hasDeath ? System.Math.Round(z.DieT * 34) : 0.0);
                float alpha = dying ? Mathf.Clamp01(1f - (float)(z.DieT / 0.7)) : 1f;
                double t = dying
                    ? System.Math.Min(z.DieT, ((e.Group("death") != null ? e.Group("death").Count : 1) - 0.05) / 4.0)
                    : w.Time + zoff;
                double fps = wf;
                var spr = e.Pick(dying ? "death" : z.State, t, fps);
                float angle = dying && !hasDeath ? (float)(z.DieT * 1.5 * Mathf.Rad2Deg) : 0f;

                var v = _poolZombies.Next();
                v.Begin(z.X, z.FootY, angle);                       // якорь — ноги: падать вокруг них
                v.Shadow(ShadowBlob, z.X - v.LastAx, z.FootY - 3 - v.LastAy, dw * 0.3f, 4, 0.24f);
                v.Put(spr, x, y, k, alpha, Color.white, z.Hurt > 0 ? 0.5f : 0f);

                // броня (конус): тем же якорем, спрайт уже нарисован в канве 64×64
                var av = _poolArmor.Next();
                av.Begin(z.X, z.FootY, angle);
                Sprite aspr = null;
                if (z.ArmorHp > 0 && !dying)
                {
                    string path = z.ArmorRatio >= z.Def.ArmorAt ? z.Def.ArmorSprite : z.Def.ArmorSpriteDmg;
                    var ae = _lib.Get(path);
                    if (ae != null && !ae.Missing) aspr = ae.Pick("idle", w.Time + zoff, fps);
                }
                av.Put(aspr, x, y, k, alpha, Color.white, z.Hurt > 0 ? 0.4f : 0f);
            }
        }

        /// <summary>Кадр по стадии расчленёнки: нет файла — остаёмся на базовом (как zombieSprite в JS).</summary>
        private SpriteLib.Entry ZombieEntry(Zombie z)
        {
            var e = _lib.Get(z.Def.Sprite);
            for (int i = 0; i < z.Def.Dmg.Count && i < z.Stage; i++)
            {
                var alt = _lib.Get(z.Def.Dmg[i].Sprite);
                if (!alt.Missing) e = alt;
            }
            return e;
        }

        public void DrawPeas(World w)
        {
            var e = _lib.Get(CFG.PEA.Sprite);
            int k = SpriteLib.Fit(e, CFG.PEA.MinSize);
            float dw = e.W * k, dh = e.H * k;
            foreach (var pea in w.Peas)
            {
                var v = _poolPeas.Next();
                v.Begin(pea.X - dw / 2f, pea.Y - dh / 2f);
                v.Put(e.Base, v.LastAx, v.LastAy, k, 1f, Color.white, 0f);
                Q(Pixel, pea.X - dw / 2f - 5, pea.Y - 1, 3, 2, new Color(0.8f, 0.94f, 0.48f, 0.85f), Sort.Peas, 1, _peas.Tr);
                Q(Pixel, pea.X - dw / 2f - 10, pea.Y, 2, 2, new Color(0.8f, 0.94f, 0.48f, 0.45f), Sort.Peas, 1, _peas.Tr);
            }
        }

        public void DrawSuns(World w)
        {
            var e = _lib.Get(CFG.SUN.Sprite);
            int k = SpriteLib.Fit(e, CFG.SUN.MinSize);
            float dw = e.W * k, dh = e.H * k;
            float rad = Mathf.Max(dw, dh) / 2f;
            foreach (var sun in w.Suns)
            {
                // Никакого мягкого glow: вместо него — жёсткая тень там, где солнце
                // ляжет, и она густеет по мере приближения к земле.
                double near = System.Math.Max(0, System.Math.Min(1, 1 - (sun.RestY - sun.Y) / 96.0));
                float bob = (float)(System.Math.Sin(sun.Spin * 2) * 1.2);
                double left = sun.X - dw / 2, top = sun.Y - dh / 2 + bob;
                var v = _poolSuns.Next();
                v.Begin(left, top);
                v.Shadow(ShadowBlob, sun.X - left, sun.RestY + rad * 0.7f - top, rad * 0.8f, rad * 0.32f,
                         (float)(sun.Fade * 0.3 * near));
                v.Put(e.Base, left, top, k, sun.Fade, Color.white, 0f);
                if (sun.State == "rest" && sun.Life < 3.2)      // «возьми меня» перед исчезновением
                {
                    float a = (float)(0.35 + 0.4 * System.Math.Abs(System.Math.Sin(sun.Spin * 6)));
                    float rr = rad * 0.72f * 2f;
                    Qc(Ring, sun.X, sun.Y + bob, rr, rr, new Color(1, 1, 1, a * 0.9f), Sort.Suns, -1, _suns.Tr);
                }
            }
        }

        /// <summary>Растение «в руке» при перетаскивании (drawDragged).</summary>
        public void DrawDragged(World w, UiState ui)
        {
            if (!ui.DragActive || !ui.DragMoved || !ui.HasMouse) return;
            var def = CFG.Plant(ui.DragType);
            if (def == null) return;
            var e = _lib.Get(def.Sprite);
            int k = SpriteLib.Fit(e, 0);
            float dw = e.W * k, dh = e.H * k;
            bool ok = ui.HoverValid && w.CanPlant(ui.HoverRow, ui.HoverCol, ui.DragType) == Fail.None;
            var v = _poolGhost.Next();
            float left = SpriteLib.R(ui.MouseX - dw / 2f), top = SpriteLib.R(ui.MouseY - dh * 0.68f);
            v.Begin(left, top);
            v.Put(e.Base, left, top, k, 0.95f, Pal.C("#ff5a3a"), ok ? 0f : 0.42f);
        }
    }

    /// <summary>То, что знает UI, но не мир (курсор/ховер/что в руке).</summary>
    public sealed class UiState
    {
        public string Selected;
        public bool Shovel;               // лопата взята в руку (клик по растению её выкопает)
        public double Clock;
        public bool HasMouse;
        public float MouseX, MouseY;
        public int HoverRow, HoverCol;
        public bool HoverValid;
        public bool DragActive, DragMoved;
        public string DragType;
        public string HoveredCard;
        public bool MouseDown;
        public Vector2 DragDown;
        public string TipText;
    }
}
