// ============================================================================
//  СЦЕНА: слои сортировки, просматриваемые пачки SpriteRenderer'ов.
//  Один SpriteView = якорь (можно повернуть вокруг ног) + сам спрайт +
//  аддитивная вспышка (аналог globalCompositeOperation='lighter' в canvas) +
//  мягкая тень-пятно под юнитом.
// ============================================================================
using System.Collections.Generic;
using UnityEngine;

namespace Pvz.View
{
    public static class Sort
    {
        public const string Lawn = "10_Lawn";
        public const string Mowers = "20_Mowers";
        public const string Plants = "30_Plants";
        public const string Peas = "40_Peas";
        public const string Zombies = "50_Zombies";
        public const string Suns = "60_Suns";
        public const string Fx = "70_Fx";
        public const string Hud = "80_Hud";
        public const string Overlay = "90_Overlay";
        public static readonly string[] All = { Lawn, Mowers, Plants, Peas, Zombies, Suns, Fx, Hud, Overlay };

        /// <summary>
        /// Порядок внутри слоя. Старшим разрядом служит индекс слоя, поэтому порядок
        /// рисования правильный, даже если sorting layers не заведены в ProjectSettings
        /// (PvZBootstrapper их заводит, но полагаться на это не стоит).
        /// </summary>
        public static int OrderFor(string layer, int off)
        {
            int i = System.Array.IndexOf(All, layer);
            return (i < 0 ? 0 : (i + 1) * 1000) + off;
        }
    }

    public sealed class Layer
    {
        public readonly GameObject Go;
        public readonly Transform Tr;
        public readonly string Sorting;
        public readonly int Order;

        public Layer(string name, string sortingLayer, Transform parent, int order = 0)
        {
            Go = new GameObject(name);
            Go.transform.SetParent(parent, false);
            Tr = Go.transform;
            Sorting = sortingLayer;
            Order = Sort.OrderFor(sortingLayer, order);
        }
    }

    /// <summary>Один юнит на экране. Якорь задан в логических пикселях (y вниз).</summary>
    public class SpriteView
    {
        public readonly GameObject Go;
        private readonly SpriteRenderer _sr;
        private readonly SpriteRenderer _glow;
        private readonly SpriteRenderer _shadow;
        private double _ax, _ay;
        public double LastAx { get { return _ax; } }
        public double LastAy { get { return _ay; } }

        public SpriteView(string name, Layer layer, int orderOffset, bool shadow = true, bool glow = true)
        {
            Go = new GameObject(name);
            Go.transform.SetParent(layer.Tr, false);
            _sr = Make("spr", layer.Sorting, layer.Order + orderOffset);
            if (glow) { _glow = Make("glow", layer.Sorting, layer.Order + orderOffset + 1); _glow.sharedMaterial = SpriteLib.Additive; _glow.enabled = false; }
            if (shadow) { _shadow = Make("shadow", layer.Sorting, layer.Order + orderOffset - 1); _shadow.enabled = false; }
        }

        private SpriteRenderer Make(string child, string layer, int order)
        {
            var go = new GameObject(child);
            go.transform.SetParent(Go.transform, false);
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sortingLayerName = layer;
            sr.sortingOrder = order;
            return sr;
        }

        public SpriteRenderer Main { get { return _sr; } }
        public Transform Tr { get { return Go.transform; } }
        public bool Visible { get { return Go.activeSelf; } set { Go.SetActive(value); } }

        public void Begin(double anchorX, double anchorY, double angleDeg = 0.0)
        {
            _ax = anchorX; _ay = anchorY;
            Go.transform.position = new Vector3(SpriteLib.R(anchorX), -SpriteLib.R(anchorY), 0f);
            Go.transform.rotation = System.Math.Abs(angleDeg) < 0.01
                ? Quaternion.identity
                : Quaternion.Euler(0f, 0f, (float)-angleDeg);          // y вниз → знак инвертируем
        }

        public void Put(Sprite sprite, double left, double top, int scale, double alpha, Color flash, double flashK,
                        Color? flashColor = null)
        {
            _sr.enabled = sprite != null && alpha > 0.01;
            _sr.sprite = sprite;
            _sr.color = new Color(1f, 1f, 1f, (float)alpha);
            _sr.transform.localPosition = Off(left, top);
            _sr.transform.localScale = new Vector3(scale, scale, 1f);

            if (_glow != null)
            {
                bool on = sprite != null && flashK > 0.001f;
                _glow.enabled = on;
                if (on)
                {
                    var c = flashColor ?? Color.white;
                    _glow.sprite = sprite;
                    _glow.color = new Color(c.r, c.g, c.b, Mathf.Min(0.6f, (float)flashK));
                    _glow.transform.localPosition = _sr.transform.localPosition;
                    _glow.transform.localScale = _sr.transform.localScale;
                }
            }
        }

        /// <summary>Тень-пятно под юнитом (contactShadow в JS).</summary>
        public void Shadow(Sprite blob, double cx, double cy, double rx, double ry, double alpha)
        {
            if (_shadow == null) return;
            bool on = blob != null && alpha > 0.01;
            _shadow.enabled = on;
            if (!on) return;
            _shadow.sprite = blob;
            _shadow.color = new Color(1f, 1f, 1f, (float)alpha);
            _shadow.transform.localPosition = Off(cx, cy);
            _shadow.transform.localScale = new Vector3((float)(rx * 2 / blob.rect.width), (float)(ry * 2 / blob.rect.height), 1f);
        }

        private Vector3 Off(double left, double top)
        {
            return new Vector3(SpriteLib.R(left - _ax), -SpriteLib.R(top - _ay), 0f);
        }

        public void Hide() { Go.SetActive(false); }
        public void Show() { Go.SetActive(true); }
        public void Destroy() { if (Go != null) Object.Destroy(Go); }
    }

    /// <summary>Слой, на котором лежит запечённый Tex (фон, HUD, экраны).</summary>
    public sealed class TexLayer
    {
        public Tex Tex;
        public readonly SpriteRenderer Sr;
        private readonly GameObject _go;
        private int _w, _h;

        public TexLayer(string name, Layer parent, int orderOffset = 0)
        {
            _go = new GameObject(name);
            _go.transform.SetParent(parent.Tr, false);
            Sr = _go.AddComponent<SpriteRenderer>();
            Sr.sortingLayerName = parent.Sorting;
            Sr.sortingOrder = parent.Order + orderOffset;
        }

        public void Ensure(int w, int h)
        {
            if (Tex != null && _w == w && _h == h) return;
            if (Tex != null) Tex.Dispose();
            _w = w; _h = h;
            Tex = new Tex(w, h);
        }

        /// <summary>Перезалить буфер в текстуру.</summary>
        public void Present()
        {
            Tex.Apply();
            Sr.sprite = Tex.Sprite;
            Sr.transform.localPosition = new Vector3(0f, 0f, 0f);
            Sr.enabled = true;
        }

        public void Hide() { Sr.enabled = false; }
    }

    /// <summary>Пул одно-пиксельных прямоугольников: частицы, вспышки, подсветки.</summary>
    public sealed class QuadPool
    {
        private sealed class Item { public SpriteRenderer Sr; }
        private readonly List<Item> _items = new List<Item>();
        private int _used;
        private readonly Sprite _px;
        private readonly Transform _parent;
        private readonly string _layer;
        private readonly int _order;

        public QuadPool(Sprite pixel, Transform parent, string layer, int order)
        {
            _px = pixel; _parent = parent; _layer = layer; _order = Sort.OrderFor(layer, order);
        }

        public void Begin() { _used = 0; }

        public void End() { for (int i = _used; i < _items.Count; i++) _items[i].Sr.enabled = false; }

        public void Q(float x, float y, float w, float h, Color c)
        {
            while (_items.Count <= _used)
            {
                var go = new GameObject("q");
                go.transform.SetParent(_parent, false);
                var sr = go.AddComponent<SpriteRenderer>();
                sr.sprite = _px;
                sr.sortingLayerName = _layer;
                sr.sortingOrder = _order;
                _items.Add(new Item { Sr = sr });
            }
            var it = _items[_used++];
            it.Sr.enabled = true;
            it.Sr.color = c;
            it.Sr.transform.localPosition = new Vector3(SpriteLib.R(x), -SpriteLib.R(y), 0f);
            it.Sr.transform.localScale = new Vector3(Mathf.Max(1, w), Mathf.Max(1, h), 1f);
        }

        /// <summary>x,y — центр.</summary>
        public void Qc(float cx, float cy, float w, float h, Color c) { Q(cx - w / 2f, cy - h / 2f, w, h, c); }
    }

    /// <summary>Просматриваемая пачка: берёт вьюху по индексу, лишние прячет.</summary>
    public sealed class ViewPool<T> where T : SpriteView
    {
        private readonly List<T> _items = new List<T>();
        private readonly System.Func<T> _factory;
        public int Used;

        public ViewPool(System.Func<T> factory) { _factory = factory; }

        public T Next()
        {
            if (Used >= _items.Count) _items.Add(_factory());
            var v = _items[Used];
            Used++;
            v.Show();
            return v;
        }

        public void Reset()
        {
            for (int i = Used; i < _items.Count; i++) _items[i].Hide();
            Used = 0;
        }

        public void Clear() { Used = 0; }
    }
}
