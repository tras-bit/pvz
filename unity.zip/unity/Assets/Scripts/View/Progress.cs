// ============================================================================
//  ПРОГРЕСС: какие растения и инструменты открыты и какой уровень доступен. Как в оригинале:
//  1-1 начинается с одного горохострела, а награды приходят по одной за уровень —
//  подсолнух за 1-1, вишня за 1-2 (LevelDef.Rewards). Хранится в PlayerPrefs,
//  переживает выход из игры. Пачка семян уровня = LevelDef.Seeds ∩ Plants().
//
//  Сбросить: PvZ → Сбросить прогресс (или Edit → Clear All Player Prefs).
// ============================================================================
using System.Collections.Generic;
using UnityEngine;
using Pvz.Core;

namespace Pvz.View
{
    public static class Progress
    {
        private const string KPlants = "pvz.plants";
        private const string KLevel = "pvz.level";       // сколько уровней пройдено
        private const string KTools = "pvz.tools";       // инструменты (лопата) — не растения
        private static readonly string[] ToolNames_ = { "shovel" };
        private static readonly string[] Starter = { "peashooter" };

        /// <summary>Открытые растения (всегда с горохострелом — стартовый).</summary>
        public static List<string> Plants()
        {
            var list = new List<string>(Starter);
            string raw = PlayerPrefs.GetString(KPlants, "");
            if (!string.IsNullOrEmpty(raw))
            {
                foreach (string id in raw.Split(','))
                {
                    if (id.Length == 0 || id == "peashooter") continue;
                    if (CFG.Plant(id) != null && !list.Contains(id)) list.Add(id);
                }
            }
            return list;
        }

        public static bool Has(string plantId)
        {
            if (plantId == "peashooter") return true;
            string raw = PlayerPrefs.GetString(KPlants, "");
            return ("," + raw + ",").Contains("," + plantId + ",");
        }

        public static int LevelsDone { get { return PlayerPrefs.GetInt(KLevel, 0); } }

        // --- инструменты (лопата). Отдельно от растений: в пачку семян не попадают ---

        /// <summary>Открытые инструменты уровня (пока это только лопата).</summary>
        public static List<string> Tools()
        {
            var list = new List<string>();
            string raw = PlayerPrefs.GetString(KTools, "");
            if (!string.IsNullOrEmpty(raw))
                foreach (string id in raw.Split(','))
                    if (id.Length > 0 && !list.Contains(id)) list.Add(id);
            return list;
        }

        public static bool HasTool(string id)
        {
            string raw = PlayerPrefs.GetString(KTools, "");
            return ("," + raw + ",").Contains("," + id + ",");
        }

        public static bool GrantTools(IEnumerable<string> ids)
        {
            var cur = new List<string>();
            string raw = PlayerPrefs.GetString(KTools, "");
            if (!string.IsNullOrEmpty(raw)) cur.AddRange(raw.Split(','));
            bool changed = false;
            foreach (string id in ids)
            {
                if (string.IsNullOrEmpty(id) || cur.Contains(id)) continue;
                if (System.Array.IndexOf(ToolNames_, id) < 0) continue;      // неизвестного не заводим
                cur.Add(id);
                changed = true;
            }
            if (changed) PlayerPrefs.SetString(KTools, string.Join(",", cur.ToArray()));
            return changed;
        }

        /// <summary>Как показывать инструмент на экране победы («ЛОПАТА»).</summary>
        public static string ToolName(string id)
        {
            if (id == "shovel") return "ЛОПАТА";
            return id.ToUpperInvariant();
        }

        /// <summary>Уровень i доступен? (первый — всегда; остальные — после прохождения предыдущего)</summary>
        public static bool LevelOpen(int i) { return i == 0 || i <= LevelsDone; }

        /// <summary>Победа на уровне: открываем следующий и выдаём награды.</summary>
        public static bool Won(int levelIndex, LevelDef level)
        {
            bool changed = false;
            if (levelIndex + 1 > LevelsDone)
            {
                PlayerPrefs.SetInt(KLevel, levelIndex + 1);
                changed = true;
            }
            if (level != null && level.Rewards != null && level.Rewards.Count > 0)
                changed |= Grant(level.Rewards);
            if (level != null && level.Tools != null && level.Tools.Count > 0)
                changed |= GrantTools(level.Tools);        // лопата за 1-1 — тоже награда
            PlayerPrefs.Save();
            return changed;
        }

        public static bool Grant(IEnumerable<string> plantIds)
        {
            var cur = new List<string>();
            string raw = PlayerPrefs.GetString(KPlants, "");
            if (!string.IsNullOrEmpty(raw)) cur.AddRange(raw.Split(','));
            bool changed = false;
            foreach (string id in plantIds)
            {
                if (string.IsNullOrEmpty(id) || id == "peashooter" || cur.Contains(id)) continue;
                if (CFG.Plant(id) == null) continue;
                cur.Add(id);
                changed = true;
            }
            if (changed) PlayerPrefs.SetString(KPlants, string.Join(",", cur.ToArray()));
            return changed;
        }

        public static void Reset()
        {
            PlayerPrefs.DeleteKey(KPlants);
            PlayerPrefs.DeleteKey(KTools);
            PlayerPrefs.DeleteKey(KLevel);
            PlayerPrefs.Save();
        }

        /// <summary>Как назвать награды на экране победы («ПОДСОЛНУХ»).</summary>
        public static string RewardNames(LevelDef level)
        {
            if (level == null || level.Rewards == null) return "";
            var names = new List<string>();
            for (int i = 0; i < level.Rewards.Count; i++)
            {
                var d = CFG.Plant(level.Rewards[i]);
                if (d != null) names.Add(d.Name.ToUpperInvariant());
            }
            return string.Join(", ", names.ToArray());
        }

        /// <summary>Названия инструментов уровня для экрана победы.</summary>
        public static string ToolNames(LevelDef level)
        {
            if (level == null || level.Tools == null) return "";
            var names = new List<string>();
            for (int i = 0; i < level.Tools.Count; i++) names.Add(ToolName(level.Tools[i]));
            return string.Join(", ", names.ToArray());
        }
    }
}
