// ============================================================================
//  ЭФФЕКТЫ: частицы, куски тела, кольца, «+50» над банком, тряска.
//  Перенос js/fx.js: та же физика и те же размеры, но квадратными блоками —
//  сглаженный круг на пиксель-арте выглядел как мыльное пятно.
// ============================================================================
using System.Collections.Generic;
using UnityEngine;
using Pvz.Core;

namespace Pvz.View
{
    public sealed class FxView
    {
        private struct Part { public float x, y, vx, vy, g, life, t, size; public Color32 color; }
        private struct Puff { public float x, y, r, t, life; public Color32 color; }
        private struct Chunk { public float x, y, vx, vy, g, w, h, a, va, life, t, ground; public Color32 color; }
        private struct Ring { public float x, y, t, life; public Color32 color; }
        private struct FloatText { public float x, y, vy, life, t, size; public string str; public Color32 color; }

        private readonly List<Part> _parts = new List<Part>();
        private readonly List<Puff> _puffs = new List<Puff>();
        private readonly List<Chunk> _limbs = new List<Chunk>();
        private readonly List<Ring> _rings = new List<Ring>();
        private readonly List<FloatText> _texts = new List<FloatText>();

        public float Shake;

        private readonly SpriteLib _lib;

        public FxView(SpriteLib lib)
        {
            _lib = lib;
        }

        public void Burst(double x, double y, Color32 color, int n = 8, float speed = 90f, float size = 3f, float g = 220f)
        {
            for (int i = 0; i < n; i++)
            {
                float a = Random.value * Mathf.PI * 2f;
                float s = speed * (0.35f + Random.value * 0.65f);
                _parts.Add(new Part
                {
                    x = (float)x, y = (float)y,
                    vx = Mathf.Cos(a) * s, vy = Mathf.Sin(a) * s - 30f,
                    g = g, life = 0.35f + Random.value * 0.4f, t = 0f, size = size, color = color,
                });
            }
        }

        public void SoilPuff(double x, double y)
        {
            for (int i = 0; i < 10; i++)
            {
                float a = -Mathf.PI / 2f + (Random.value - 0.5f) * 2.2f;
                float s = 40f + Random.value * 70f;
                _parts.Add(new Part
                {
                    x = (float)x + (Random.value - 0.5f) * Geo.TILE * 0.6f, y = (float)y,
                    vx = Mathf.Cos(a) * s, vy = Mathf.Sin(a) * s, g = 260f,
                    life = 0.3f + Random.value * 0.25f, t = 0f, size = 2f,
                    color = Random.value < 0.5f ? Pal.C("#6b4a2f") : Pal.C("#4b3320"),
                });
            }
            _rings.Add(new Ring { x = (float)x, y = (float)y, t = 0f, life = 0.28f, color = new Color32(255, 255, 255, 128) });
        }

        public void Poof(double x, double y, double r = 14, Color32? color = null)
        {
            _puffs.Add(new Puff { x = (float)x, y = (float)y, r = (float)r, t = 0f, life = 0.26f, color = color ?? Pal.C("#efe9d8") });
        }

        public void Limb(double x, double y, Color32 color, float w = 7f, float h = 5f, double ground = 1e9,
                         float vx = float.MinValue, float vy = float.MinValue, float life = 1.1f)
        {
            _limbs.Add(new Chunk
            {
                x = (float)x, y = (float)y, color = color, t = 0f, life = life,
                vx = vx == float.MinValue ? -70f - Random.value * 70f : vx,
                vy = vy == float.MinValue ? -140f - Random.value * 60f : vy,
                g = 460f, w = w, h = h, a = Random.value * 6.283f, va = (Random.value - 0.5f) * 16f,
                ground = (float)ground,
            });
        }

        public void HitSpark(double x, double y, Color32 color)
        {
            for (int i = 0; i < 4; i++)
            {
                float a = Random.value * Mathf.PI * 2f;
                _parts.Add(new Part
                {
                    x = (float)x, y = (float)y, vx = Mathf.Cos(a) * 60f, vy = Mathf.Sin(a) * 60f - 20f,
                    g = 120f, life = 0.22f, t = 0f, size = 2f, color = color,
                });
            }
        }

        /// <summary>Вишня: кольцо ударной волны, белая вспышка, уголь и дым.
        /// r — радиус в пикселях (в оригинале это 3×3 клетки).</summary>
        public void Boom(double x, double y, double r = 96, int embers = 26)
        {
            _rings.Add(new Ring { x = (float)x, y = (float)y, t = 0f, life = 0.44f, color = new Color32(255, 238, 160, 230) });
            _rings.Add(new Ring { x = (float)x, y = (float)y, t = 0f, life = 0.6f, color = new Color32(255, 120, 40, 150) });
            _puffs.Add(new Puff { x = (float)x, y = (float)y, r = (float)r * 0.5f, t = 0f, life = 0.3f, color = new Color32(255, 255, 255, 240) });
            _puffs.Add(new Puff { x = (float)x, y = (float)y, r = (float)r, t = 0f, life = 0.52f, color = Pal.C(Pal.SUN_DEEP) });
            for (int i = 0; i < embers; i++)
            {
                float a = Random.value * Mathf.PI * 2f;
                float sp = 90f + Random.value * 190f;
                _parts.Add(new Part
                {
                    x = (float)x, y = (float)y,
                    vx = Mathf.Cos(a) * sp, vy = Mathf.Sin(a) * sp - 40f,
                    g = 320f, life = 0.4f + Random.value * 0.5f, t = 0f,
                    size = 2f + Random.value * 3f,
                    color = Random.value < 0.4f ? Pal.C(Pal.BAD) : (Random.value < 0.6f ? new Color32(60, 48, 44, 255) : Pal.C(Pal.SUN)),
                });
            }
            Shake = 0.34f;
        }

        public void Text(float x, float y, string s, Color32 color, float vy = -26f, float life = 0.9f)
        {
            _texts.Add(new FloatText { x = (float)x, y = (float)y, str = s, color = color, t = 0f, life = life, vy = vy, size = 1f });
        }

        public void Update(double dt)
        {
            for (int i = _parts.Count - 1; i >= 0; i--)
            {
                var p = _parts[i];
                p.t += (float)dt; p.vy += p.g * (float)dt;
                p.x += p.vx * (float)dt; p.y += p.vy * (float)dt;
                if (p.t >= p.life) _parts.RemoveAt(i); else _parts[i] = p;
            }
            for (int i = _texts.Count - 1; i >= 0; i--)
            {
                var s = _texts[i]; s.t += (float)dt; s.y += s.vy * (float)dt;
                if (s.t >= s.life) _texts.RemoveAt(i); else _texts[i] = s;
            }
            for (int i = _rings.Count - 1; i >= 0; i--)
            {
                var r = _rings[i]; r.t += (float)dt;
                if (r.t >= r.life) _rings.RemoveAt(i); else _rings[i] = r;
            }
            for (int i = _puffs.Count - 1; i >= 0; i--)
            {
                var f = _puffs[i]; f.t += (float)dt;
                if (f.t >= f.life) _puffs.RemoveAt(i); else _puffs[i] = f;
            }
            for (int i = _limbs.Count - 1; i >= 0; i--)
            {
                var l = _limbs[i];
                l.t += (float)dt; l.vy += l.g * (float)dt;
                l.x += l.vx * (float)dt; l.y += l.vy * (float)dt; l.a += l.va * (float)dt;
                if (l.y > l.ground) { l.y = l.ground; l.vy *= -0.3f; l.vx *= 0.55f; l.va *= 0.5f; }
                if (l.t >= l.life) _limbs.RemoveAt(i); else _limbs[i] = l;
            }
            Shake = Mathf.Max(0f, Shake - (float)dt);
        }

        public int Count { get { return _parts.Count + _puffs.Count + _limbs.Count + _rings.Count + _texts.Count; } }

        public void Clear()
        {
            _parts.Clear(); _puffs.Clear(); _limbs.Clear(); _rings.Clear(); _texts.Clear();
            Shake = 0f;
        }

        /// <summary>Отрисовка в пул квадов; текст — в отдельный Tex-слой (у него свой шрифт).</summary>
        public void Draw(QuadPool quads, Sprite pixel)
        {
            for (int i = 0; i < _parts.Count; i++)
            {
                var p = _parts[i];
                float k = 1f - p.t / p.life;
                float s = Mathf.Max(1f, Mathf.Round(p.size * k + 0.5f));
                var c = (Color)p.color; c.a *= Mathf.Clamp01(k);
                quads.Q(p.x, p.y, s, s, c);
            }
            for (int i = 0; i < _puffs.Count; i++)
            {
                var f = _puffs[i];
                float k = f.t / f.life, fade = 1f - k;
                float cell = Mathf.Max(2f, Mathf.Round(f.r * (0.5f + k * 0.7f) / 2.2f));
                var c = (Color)f.color; c.a *= 0.42f * fade;
                float[][] offs = { new[] { 0f, 0f }, new[] { -1.6f, 0f }, new[] { 1.6f, 0f }, new[] { 0f, -1.2f },
                                   new[] { 0f, 1.2f }, new[] { -1.6f, -1.2f }, new[] { 1.6f, -1.2f },
                                   new[] { -0.8f, 1.2f }, new[] { 0.8f, 1.2f } };
                for (int o = 0; o < offs.Length; o++)
                    quads.Q(f.x + offs[o][0] * cell - Mathf.FloorToInt(cell / 2), f.y + offs[o][1] * cell - Mathf.FloorToInt(cell / 2),
                            cell, cell, c);
                var c2 = new Color(0.76f, 0.74f, 0.67f, 0.3f * fade);
                quads.Q(f.x - cell, f.y - cell * 0.7f, cell * 2, cell, c2);
            }
            for (int i = 0; i < _limbs.Count; i++)
            {
                var l = _limbs[i];
                float k = l.t / l.life;
                float a = k > 0.7f ? (1f - k) / 0.3f : 1f;
                // кувырок: рисуем прямоугольник повёрнутым — у квада для этого отдельный поворот не нужен,
                // поэтому просто «плюхаем» его в двух слоях (тень-контур + тело) с тем же альфой
                var ink = new Color(0.08f, 0.07f, 0.07f, a);
                var body = (Color)l.color; body.a *= a;
                quads.Q(l.x - l.w / 2f - 1, l.y - l.h / 2f - 1, l.w + 2, l.h + 2, ink);
                quads.Q(l.x - l.w / 2f, l.y - l.h / 2f, l.w, l.h, body);
            }
            for (int i = 0; i < _rings.Count; i++)
            {
                var r = _rings[i];
                float k = r.t / r.life, a = 1f - k;
                float x = Mathf.Round(r.x - 24f - k * 14f), y = Mathf.Round(r.y - 10f - k * 6f);
                float w = 48f + k * 28f, h = 20f + k * 12f;
                var c = new Color(1f, 1f, 1f, 0.5f * a);
                quads.Q(x, y, w, 2, c); quads.Q(x, y + h - 2, w, 2, c);
                quads.Q(x, y, 2, h, c); quads.Q(x + w - 2, y, 2, h, c);
            }
        }

        /// <summary>Всплывающий текст — в Tex (у него есть шрифт).</summary>
        public void DrawText(Tex t)
        {
            for (int i = 0; i < _texts.Count; i++)
            {
                var s = _texts[i];
                float k = 1f - s.t / s.life;
                var col = s.color; col.a = (byte)(255 * Mathf.Clamp01(k * 1.6f));
                var ink = new Color32(20, 26, 18, col.a);
                t.Text(Mathf.RoundToInt(s.x) + 1, Mathf.RoundToInt(s.y) + 1, s.str, ink, 1, 0, null);
                t.Text(Mathf.RoundToInt(s.x), Mathf.RoundToInt(s.y), s.str, col, 1, 0, null);
            }
        }
    }
}
