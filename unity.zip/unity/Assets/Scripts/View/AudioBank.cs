// ============================================================================
//  ЗВУК. В вебе это был WebAudio-синт (js/audio.js) — в Unity его не перенести,
//  поэтому те же самые «ноты» офлайн собраны в короткие WAV (tools/export_unity.py
//  прогоняет ту же огибающую и кладёт их в Assets/Resources/Pvz/audio/).
//  Здесь только проигрыватель: Play("shoot"), M — мьют.
// ============================================================================
using System.Collections.Generic;
using UnityEngine;

namespace Pvz.View
{
    [DisallowMultipleComponent]
    public sealed class AudioBank : MonoBehaviour
    {
        private readonly Dictionary<string, AudioClip> _clips = new Dictionary<string, AudioClip>();
        private AudioSource _src;
        public bool Muted;
        public float Volume = 1f;

        private void Awake()
        {
            _src = gameObject.AddComponent<AudioSource>();
            _src.playOnAwake = false;
            _src.spatialBlend = 0f;         // 2D
            var all = Resources.LoadAll<AudioClip>("Pvz/audio");
            if (all != null)
                foreach (var c in all) _clips[c.name] = c;
            if (_clips.Count == 0)
                Debug.Log("[PvZ] папка Resources/Pvz/audio пуста — игра без звука (это нормально).");
        }

        public void Play(string name, float vol = 1f)
        {
            if (Muted || _src == null) return;
            AudioClip c;
            if (!_clips.TryGetValue(name, out c) || c == null) return;
            _src.PlayOneShot(c, Mathf.Clamp01(vol) * Volume);
        }

        public bool ToggleMute() { Muted = !Muted; return Muted; }

        public int Loaded { get { return _clips.Count; } }
    }
}
