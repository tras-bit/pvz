// ============================================================================
//  Tex — программный «canvas» для статики: фон лужайки, балка HUD, панели,
//  экраны и меню. Это механический перенос вызовов fillRect/stroke из
//  render.js: тот же буфер пикселей, только рисуем один раз и вешаем
//  результат на SpriteRenderer.
//
//  Соглашения: PPU = 1 (1 юнит = 1 логический пиксель), начало координат —
//  верхний левый угол (как в canvas), у всех спрайтов пивот (0,1).
//  Все текстуры в Assets/Resources/Pvz обязаны быть Read/Write (ставит
//  PvzImporter) — иначе Blit не может прочитать пиксели.
// ============================================================================
using UnityEngine;

namespace Pvz.View
{
    public sealed class Tex
    {
        public readonly int W, H;
        private readonly Color32[] _px;
        private Texture2D _tex;
        private Sprite _sprite;

        private static readonly Color32 Transparent = new Color32(0, 0, 0, 0);
        private static readonly Color32 ShadowInk = new Color32(21, 17, 19, 90);
        private static readonly Color32 LipLight = new Color32(255, 255, 255, 130);

        public Tex(int w, int h)
        {
            W = w; H = h;
            _px = new Color32[w * h];
        }

        public Color32[] Raw { get { return _px; } }

        public void Clear(Color32 c) { for (int i = 0; i < _px.Length; i++) _px[i] = c; }
        public void ClearTransparent() { Clear(Transparent); }

        public void Dispose()
        {
            if (_sprite != null) { Object.Destroy(_sprite); _sprite = null; }
            if (_tex != null) { Object.Destroy(_tex); _tex = null; }
        }

        private int Index(int x, int y) { return (H - 1 - y) * W + x; }     // текстура в Unity вверх ногами
        private bool Inside(int x, int y) { return (uint)x < (uint)W && (uint)y < (uint)H; }

        public void SetPixel(int x, int y, Color32 c) { if (Inside(x, y)) _px[Index(x, y)] = c; }
        public Color32 GetPixel(int x, int y) { return Inside(x, y) ? _px[Index(x, y)] : Transparent; }

        private static Color32 Blend(Color32 dst, Color32 src)
        {
            float a = src.a / 255f;
            if (a >= 0.999f) return src;
            return new Color32(
                (byte)(dst.r + (src.r - dst.r) * a),
                (byte)(dst.g + (src.g - dst.g) * a),
                (byte)(dst.b + (src.b - dst.b) * a),
                (byte)Mathf.Min(255, dst.a + src.a));
        }

        private static Color32 WithAlpha(Color32 c, float alpha)
        {
            if (alpha >= 1f) return c;
            c.a = (byte)(c.a * Mathf.Clamp01(alpha));
            return c;
        }

        // ---------------------------------------------------------------- рисование
        public void FillRect(int x, int y, int w, int h, Color32 c)
        {
            int x0 = Mathf.Max(0, x), y0 = Mathf.Max(0, y);
            int x1 = Mathf.Min(W, x + w), y1 = Mathf.Min(H, y + h);
            if (c.a >= 255)
            {
                for (int yy = y0; yy < y1; yy++)
                    for (int xx = x0; xx < x1; xx++) _px[Index(xx, yy)] = c;
                return;
            }
            for (int yy = y0; yy < y1; yy++)
                for (int xx = x0; xx < x1; xx++)
                {
                    int i = Index(xx, yy);
                    _px[i] = Blend(_px[i], c);
                }
        }

        public void StrokeRect(int x, int y, int w, int h, int bw, Color32 c)
        {
            FillRect(x, y, w, bw, c);
            FillRect(x, y + h - bw, w, bw, c);
            FillRect(x, y + bw, bw, h - bw * 2, c);
            FillRect(x + w - bw, y + bw, bw, h - bw * 2, c);
        }

        public void Ellipse(int cx, int cy, int rx, int ry, Color32 c)
        {
            if (rx <= 0 || ry <= 0) return;
            for (int y = cy - ry; y <= cy + ry; y++)
                for (int x = cx - rx; x <= cx + rx; x++)
                {
                    double dx = (x - cx) / (double)rx, dy = (y - cy) / (double)ry;
                    if (dx * dx + dy * dy <= 1.05) FillRect(x, y, 1, 1, c);
                }
        }

        public void Tri(int x0, int y0, int x1, int y1, int x2, int y2, Color32 c)
        {
            int top = Mathf.Min(y0, Mathf.Min(y1, y2)), bot = Mathf.Max(y0, Mathf.Max(y1, y2));
            for (int y = top; y <= bot; y++)
            {
                int minX = int.MaxValue, maxX = int.MinValue;
                int[] xs = { x0, x1, x2 }, ys = { y0, y1, y2 };
                for (int e = 0; e < 3; e++)
                {
                    int e2 = (e + 1) % 3;
                    if (ys[e] == ys[e2]) continue;
                    if (y < Mathf.Min(ys[e], ys[e2]) || y > Mathf.Max(ys[e], ys[e2])) continue;
                    float t = (y - ys[e]) / (float)(ys[e2] - ys[e]);
                    int xi = Mathf.RoundToInt(xs[e] + (xs[e2] - xs[e]) * t);
                    minX = Mathf.Min(minX, xi); maxX = Mathf.Max(maxX, xi);
                }
                if (maxX >= minX) FillRect(minX, y, maxX - minX + 1, 1, c);
            }
        }

        /// <summary>Панель как panel() в JS: заливка, тёмная нижняя грань, блик, контур, тень.</summary>
        public void Panel(int x, int y, int w, int h, Color32 fill, Color32 border, int bw = 3, int r = 6,
                          bool lip = true, bool shadow = true, Color32? lipColor = null)
        {
            var cardDark = Core.Pal.C(Core.Pal.CARD_DARK);
            if (shadow) RoundRectFill(x + 2, y + 3, w, h, r, ShadowInk);
            RoundRectFill(x, y, w, h, r, fill);
            if (lip)
            {
                FillRect(x + 1, y + h - 4, w - 2, 4, lipColor ?? cardDark);
                FillRect(x + 1, y + 1, w - 2, 2, LipLight);
            }
            if (bw > 0) StrokeRect(x, y, w, h, bw, border);
        }

        private static int Corner(int i, int r)
        {
            double d = r - i - 0.5;
            double v = r - System.Math.Sqrt(System.Math.Max(0.0, r * r - d * d));
            return Mathf.Clamp((int)System.Math.Floor(v + 0.5), 0, r);
        }

        public void RoundRectFill(int x, int y, int w, int h, int r, Color32 c)
        {
            r = Mathf.Min(r, w / 2, h / 2);
            for (int yy = 0; yy < h; yy++)
            {
                int inset = 0;
                if (yy < r) inset = r - Corner(yy, r);
                else if (yy >= h - r) inset = r - Corner(h - 1 - yy, r);
                FillRect(x + inset, y + yy, w - inset * 2, 1, c);
            }
        }

        public void RoundRectStroke(int x, int y, int w, int h, int r, int bw, Color32 c)
        {
            for (int i = 0; i < bw; i++) RoundRectOutline(x + i, y + i, w - i * 2, h - i * 2, r, c);
        }

        private void RoundRectOutline(int x, int y, int w, int h, int r, Color32 c)
        {
            r = Mathf.Min(r, w / 2, h / 2);
            for (int xx = x + r; xx < x + w - r; xx++) { SetPixel(xx, y, c); SetPixel(xx, y + h - 1, c); }
            for (int yy = y + r; yy < y + h - r; yy++) { SetPixel(x, yy, c); SetPixel(x + w - 1, yy, c); }
            for (int i = 0; i < r; i++)
            {
                int inTop = r - Corner(i, r);
                SetPixel(x + inTop, y + i, c); SetPixel(x + w - 1 - inTop, y + i, c);
                int inBot = r - Corner(i, r);
                SetPixel(x + inBot, y + h - 1 - i, c); SetPixel(x + w - 1 - inBot, y + h - 1 - i, c);
            }
        }

        /// <summary>Блит текстуры (nearest) с тонтом и аддитивкой — аналог sp.draw с flash.</summary>
        public void Blit(Texture2D src, Color32 tint, int dx, int dy, float alpha = 1f, bool additive = false, float scale = 1f)
        {
            if (src == null) return;
            Color32[] data;
            try { data = src.GetPixels32(); }
            catch { return; }                                   // текстура не readable — молча пропускаем
            Blit(data, src.width, src.height, 0, 0, src.width, src.height, tint, dx, dy, alpha, additive, scale);
        }

        private void Blit(Color32[] data, int texW, int texH, int rx, int ry, int rw, int rh,
                          Color32 tint, int dx, int dy, float alpha, bool additive, double scale)
        {
            tint = WithAlpha(tint, alpha);
            int dw = Mathf.Max(1, Mathf.RoundToInt((float)rw * (float)scale));
            int dh = Mathf.Max(1, Mathf.RoundToInt((float)rh * (float)scale));
            for (int y = 0; y < dh; y++)
            {
                int sy = texH - 1 - (ry + (int)(y / scale));
                int rowDst = dy + y;
                if ((uint)rowDst >= (uint)H) continue;
                for (int x = 0; x < dw; x++)
                {
                    int sx = rx + (int)(x / scale);
                    Color32 c = data[sy * texW + sx];
                    if (c.a == 0) continue;
                    c.r = (byte)(c.r * tint.r / 255);
                    c.g = (byte)(c.g * tint.g / 255);
                    c.b = (byte)(c.b * tint.b / 255);
                    c.a = (byte)(c.a * tint.a / 255);
                    int colDst = dx + x;
                    if ((uint)colDst >= (uint)W) continue;
                    int i = Index(colDst, rowDst);
                    if (additive)
                    {
                        Color32 d = _px[i];
                        _px[i] = new Color32(
                            (byte)Mathf.Min(255, d.r + c.r), (byte)Mathf.Min(255, d.g + c.g),
                            (byte)Mathf.Min(255, d.b + c.b), (byte)Mathf.Min(255, Mathf.Max(d.a, c.a)));
                    }
                    else _px[i] = Blend(_px[i], c);
                }
            }
        }

        /// <summary>Спрайт в буфер (x,y — верхний левый угол). scale: 1 или 0.5 — как в карточках HUD.</summary>
        public void Draw(Sprite sp, int x, int y, Color32? tint = null, float alpha = 1f, bool additive = false, double scale = 1.0)
        {
            if (sp == null || sp.texture == null) return;
            Color32[] full;
            try { full = sp.texture.GetPixels32(); }
            catch { return; }
            var r = sp.textureRect;
            var col = tint ?? new Color32(255, 255, 255, 255);
            Blit(full, sp.texture.width, sp.texture.height, (int)r.x, (int)r.y, (int)r.width, (int)r.height,
                 col, x, y, alpha, additive, scale);
        }

        // ----------------------------------------------------------------- текст
        /// <summary>
        /// Текст пиксельным шрифтом 5×7. yBaseline — базовая линия (как в canvas).
        /// align: -1 влево, 0 центр, 1 вправо. scale — только целое.
        /// </summary>
        public void Text(int x, int yBaseline, string text, Color32 fill, int scale = 1, int align = -1,
                         Color32? outline = null, int outlineW = 1)
        {
            text = text ?? "";
            int w = Mathf.Max(0, (text.Length * Glyphs.ADVANCE - 1) * scale);
            int startX = align == 0 ? x - w / 2 : (align == 1 ? x - w : x);
            int top = yBaseline - (Glyphs.GH + 1) * scale;

            // сначала в маску строки — так обводка получается ровно по силуэту
            int mw = Mathf.Max(1, text.Length * Glyphs.ADVANCE * scale);
            int mh = Glyphs.GH * scale + outlineW * 2;
            var mask = new bool[mw * mh];
            for (int i = 0; i < text.Length; i++)
            {
                int[] bits;
                Glyphs.TryGet(text[i], out bits);
                int gx = i * Glyphs.ADVANCE * scale;
                for (int gy = 0; gy < Glyphs.GH; gy++)
                    for (int gxx = 0; gxx < Glyphs.GW; gxx++)
                    {
                        if (!Glyphs.Pixel(bits, gxx, gy)) continue;
                        for (int oy = 0; oy < scale; oy++)
                            for (int ox = 0; ox < scale; ox++)
                            {
                                int mx = gx + gxx * scale + ox, my = outlineW + gy * scale + oy;
                                if ((uint)mx < (uint)mw && (uint)my < (uint)mh) mask[my * mw + mx] = true;
                            }
                    }
            }
            if (outline != null)
            {
                var oc = outline.Value;
                for (int yy = 0; yy < mh; yy++)
                    for (int xx = 0; xx < mw; xx++)
                    {
                        if (mask[yy * mw + xx]) continue;
                        bool near = false;
                        for (int d = 1; d <= outlineW && !near; d++)
                        {
                            if (Near(mask, mw, mh, xx, yy, -d, 0) || Near(mask, mw, mh, xx, yy, d, 0) ||
                                Near(mask, mw, mh, xx, yy, 0, -d) || Near(mask, mw, mh, xx, yy, 0, d)) near = true;
                        }
                        if (near) FillRect(startX - outlineW + xx, top - outlineW + yy, 1, 1, oc);
                    }
            }
            for (int yy = 0; yy < mh; yy++)
                for (int xx = 0; xx < mw; xx++)
                    if (mask[yy * mw + xx]) FillRect(startX + xx, top + yy, 1, 1, fill);
        }

        private static bool Near(bool[] mask, int mw, int mh, int x, int y, int dx, int dy)
        {
            int nx = x + dx, ny = y + dy;
            if ((uint)nx >= (uint)mw || (uint)ny >= (uint)mh) return false;
            return mask[ny * mw + nx];
        }

        // ------------------------------------------------------------ публикация
        public void Apply()
        {
            if (_tex == null)
            {
                _tex = new Texture2D(W, H, TextureFormat.RGBA32, false);
                _tex.filterMode = FilterMode.Point;
                _tex.wrapMode = TextureWrapMode.Clamp;
            }
            _tex.SetPixels32(_px);
            _tex.Apply(false, false);
            if (_sprite != null) Object.Destroy(_sprite);
            _sprite = Sprite.Create(_tex, new Rect(0, 0, W, H), new Vector2(0, 1f), 1f);
        }

        public Sprite Sprite
        {
            get
            {
                if (_sprite == null) Apply();
                return _sprite;
            }
        }
    }
}
