// ============================================================================
//  ОФЛАЙН-РЕНДЕР Unity-СЛОЯ.
//
//  Геймплейный код (GameRoot + View) выполняется НАСТОЯЩИЙ, вместо Unity
//  работают заглушки из UnityStubs.cs: они умеют читать пиксели ассетов
//  (dump'ы, которые пишет pvz-pixel/tools/export_unity.py) и складывать все
//  созданные SpriteRenderer'ы в общий кадр. Дальше харнесс сам раскладывает
//  их по слоям сортировки — то, что получится, и есть картинка из Unity
//  (без учёта поворотов, они в этой игре косметические).
//
//    dotnet run -c Release --no-build -- render <файл.rgba> <режим> [секунд]
//    режимы: title | menu | play | drag | lose
//
//  Это только проверка. В билд Unity файл не попадает (лежит вне Assets/).
// ============================================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Linq;
using UnityEngine;
using Pvz;
using Pvz.View;

internal static class Program
{
    private static readonly BindingFlags IP = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public;
    private static GameRoot _gr;
    private static MethodInfo _awake, _update;
    private static int _w, _h;
    private static byte[] _buf;

    private static int Main(string[] args)
    {
        string outPath = args.Length > 0 ? args[0] : "/tmp/render.rgba";
        string mode = args.Length > 1 ? args[1] : "play";
        double seconds = args.Length > 2 ? double.Parse(args[2], System.Globalization.CultureInfo.InvariantCulture) : 20;

        Resources.StubBinDir = FindBinDir();
        if (Resources.StubBinDir == "")
        {
            Console.Error.WriteLine("нет renderbin — запусти: python3 pvz-pixel/tools/export_unity.py");
            return 2;
        }

        // экран 1:1 = ровно логический вид, масштаб 1
        _w = (int)Pvz.Core.Geo.VIEW_W;
        _h = (int)Pvz.Core.Geo.VIEW_H;
        var camGo = new GameObject("Camera");
        var cam = camGo.AddComponent<Camera>();
        cam.pixelWidth = _w;
        cam.pixelHeight = _h;
        Camera.main = cam;
        Time.deltaTime = 1f / 60f;

        var go = new GameObject("GameRoot");
        _gr = go.AddComponent<GameRoot>();
        if (mode == "title") _gr.StartInMenu = false;
        // «пройдённый» 1-1: прогресс живёт в PlayerPrefs — для кадров 1-2 и открытого меню
        // подставляем его сюда же, куда это делает игра после победы.
        if (mode == "level2" || mode == "menuopen" || mode == "win" || mode == "debug2" ||
            mode == "cool" || mode == "input" || mode == "adventure" || mode == "level3" ||
            mode == "level4" || mode == "nut")
        {
            // как после победы над 1-1: 1-2 открыт, в награду — подсолнух и вишня.
            // Для 1-3 прокручиваем прогресс на уровень дальше: пройдены 1-1 и 1-2,
            // орех ещё НЕ открыт (он — награда за 1-3), поэтому его в пачке нет.
            bool deep = mode == "level3" || mode == "nut";
            bool done4 = mode == "level4";
            if (mode != "win")
            {
                // level4 снимает «повторное» прохождение 1-4: чемпер и лопата уже
                // заработаны, поэтому они и в пачке, и в HUD (иначе кадр был бы пустой)
                UnityEngine.PlayerPrefs.SetInt("pvz.level", done4 ? 4 : (deep ? 2 : 1));
                UnityEngine.PlayerPrefs.SetString("pvz.plants", done4 ? "sunflower,cherry,wallnut,chomper" : "sunflower,cherry");
                if (done4) UnityEngine.PlayerPrefs.SetString("pvz.tools", "shovel");
            }
            if (mode != "win") _gr.LevelIndex = done4 ? 3 : (deep ? 2 : 1);
        }
        _awake = typeof(GameRoot).GetMethod("Awake", IP);
        _update = typeof(GameRoot).GetMethod("Update", IP);
        _awake.Invoke(_gr, null);

        switch (mode)
        {
            case "title":
            case "menu":
                Frame();
                foreach (var sr in StubScene.Renderers)
                {
                    var sp = sr.sprite;
                    Console.WriteLine(string.Format("  {0,-9} en={1} act={2} sprite={3} tex={4} rect={5}x{6} pos=({7},{8})",
                        sr.gameObject.name, sr.enabled, sr.gameObject.activeSelf, sp == null ? "null" : sp.name,
                        sp == null || sp.texture == null ? "null" : sp.texture.width + "x" + sp.texture.height,
                        sp == null ? 0 : sp.rect.width, sp == null ? 0 : sp.rect.height,
                        sr.transform.position.x, sr.transform.position.y));
                }
                break;
            case "play":
                PlantAll();
                Run(seconds);
                break;
            case "level2":
                PlantAll2();
                Run(seconds > 0 ? seconds : 24);
                {
                    Pvz.Core.Fail fx;
                    _gr.World.Place(2, 4, "cherry", out fx);      // вишня в гущу — кадр с тлеющим фитилём
                    // конусы рисуем руками: их приход зависит от rng уровня, а нам важно
                    // увидеть оверлей брони (целый и побитый) в кадре
                    var z1 = _gr.World.SpawnZombie("conehead", 1);
                    z1.X = Pvz.Core.Geo.LAWN_X + 6.5 * Pvz.Core.Geo.TILE;
                    var z2 = _gr.World.SpawnZombie("conehead", 3);
                    z2.X = Pvz.Core.Geo.LAWN_X + 5.2 * Pvz.Core.Geo.TILE;
                    _gr.World.HurtZombie(z2, 300);                // конус побит: другая картинка
                }
                Run(0.8);
                int cone = 0;
                foreach (var z in _gr.World.Zombies) if (z.Type == "conehead") cone++;
                Console.WriteLine("  конусов в кадре: " + cone);
                Console.WriteLine("  1-2: полос " + _gr.World.UnlockedRows.Count +
                                  " · посажено " + _gr.World.Plants.Count +
                                  " · зомби " + _gr.World.Zombies.Count);
                break;
            case "level4":
                // 1-4: чемперы жуят, ведроголовые едят орех, лопата в руке (кадр HUD)
                PlantAll4();
                Run(seconds > 0 ? seconds : 80);
                _gr.ToggleShovel();
                Frame();
                Console.WriteLine("  1-4: чемперов " + CountChompers() + " · карточек " + _gr.World.Seeds.Count +
                                  " · лопата в руке " + _gr.ShovelArmed + " · убито " + _gr.World.KilledZombies);
                break;
            case "level3":
                // 1-3: пять полос открыты с первой секунды, ведроголовые, орех-стена.
                PlantAll3();
                Run(seconds > 0 ? seconds : 64);   // 64 с: первая волна на 1-3 теперь на 44-й, раньше на поле пусто
                {
                    Pvz.Core.Fail f3;
                    var w3 = _gr.World;
                    w3.RechargeAll();
                    w3.Place(0, 3, "wallnut", out f3);            // орех ставим миром:
                    w3.RechargeAll();
                    w3.Place(4, 2, "wallnut", out f3);            // карты его ещё нет
                    var b1 = w3.SpawnZombie("buckethead", 0);
                    b1.X = Pvz.Core.Geo.LAWN_X + 4.6 * Pvz.Core.Geo.TILE;   // прямо на орех
                    var b2 = w3.SpawnZombie("buckethead", 4);
                    b2.X = Pvz.Core.Geo.LAWN_X + 3.2 * Pvz.Core.Geo.TILE;
                    w3.HurtZombie(b2, 900);                         // ведро помято → другой спрайт
                    var c2 = w3.SpawnZombie("conehead", 2);
                    c2.X = Pvz.Core.Geo.LAWN_X + 5.4 * Pvz.Core.Geo.TILE;
                    Run(16.0);                    // 16 с поедания (100 HP/с минус подходы): на кадре видна
                    // первая стадия скорлупы (трещины и укусы), а не «целый орех, который грызут»
                    int buckets = 0, eating = 0;
                    double nutHp = 0;
                    foreach (var z in w3.Zombies)
                    {
                        if (z.Type == "buckethead") buckets++;
                        if (z.State == "eat") eating++;
                    }
                    foreach (var pl in w3.Plants) if (pl.Type == "wallnut" && pl.Hp < nutHp + 1) nutHp = pl.Hp;
                    int nutStage = 0, nutBites = 0;
                    foreach (var pl in w3.Plants) if (pl.Type == "wallnut") { nutHp = pl.Hp; nutStage = pl.Stage; nutBites = pl.Bites; break; }
                    Console.WriteLine("  1-3: полос " + w3.UnlockedRows.Count + " · косилок " + w3.Mowers.Count +
                                      " · ведер " + buckets + " · едят " + eating +
                                      " · орех HP " + nutHp.ToString("0") + " стадия " + nutStage +
                                      " укусов " + nutBites + " · карточек " + w3.Seeds.Count);
                }
                break;
            case "nut":
                // Витрина анимаций: орех в четырёх стадиях скорлупы, зомби в шаге и
                // в пасти, горохострел на выстреле, чемпер на жвачке. Кадр снят на
                // 1-3 (пять полос), чтобы всё влезло в одну полосу обзора.
                PlantAll3();
                Run(30);
                {
                    var wn = _gr.World;
                    Pvz.Core.Fail fn;
                    int[] hp = { 4000, 2880, 2000, 1000 };
                    for (int i = 0; i < 4; i++)
                    {
                        wn.RechargeAll();
                        wn.Place(1, 1 + i, "wallnut", out fn);
                    }
                    int j = 0;
                    foreach (var pl in wn.Plants)
                        if (pl.Type == "wallnut" && j < hp.Length) { pl.Hp = hp[j++]; pl.MaxHp = 4000; }
                    var zc = wn.SpawnZombie("basic", 1);
                    zc.X = Pvz.Core.Geo.LAWN_X + 2.35 * Pvz.Core.Geo.TILE;      // прямо на орех — кадр «ест»
                    var zw = wn.SpawnZombie("conehead", 3);
                    zw.X = Pvz.Core.Geo.LAWN_X + 6.0 * Pvz.Core.Geo.TILE;       // кадр «идёт»
                    var zb = wn.SpawnZombie("buckethead", 4);
                    zb.X = Pvz.Core.Geo.LAWN_X + 5.1 * Pvz.Core.Geo.TILE;
                    wn.HurtZombie(zb, 1150);                                     // ведро помято
                    // два чемпера в разных фазах жвачки: «только что схватил» (первые
                    // 0.9 с — группа eat) и «сидит и пережёвывает» (середина — группа chew).
                    wn.RechargeAll();
                    Pvz.Core.Plant chA = wn.Place(0, 7, "chomper", out fn);
                    wn.RechargeAll();
                    Pvz.Core.Plant chB = wn.Place(2, 7, "chomper", out fn);
                    if (chA != null) { var q = wn.SpawnZombie("basic", 0); q.X = Pvz.Core.Geo.CellX(chA.Col + 2) + 32; }  // клетка c+2
                    if (chB != null) { var q = wn.SpawnZombie("basic", 2); q.X = chB.X + 40; }
                    Run(0.42);                                                   // середина цикла шага
                    if (chB != null && chB.ChewTimer > 0) chB.ChewTimer = 8.0;   // середина жвачки
                    int bites = 0, stages = 0, eat = 0, chew = 0, grab = 0;
                    foreach (var pl in wn.Plants)
                    {
                        if (pl.Type == "wallnut") { bites += pl.Bites; stages += pl.Stage; continue; }
                        if (pl.Def.Chomp == null || pl.ChewTimer <= 0) continue;
                        if (pl.ChewTimer > pl.Def.Chomp.Chew - 0.9) grab++; else chew++;
                    }
                    foreach (var z in wn.Zombies) if (z.State == "eat") eat++;
                    Console.WriteLine("  орехи: стадий " + stages + " · укусов " + bites +
                                      " · едят " + eat + " · чемперы: выпад " + grab + ", жуют " + chew +
                                      " · зомби " + wn.Zombies.Count);
                }
                break;
            case "win":
                WinRun(seconds > 0 ? seconds : 210);
                Console.WriteLine("  мир: " + _gr.World.State + " · убито " + _gr.World.KilledZombies +
                                  "/" + _gr.World.TotalZombies + " · открыто " + Pvz.View.Progress.LevelOpen(1));
                break;
            case "menuopen":
                Frame();
                Console.WriteLine("  меню: пунктов " + Pvz.View.MenuLayout.Modes.Length +
                                  " · 1-2 на экране выбора " +
                                  (Pvz.View.AdventureLayout.IsOpen(1) ? "открыт" : "заперт") +
                                  " · пройдено " + Pvz.View.Progress.LevelsDone);
                break;
            case "adventure":
                // настоящим Enter: меню → экран выбора уровня
                Frame();
                Input.StubKeys.Add(KeyCode.Return);
                Frame();
                Console.WriteLine("  экран: " + Private("_scr") + " · узлов " + Pvz.View.AdventureLayout.Count +
                                  " · 1-2 " + (Pvz.View.AdventureLayout.IsOpen(1) ? "открыт" : "заперт") +
                                  " · рамка на " + Pvz.View.AdventureLayout.Title(Sel()));
                break;
            case "adventurelocked":
                // без прогресса: 1-2 заперт; стрелкой переезжаем на него — надо видеть замок
                Frame();
                Input.StubKeys.Add(KeyCode.Return);
                Frame();
                Input.StubKeys.Add(KeyCode.RightArrow);
                Frame();
                Console.WriteLine("  экран: " + Private("_scr") + " · 1-2 " +
                                  (Pvz.View.AdventureLayout.IsOpen(1) ? "открыт" : "заперт") +
                                  " · рамка на " + Pvz.View.AdventureLayout.Title(Sel()) +
                                  " · галка на 1-1 " + Pvz.View.AdventureLayout.Done(0));
                break;
            case "drag":
                HoldCard();
                break;
            case "cool":                                // тени перезарядки на карточках
                CoolShot();
                break;
            case "input":
                return InputRules();
            case "lose":
                _gr.Restart();
                Run(seconds > 0 ? seconds : 88);
                break;
            case "debug2":
                PlantAll2();
                Run(30);
                DumpRight();
                break;
            case "debug":
                PlantAll();
                Run(2);
                foreach (var sr in StubScene.Renderers)
                {
                    if (sr.sprite == null || !sr.enabled) continue;
                    if (sr.gameObject == null || !sr.gameObject.activeSelf) continue;
                    var t = sr.transform;
                    Console.WriteLine(string.Format("{0,-12} {1,-28} L={2,-11} o={3,-5} pos=({4},{5}) sc=({6},{7})",
                        sr.gameObject.name, sr.sprite.name, sr.sortingLayerName, sr.sortingOrder,
                        t.position.x, t.position.y, t.lossyScale.x, t.lossyScale.y));
                }
                Console.WriteLine("всего рендереров: " + StubScene.Renderers.Count +
                                  "  косилок в мире: " + WorldCount());
                var fW = typeof(GameRoot).GetField("_world", IP);
                var w = fW.GetValue(_gr) as Pvz.Core.World;
                Console.WriteLine(string.Format("world: t={0} state={1} sun={2} plants={3} wavesDone={4} unlocked={5}",
                    w.Time.ToString("0.00"), w.State, w.SunCount, w.Plants.Count, w.WaveIndex, w.UnlockedRows.Count));
                Console.WriteLine("ui: selected=" + _gr.GetType().GetField("_ui", IP).GetValue(_gr));
                foreach (var nm in new[] { "_scr", "_acc", "_paused", "_running", "_clock" })
                {
                    var ff = typeof(GameRoot).GetField(nm, IP);
                    Console.WriteLine("  " + nm + " = " + (ff == null ? "нет поля" : ff.GetValue(_gr)));
                }
                var pk = Pvz.Core.CFG.HUD.Packet;
                Console.WriteLine(string.Format("  packet: x={0} y={1} w={2} h={3} gap={4}", pk.X, pk.Y, pk.W, pk.H, pk.Gap));
                var cardAt = typeof(GameRoot).GetMethod("CardAt", IP);
                var hov = typeof(GameRoot).GetField("_ui", IP).GetValue(_gr) as UiState;
                Console.WriteLine("  CardAt(119,41) = " + (cardAt.Invoke(_gr, new object[] { new Vector2(119f, 41f) }) ?? "null") +
                                  "   HoveredCard=" + (hov.HoveredCard ?? "null") +
                                  "  mouse=(" + hov.MouseX + "," + hov.MouseY + ")");
                var wl = (fW.GetValue(_gr) as Pvz.Core.World);
                Console.WriteLine("  seeds уровня: " + string.Join(",", wl.Level.Seeds) +
                                  "  sun=" + wl.SunCount + "  plants=" + wl.Plants.Count +
                                  "  time=" + wl.Time.ToString("0.0"));
                Console.WriteLine("  Time.deltaTime = " + Time.deltaTime + "  FixedStep = " + Pvz.Core.CFG.GAME.FixedStep +
                                  "  MaxStepPerFrame = " + Pvz.Core.CFG.GAME.MaxStepPerFrame);
                return 0;
            default:
                Console.Error.WriteLine("неизвестный режим: " + mode);
                return 2;
        }

        var scrF = typeof(GameRoot).GetField("_scr", IP);
        Console.WriteLine("экран: " + (scrF == null ? "?" : scrF.GetValue(_gr)));
        Dump(outPath);
        Console.WriteLine("ok " + mode + " → " + outPath + "  (" + _w + "×" + _h + ", " + _buf.Length / 4 + " px)");
        return 0;
    }

    private static string Scr() { var v = Private("_scr"); return v == null ? "?" : v.ToString(); }

    private static object Private(string field)
    {
        var f = typeof(GameRoot).GetField(field, IP);
        return f == null ? "?" : f.GetValue(_gr);
    }

    private static int Sel()
    {
        var f = typeof(GameRoot).GetField("_adSel", IP);
        int v = (int)f.GetValue(_gr);
        // -1 = «рамку поставил сам мир»: берём то, что покажет Paint
        var m = typeof(GameRoot).GetMethod("AdventureSel", IP);
        return v >= 0 ? v : (int)m.Invoke(_gr, null);
    }

    private static string WorldCount()
    {
        var f = typeof(GameRoot).GetField("_world", IP);
        var w = f.GetValue(_gr) as Pvz.Core.World;
        return w == null ? "?" : (w.Mowers.Count + " (штук), peas=" + w.Peas.Count + " suns=" + w.Suns.Count);
    }

    // ------------------------------------------------------------------ кадры
    private static void Frame() { Time.time += Time.deltaTime; _update.Invoke(_gr, null); Input.StubEndFrame(); }

    private static void Run(double seconds)
    {
        int frames = (int)Math.Round(seconds / (double)Time.deltaTime);
        for (int i = 0; i < frames; i++) Frame();
    }

    private static void Move(double x, double y) { Input.mousePosition = new Vector3((float)x, (float)(_h - y), 0f); }

    private static void ClickDown(double x, double y) { Move(x, y); Input.StubDown0 = true; Frame(); }
    private static void ClickUp(double x, double y) { Move(x, y); Input.StubUp0 = true; Frame(); }
    private static void Hover(double x, double y) { Move(x, y); Frame(); }

    private const double CardY = 41;                 // центр карточки в панели семян
    private static double CardX(int i) => Pvz.Core.CFG.HUD.Packet.X + i * (Pvz.Core.CFG.HUD.Packet.W + Pvz.Core.CFG.HUD.Packet.Gap) + Pvz.Core.CFG.HUD.Packet.W / 2;
    private static double CellX(int col) => Pvz.Core.Geo.CellX(col) + Pvz.Core.Geo.TILE / 2.0;
    private static double CellY(int row) => Pvz.Core.Geo.CellY(row) + Pvz.Core.Geo.TILE / 2.0;

    /// <summary>Посадка настоящим перетаскиванием: карточка → клетка → отпустил.</summary>
    private static void Plant(int card, int row, int col)
    {
        ClickDown(CardX(card), CardY);
        Hover(CellX(col), CellY(row));
        ClickUp(CellX(col), CellY(row));
    }

    private static void PlantAll()
    {
        _gr.Restart();
        Frame();
        Plant(0, 2, 1);            // горохострел — настоящим перетаскиванием
        _gr.World.RechargeAll();   // перезарядку сбрасываем читом: в кадре нужно два растения
        Plant(0, 2, 3);            // второй горох правее
        Run(5.0);                  // 5 с карточка «дозаряжается» — в кадре видна половина тени
    }

    /// <summary>Доводим 1-1 до победы: 8 горохострелов и солнце веером. Миром напрямую,
    /// без мыши — клик по победному экрану в игре означает «заново» (см. OnDown).</summary>
    private static void WinRun(double seconds)
    {
        _gr.Restart();
        Frame();
        _gr.GiveSun(2000);
        Pvz.Core.Fail f;
        // кадры ставим миром напрямую, поэтому перезарядку сбрасываем руками:
        // иначе 8 горохострелов не посадить, а нам нужен полный газон
        for (int c = 0; c < 8; c++) { _gr.World.RechargeAll(); _gr.World.Place(2, c, "peashooter", out f); }
        _gr.World.RechargeAll();          // кадр победы: пачка должна быть светлой
        Frame();
        int frames = (int)Math.Round(seconds / (double)Time.deltaTime);
        for (int i = 0; i < frames && _gr.World.State == Pvz.Core.WorldState.Playing; i++)
        {
            _gr.GiveSun(20);
            Frame();
        }
        Console.WriteLine("  экран: мир=" + _gr.World.State + " · t=" + _gr.World.Time.ToString("0.0") +
                          " · убито " + _gr.World.KilledZombies + "/" + _gr.World.TotalZombies +
                          " · 1-2 открыт " + Pvz.View.Progress.LevelOpen(1) +
                          " · растений у игрока " + Pvz.View.Progress.Plants().Count);
    }

    /// <summary>1-2: три полосы, по горохострелу и подсолнух на каждой.</summary>
    /// <summary>1-3: по перцу и подсолнуху на каждую из пяти полос — кадр должен
    /// показывать и поле целиком, и новых зомби, и орех (посадка — миром, карта
    /// ореха на этом уровне ещё не открыта).</summary>
    private static int CountChompers()
    {
        int n = 0;
        foreach (var pl in _gr.World.Plants) if (pl.Type == "chomper") n++;
        return n;
    }

    private static void PlantAll4()
    {
        _gr.Restart();
        _gr.GiveSun(4000);
        Frame();
        Pvz.Core.Fail f;
        var w = _gr.World;
        for (int r = 0; r < 5; r++)
        {
            w.RechargeAll();
            w.Place(r, 0, "sunflower", out f);
            w.RechargeAll();
            w.Place(r, 4, r % 2 == 0 ? "chomper" : "wallnut", out f);
            w.RechargeAll();
            w.Place(r, 6, "peashooter", out f);
        }
        w.RechargeAll();
    }

    private static void PlantAll3()
    {
        _gr.Restart();
        _gr.GiveSun(4000);
        Frame();
        Pvz.Core.Fail f;
        var w = _gr.World;
        for (int r = 0; r < 5; r++)
        {
            w.RechargeAll();
            w.Place(r, 6, "peashooter", out f);
            w.RechargeAll();
            w.Place(r, 1, "sunflower", out f);
        }
        w.RechargeAll();
    }

    private static void PlantAll2()
    {
        _gr.Restart();
        _gr.GiveSun(2000);
        Frame();
        // сажаем миром напрямую: карточка появляется только если растение открыто
        // (cliki по карточкам проверяются на кадрах play/drag)
        Pvz.Core.Fail f;
        var w = _gr.World;
        for (int c = 0; c < 3; c++)
        {
            w.RechargeAll();
            w.Place(1 + c, 5 + c, "peashooter", out f);
            w.RechargeAll();
            w.Place(1 + c, 1 + c, "sunflower", out f);
        }
        // карточки заряжаем: иначе тень перезарядки съедает половину пачки в кадре,
        // а нам важно увидеть набор целиком
        w.RechargeAll();
        Console.WriteLine("  пачка 1-2: " + string.Join(",", w.Seeds.ToArray()) + " · посажено " + w.Plants.Count);
        Frame(); Frame();
    }

    /// <summary>Печать видимых квадов у правой кромки газона — искать «чёрную полосу».</summary>
    private static void DumpRight()
    {
        foreach (var sr in StubScene.Renderers)
        {
            if (sr.sprite == null || !sr.enabled) continue;
            if (sr.gameObject != null && !sr.gameObject.activeSelf) continue;
            var t = sr.transform;
            var pt = t.parent != null ? t.parent.position : t.position;
            if (pt.x < 500 || pt.y > -130 || pt.y < -260) continue;
            var c = sr.color;
            Console.WriteLine(string.Format("  {0,-8} {1,-20} L={2,-11} o={3,-5} pos=({4},{5}) sc=({6},{7}) col=({8},{9},{10},{11}) mat={12}",
                sr.gameObject.name, sr.sprite.name, sr.sortingLayerName, sr.sortingOrder,
                pt.x, pt.y, t.lossyScale.x, t.lossyScale.y, c.r, c.g, c.b, c.a,
                sr.sharedMaterial == null ? "null" : sr.sharedMaterial.name));
        }
    }

    private static void Gap() { for (int i = 0; i < 5; i++) Frame(); }

    private static string Describe(int i)
    {
        if (i >= _gr.World.Plants.Count) return "—";
        var p = _gr.World.Plants[i];
        return p.Type + " r" + p.Row + "c" + p.Col;
    }

    private static void HoldCard()
    {
        _gr.Restart();
        Frame();
        Plant(0, 2, 1);           // одна посадка, чтобы был бюджет
        _gr.World.RechargeAll();  // иначе карточка на перезарядке и её не взять
        ClickDown(CardX(0), CardY);
        Hover(CellX(4), CellY(2));
    }

    /// <summary>Кадр «карточка отдыхает»: на 1-2 сажаем две карточки по-настоящему
    /// (перетаскиванием), третью держим в руке. Видно тень перезарядки и секунды вместо цены.</summary>
    private static void CoolShot()
    {
        _gr.Restart();
        Frame();
        var w = _gr.World;
        _gr.GiveSun(2000);
        Plant(1, 2, 2);           // подсолнух (вторая карточка пачки)
        Run(3.0);                 // 3 с: у него должно остаться ~4.5
        Plant(0, 2, 4);           // горохострел — только что посажен, все 7.5
        ClickDown(CardX(2), CardY);       // вишню держим в руке
        Hover(CellX(6), CellY(2));
        Console.WriteLine("  перезарядка: горох=" + w.CooldownLeft("peashooter").ToString("0.0") +
                          " · подсолнух=" + w.CooldownLeft("sunflower").ToString("0.0") +
                          " · вишня=" + w.CooldownLeft("cherry").ToString("0.0") +
                          " · посажено " + w.Plants.Count);
        Run(0.2);
    }

    private static int _checkFails, _checkTotal;

    private static void Check(bool ok, string what, string extra = "")
    {
        _checkTotal++;
        Console.WriteLine((ok ? "  ok   " : "  FAIL ") + what + (ok || extra == "" ? "" : " [" + extra + "]"));
        if (!ok) _checkFails++;
    }

    private static string Str(string field)
    {
        var f = typeof(GameRoot).GetField(field, IP);
        var v = f == null ? null : f.GetValue(_gr);
        return v == null ? "" : v.ToString();
    }

    private static object Ui(string field)
    {
        var ui = typeof(GameRoot).GetField("_ui", IP).GetValue(_gr);
        return ui == null ? null : ui.GetType().GetField(field, IP).GetValue(ui);
    }

    /// <summary>Правила ввода: сажает только перетаскивание, тап — нет; на перезарядке
    /// карточку не взять; клавиша C заряжает всё.</summary>
    private static int InputRules()
    {
        _gr.Restart();
        Frame();
        var w = _gr.World;              // Restart() меняет мир местами — ссылкой до него брать нельзя
        _gr.GiveSun(2000);
        int n0 = w.Plants.Count;

        ClickDown(CardX(0), CardY);                     // чистый тап по первой карточке
        ClickUp(CardX(0), CardY);
        Check(w.Plants.Count == n0, "тап по карточке ничего не сажает", "посажено " + w.Plants.Count);
        Check(Str("_toastText").Contains("ПЕРЕТАЩИТЬ"), "тап по карточке → подсказка «нужно перетащить»", Str("_toastText"));
        Check(Ui("Selected") == null, "после тапа рука пуста", "" + Ui("Selected"));
        Check((bool)Ui("DragActive") == false, "после тапа ничего не перетаскивается");

        Plant(0, 2, 4);                                 // а перетаскивание — сажает
        Check(w.Plants.Count == n0 + 1, "перетаскивание сажает", "посажено " + w.Plants.Count);
        Check(w.CooldownLeft("peashooter") > 6.5, "карточка ушла на перезарядку",
              w.CooldownLeft("peashooter").ToString("0.00"));

        ClickDown(CardX(0), CardY);                     // тут же взять её снова — нельзя
        Frame();
        Check((bool)Ui("DragActive") == false, "на перезарядке карточку не взять");
        Check(Str("_toastText").Contains("ПЕРЕЗАРЯДКА"), "и подсказка говорит сколько ждать", Str("_toastText"));

        w.RechargeAll();                                // как клавиша C, но напрямую
        Plant(0, 2, 5);
        Check(w.Plants.Count == n0 + 2, "после перезарядки то же растение сажается снова",
              "посажено " + w.Plants.Count);

        var key = typeof(GameRoot).GetField("KeyRecharge", IP);
        Check(key != null && (KeyCode)key.GetValue(_gr) == KeyCode.C, "за мгновенную перезарядку отвечает C");
        Input.StubKeys.Add(KeyCode.C);
        ClickUp(320, 300);                              // любой кадр с нажатой клавишей
        Check(w.CooldownLeft("peashooter") == 0, "C заряжает все карточки",
              w.CooldownLeft("peashooter").ToString("0.00"));

        // --- главное меню и выбор уровня --------------------------------------
        _gr.ToMenu();
        Frame();
        Check(Scr() == "Menu", "из игры Esc/ToMenu ведёт в главное меню", Scr());
        var mp = Pvz.View.MenuLayout.Card(1).center;               // «МУЛЬТИПЛЕЕР» — заглушка
        ClickDown(mp.x, mp.y); ClickUp(mp.x, mp.y);
        Check(Scr() == "Menu", "заглушка мультиплеера никуда не ведёт", Scr());
        Check(Str("_toastText").Contains("МУЛЬТИПЛЕЕР"), "и говорит, что не собрана", Str("_toastText"));

        UnityEngine.PlayerPrefs.SetInt("pvz.level", 0);           // 1-2 снова заперт
        var adv = Pvz.View.MenuLayout.Card(0).center;              // «ПРИКЛЮЧЕНИЕ»
        ClickDown(adv.x, adv.y); ClickUp(adv.x, adv.y);
        Check(Scr() == "Adventure", "«ПРИКЛЮЧЕНИЕ» открывает выбор уровня", Scr());
        Check(Pvz.View.AdventureLayout.Count == Pvz.Core.CFG.LEVELS.Count,
              "узлов ровно по числу уровней конфига", Pvz.View.AdventureLayout.Count.ToString());
        var n2 = Pvz.View.AdventureLayout.Node(1).center;
        ClickDown(n2.x, n2.y); ClickUp(n2.x, n2.y);
        Check(Scr() == "Adventure", "запертый уровень не запускается", Scr());
        Check(Str("_toastText").Contains("СНАЧАЛА ПРОЙДИ"), "и объясняет, что пройти сначала", Str("_toastText"));

        int selBefore = Sel();
        Input.StubKeys.Add(KeyCode.LeftArrow); Frame();
        Check(Sel() == 0 || Pvz.View.AdventureLayout.Count == 1, "стрелка водит рамку по узлам", Sel().ToString());
        Check(Sel() != selBefore || selBefore == 0, "рамка не стоит на месте", selBefore + "→" + Sel());
        Input.StubKeys.Add(KeyCode.Return); Frame();
        Check(Scr() == "Play" && _gr.LevelIndex == 0, "Enter с открытого узла запускает этот уровень",
              Scr() + "/" + _gr.LevelIndex);

        UnityEngine.PlayerPrefs.SetInt("pvz.level", 1);
        _gr.ToMenu(); Frame();
        Input.StubKeys.Add(KeyCode.Return); Frame();
        Check(Scr() == "Adventure" && Sel() == 1, "без выбора рамка встаёт на последний открытый уровень",
              Scr() + "/" + Sel());
        Input.StubKeys.Add(KeyCode.Return); Frame();
        Check(Scr() == "Play" && _gr.LevelIndex == 1, "и Enter с него ведёт сразу на 1-2",
              Scr() + "/" + _gr.LevelIndex);
        // --- геометрия карты: клики должны попадать ровно туда, где нарисовано ---
        int geo = 0;
        for (int i = 0; i < Pvz.View.AdventureLayout.Count; i++)
        {
            var r = Pvz.View.AdventureLayout.Node(i);
            var c = new UnityEngine.Vector2(Pvz.View.AdventureLayout.CenterX(i), Pvz.View.AdventureLayout.CenterY(i));
            if (!r.Contains(c)) geo |= 1 << (i * 3);
            if (r.x < Pvz.View.AdventureLayout.PanelX || r.xMax > Pvz.View.AdventureLayout.PanelX + Pvz.View.AdventureLayout.PanelW)
                geo |= 2 << (i * 3);
            if (r.y < Pvz.View.AdventureLayout.LawnY || r.yMax > Pvz.View.AdventureLayout.PanelY + Pvz.View.AdventureLayout.PanelH)
                geo |= 4 << (i * 3);
            for (int j = 0; j < i; j++)
            {
                var o = Pvz.View.AdventureLayout.Node(j);
                bool sep = r.xMax <= o.x || o.xMax <= r.x || r.yMax <= o.y || o.yMax <= r.y;
                if (!sep) geo |= 8 << (i * 3 + j);
            }
        }
        Check(geo == 0, "узлы карты: центр внутри, в панели, не налезают друг на друга", "битовая маска " + geo);
        Check(Pvz.View.AdventureLayout.Next == -1 || Pvz.View.AdventureLayout.IsOpen(Pvz.View.AdventureLayout.Next),
              "стрелка «СЛЕДУЮЩИЙ» только на открытом узле",
              Pvz.View.AdventureLayout.Next.ToString());

        // --- выдача наград: ровно одно растение за уровень, по порядку 1-1 → 1-2 ---
        // (берём чистый сейв и «проходим» уровни через Progress.Won — как это делает
        //  GameRoot на событии Win; иначе награды снова слипнутся в одну выдачу)
        UnityEngine.PlayerPrefs.DeleteKey("pvz.plants");
        UnityEngine.PlayerPrefs.DeleteKey("pvz.level");
        var l1 = Pvz.Core.CFG.LEVELS[0];
        var l2 = Pvz.Core.CFG.LEVELS[1];
        Pvz.View.Progress.Won(0, l1);
        Check(Pvz.View.Progress.Has("sunflower") && !Pvz.View.Progress.Has("cherry"),
              "за 1-1 дают только подсолнух, вишня ещё не открыта",
              Pvz.View.Progress.RewardNames(l1));
        var deck = new Pvz.Core.World(l2, 5u, Pvz.View.Progress.Plants());
        Check(deck.Seeds.IndexOf("sunflower") >= 0 && deck.Seeds.IndexOf("cherry") < 0,
              "на 1-2 в пачке подсолнух есть, а вишни ещё нет", string.Join(",", deck.Seeds.ToArray()));
        Pvz.View.Progress.Won(1, l2);
        var deck2 = new Pvz.Core.World(l2, 5u, Pvz.View.Progress.Plants());
        Check(Pvz.View.Progress.Has("cherry") && deck2.Seeds.IndexOf("cherry") >= 0,
              "вишня приходит после 1-2 и попадает в пачку при повторе",
              Pvz.View.Progress.RewardNames(l2) + "/" + string.Join(",", deck2.Seeds.ToArray()));
        UnityEngine.PlayerPrefs.DeleteKey("pvz.plants");
        UnityEngine.PlayerPrefs.DeleteKey("pvz.level");

        // --- экран победы: кнопка «ДАЛЬШЕ» обязана вести вперёд, а не «заново» ---
        // (был баг: кнопка рисовалась одна, а кликалась вся панель, и Enter-путь был
        //  единственный рабочий — клик по кнопке перезапускал текущий уровень)
        _gr.LevelIndex = 0;
        WinRun(210);
        Check(_gr.World.State.ToString() == "Won", "1-1 доигран до победы", _gr.World.State.ToString());
        Check(Pvz.View.Paint.WinHasNext(_gr.World), "на экране победы есть следующий уровень");
        Input.StubKeys.Add(KeyCode.Escape); Frame();
        Check(Scr() == "Menu", "Esc с экрана победы уводит в меню", Scr());

        _gr.LevelIndex = 0;
        WinRun(210);
        ClickDown(40, 300); ClickUp(40, 300);            // за пределами кнопки
        Check(Scr() == "Play" && _gr.LevelIndex == 0 && _gr.World.Time < 1.5,
              "клик мимо кнопки — честное «заново» на том же уровне",
              Scr() + "/" + _gr.LevelIndex + "/t=" + _gr.World.Time.ToString("0.0"));

        _gr.LevelIndex = 0;
        WinRun(210);
        var wb = Pvz.View.Paint.WinButtonRect(_gr.World);
        ClickDown(wb.x + wb.width / 2, wb.y + wb.height / 2);
        ClickUp(wb.x + wb.width / 2, wb.y + wb.height / 2);
        Check(Scr() == "Play" && _gr.LevelIndex == 1 && _gr.World.Level.Id == "1-2",
              "клик по кнопке «ДАЛЬШЕ» ведёт на следующий уровень",
              Scr() + "/" + _gr.LevelIndex + "/" + _gr.World.Level.Id);
        // --- лопата: выдаётся за 1-1, берётся в руку, копает, отменяется ---
        _gr.LevelIndex = 0;
        WinRun(210);
        Check(Pvz.View.Progress.HasTool("shovel"), "лопата выдана наградой за 1-1");
        Check(_gr.World.State.ToString() == "Won", "на 1-1 после 210 с действительно победа", _gr.World.State.ToString());
        _gr.Restart();                                     // свежий газон: копать надо на нём
        var shr = Pvz.View.Paint.ShovelRect(_gr.World.Seeds.Count);
        ClickDown(shr.x + shr.width / 2, shr.y + shr.height / 2);
        ClickUp(shr.x + shr.width / 2, shr.y + shr.height / 2);
        Check(_gr.ShovelArmed, "клик по слоту HUD берёт лопату в руку", "rect=" + shr.x + "," + shr.y);
        Pvz.Core.Fail fd;
        _gr.World.RechargeAll();
        var dp = _gr.World.Place(2, 4, "peashooter", out fd);
        int sunBefore = _gr.World.SunCount;
        Check(dp != null, "посажен горохострел под копку", "fail=" + fd);
        ClickDown(Pvz.Core.Geo.CellX(4) + 32, Pvz.Core.Geo.CellY(2) + 32);
        ClickUp(Pvz.Core.Geo.CellX(4) + 32, Pvz.Core.Geo.CellY(2) + 32);
        Check(_gr.World.Plants.Count == 0, "клик лопатой по клетке выкапывает растение", "n=" + _gr.World.Plants.Count);
        Check(_gr.World.SunCount == sunBefore, "лопата не возвращает солнце — как в оригинале",
              sunBefore + "→" + _gr.World.SunCount);
        Check(!_gr.ShovelArmed, "после копки лопата сама убирается");
        Input.StubKeys.Add(KeyCode.X); Frame();
        Check(_gr.ShovelArmed, "X берёт лопату в руку");
        Input.StubKeys.Add(KeyCode.Escape); Frame();
        Check(!_gr.ShovelArmed, "Esc роняет лопату обратно в слот");
        Input.StubKeys.Add(KeyCode.X); Frame();
        ClickDown(Pvz.Core.Geo.CellX(6) + 32, Pvz.Core.Geo.CellY(0) + 32);
        ClickUp(Pvz.Core.Geo.CellX(6) + 32, Pvz.Core.Geo.CellY(0) + 32);
        Check(!_gr.ShovelArmed && _gr.World.Plants.Count == 0, "пустая клетка: копать нечего, лопата не застревает");
        Check(_gr.World.State == Pvz.Core.WorldState.Playing, "копка не ломает уровень", _gr.World.State.ToString());

        var wb2 = Pvz.View.Paint.WinButtonRect(_gr.World);
        Check(wb2.width > 0 && wb2.y > 0 && wb2.yMax < Pvz.Core.Geo.VIEW_H,
              "прямоугольник кнопки лежит внутри экрана (его же кликают)",
              wb2.x + "," + wb2.y + " " + wb2.width + "x" + wb2.height);

        // ---- анимации и стадии: орех бьётся по-настоящему, зомби ходит ----------
        {
            _gr.Restart(); Frame();
            var ww = _gr.World;
            Pvz.Core.Plant nut = null;
            Pvz.Core.Fail fy = Pvz.Core.Fail.None;
            for (int r = 0; r < 5 && nut == null; r++)
                for (int c = 2; c < 8 && nut == null; c++) { ww.RechargeAll(); nut = ww.Place(r, c, "wallnut", out fy); }
            Check(nut != null, "орех садится (дальше проверяем его стадии)", "fail=" + fy);
            if (nut != null)
            {
                nut.MaxHp = 4000; nut.Hp = 4000;
                Check(nut.Stage == 0 && nut.Bites == 0, "целый орех: стадия 0 и ноль укусов");
                nut.Hp = 2880; Check(nut.Stage == 1, "72% HP — первая стадия: трещины", "st=" + nut.Stage);
                nut.Hp = 2881; Check(nut.Stage == 0, "2881 — ещё целая (порог строгий)", "st=" + nut.Stage);
                nut.Hp = 2000; Check(nut.Stage == 2 && nut.Bites == 2, "2000 HP — откушена макушка, 2 укуса",
                                     "st=" + nut.Stage + " b=" + nut.Bites);
                nut.Hp = 1000; Check(nut.Stage == 3 && nut.Bites == 3, "1000 HP — орех держится наполовину",
                                     "st=" + nut.Stage + " b=" + nut.Bites);
                int prevB = -1; bool mono = true;
                for (int hp = 4000; hp >= 0; hp -= 200)
                {
                    nut.Hp = hp;
                    int b = nut.Bites;
                    if (b < prevB) mono = false;
                    prevB = b;
                }
                Check(mono && prevB == 5, "укусы растут монотонно и доходят до пяти у нуля HP", "n=" + prevB);

                int rx0 = (int)(nut.X - 8), rx1 = (int)(nut.X + 72);
                int ry0 = (int)(nut.Y - 8), ry1 = (int)(nut.Y + 72);
                nut.Hp = 4000; Frame(); var gWhole = Grab();
                nut.Hp = 3200; Frame(); var gSameStage = Grab();     // стадия та же — это «шум» кадра
                nut.Hp = 2000; Frame(); var gNut = Grab();
                int dSame = DiffRect(gWhole, gSameStage, rx0, rx1, ry0, ry1);
                int dStage = DiffRect(gWhole, gNut, rx0, rx1, ry0, ry1);
                Check(dStage > dSame + 60, "стадия скорлупы меняет картинку, а не только числа",
                      "тот же класс: " + dSame + " px, другая стадия: " + dStage + " px");
                nut.Hp = 1900; Frame(); var gB2 = Grab();            // 2 укуса
                nut.Hp = 1200; Frame(); var gB3 = Grab();            // 3 укуса, стадия та же
                int dBite = DiffRect(gB2, gB3, rx0, rx1, ry0, ry1);
                Check(dBite >= 12 && nut.Bites == 3 && nut.Stage == 2, "очередной укус дорисован на скорлупе",
                      "px=" + dBite + " укусов=" + nut.Bites + " стадия=" + nut.Stage);

                nut.Hp = 4000; nut.MaxHp = 4000;
                var zc = ww.SpawnZombie("basic", nut.Row);
                zc.X = nut.X + 26;                       // пасть уже у растения
                Run(12);                                 // 100 урона/с × 12 с = 1200 → 2800 HP
                Check(nut.Stage >= 1, "12 с поедания — скорлупа лопнула сама, без подсказок",
                      "hp=" + nut.Hp.ToString("0") + " st=" + nut.Stage);
                Check(nut.Bites >= 1, "и первый укус нарисован", "b=" + nut.Bites);

                var zw = ww.SpawnZombie("basic", nut.Row == 0 ? 1 : 0);
                zw.X = Pvz.Core.Geo.LAWN_X + 7.4 * Pvz.Core.Geo.TILE;
                int wx0 = (int)(zw.X - 44), wx1 = (int)(zw.X + 44);
                int wy0 = (int)(Pvz.Core.Geo.LAWN_Y + zw.Row * Pvz.Core.Geo.TILE) - 12;
                int wy1 = wy0 + 84;
                Frame(); var g0 = Grab();
                int best = 0;
                for (int i = 0; i < 24; i++)       // 0.4 с = полный цикл 6 fps
                {
                    Frame();
                    int d = DiffRect(g0, Grab(), wx0, wx1, wy0, wy1);
                    if (d > best) best = d;
                }
                Check(best > 200, "шаг зомби — это разные кадры, а не один спрайт (walk-цикл)", "px=" + best);

            // Поставка кадров и темп — то, из-за чего «дерганый зомби» вообще появился:
            // два кадра на 6 fps при 12.8 px/с дают строб, а не шаг.
            var lib = Pvz.View.SpriteLib.Load();
            var ze = lib.Get("assets/zombies/basic.png");
            var walk = ze.Group("walk");
            Check(walk != null && walk.Count == 4, "шаг зомби — 4 кадра", walk == null ? "группы нет" : "n=" + walk.Count);
            var zeat = ze.Group("eat");
            Check(zeat != null && zeat.Count == 2, "еда зомби — 2 кадра", zeat == null ? "группы нет" : "n=" + zeat.Count);
            var ce = lib.Get("assets/plants/chomper.png");
            var chew = ce.Group("chew");
            Check(chew != null && chew.Count == 4, "чемпер пережёвывает 4 кадрами сидя",
                  chew == null ? "группы нет" : "n=" + chew.Count);
            var seen = new System.Collections.Generic.List<UnityEngine.Sprite>();
            for (int i = 0; i < 8; i++)
            {
                var sp = ze.Pick("walk", i / 2.4, 2.4);
                if (sp != null && !seen.Contains(sp)) seen.Add(sp);
            }
            Check(seen.Count == 4, "медленный цикл проходит все 4 кадра за 1.7 с (2.4 к/с)", "уникальных=" + seen.Count);
            var seenChew = new System.Collections.Generic.List<UnityEngine.Sprite>();
            for (int i = 0; i < 8; i++)
            {
                var sp = ce.Pick("chew", i / 2.0, 2.0);
                if (sp != null && !seenChew.Contains(sp)) seenChew.Add(sp);
            }
            Check(seenChew.Count == 4, "жвачка чемпера меняет кадр раз в полсекунды", "уникальных=" + seenChew.Count);

            // Дальность ловли через живой GameRoot (не через голые поля): чемпер обязан
            // брать зомби, идущего по клетке c+2, и не брать того, кто в c+3.
            _gr.Restart(); Frame();
            var wc = _gr.World;
            Pvz.Core.Plant ch = null;
            Pvz.Core.Fail fch = Pvz.Core.Fail.None;
            for (int r = 0; r < 5 && ch == null; r++) { wc.RechargeAll(); ch = wc.Place(r, 3, "chomper", out fch); }
            Check(ch != null, "чемпер садится (дальность ловли)", "fail=" + fch);
            if (ch != null)
            {
                var fz = wc.SpawnZombie("basic", ch.Row);
                fz.X = Pvz.Core.Geo.CellX(ch.Col + 3) + Pvz.Core.Geo.TILE / 2;
                Run(0.35);
                Check(fz.State != "die", "из клетки c+3 не тянется", "state=" + fz.State);
                fz.X = Pvz.Core.Geo.CellX(ch.Col + 2) + Pvz.Core.Geo.TILE / 2;
                Run(0.35);
                Check(fz.State == "die", "а из клетки c+2 — схавал (две клетки вперёд)", "state=" + fz.State);
                Check(ch.ChewTimer > 19, "и сразу сел жевать", "chew=" + ch.ChewTimer.ToString("F1"));
            }
                ww.HurtZombie(zw, (int)(zw.MaxHp * 0.5));
                Check(zw.Stage == 1, "на 50% HP у зомби нет руки — своя картинка и свой цикл", "st=" + zw.Stage);
                Check(Pvz.Core.CFG.Plant("wallnut").Dmg.Count == 3
                      && Pvz.Core.CFG.Plant("wallnut").Bites.Count == 5,
                      "в конфиге три стадии скорлупы и пять укусов",
                      Pvz.Core.CFG.Plant("wallnut").Dmg.Count + "/" + Pvz.Core.CFG.Plant("wallnut").Bites.Count);
            }
        }

        Console.WriteLine("ПРОВЕРКИ ВВОДА: " + (_checkTotal - _checkFails) + "/" + _checkTotal + " ok");
        return _checkFails == 0 ? 0 : 1;
    }

    // ------------------------------------------------------------------ вывод
    private static string FindBinDir()
    {
        var dir = new DirectoryInfo(Directory.GetCurrentDirectory());
        for (int i = 0; i < 6 && dir != null; i++, dir = dir.Parent)
        {
            string p = Path.Combine(dir.FullName, "unity", "Verify", "ViewCheck", "renderbin");
            if (Directory.Exists(p)) return p;
            p = Path.Combine(dir.FullName, "Verify", "ViewCheck", "renderbin");
            if (Directory.Exists(p)) return p;
        }
        return "";
    }

    private static int LayerIndex(string name)
    {
        var all = Pvz.View.Sort.All;
        for (int i = 0; i < all.Length; i++) if (all[i] == name) return i;
        return all.Length;
    }

    /// <summary>Пиксели кадра в память (тот же композит, что пишет Dump) — нужно для
    /// проверок «картинка действительно меняется»: кадр шага, кадр укуса.</summary>
    private static byte[] Grab()
    {
        DumpTo(null);
        var copy = new byte[_buf.Length];
        Buffer.BlockCopy(_buf, 0, copy, 0, copy.Length);
        return copy;
    }

    /// <summary>Число отличающихся пикселей в прямоугольнике (в координатах View).</summary>
    private static int DiffRect(byte[] a, byte[] b, int x0, int x1, int y0, int y1)
    {
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > _w) x1 = _w;
        if (y1 > _h) y1 = _h;
        int n = 0;
        for (int y = y0; y < y1; y++)
            for (int x = x0; x < x1; x++)
            {
                int i = (y * _w + x) * 4;
                if (a[i] != b[i] || a[i + 1] != b[i + 1] || a[i + 2] != b[i + 2]) n++;
            }
        return n;
    }

    private static int DiffPixels(byte[] a, byte[] b)
    {
        int n = 0;
        for (int i = 0; i < a.Length; i += 4)
            if (a[i] != b[i] || a[i + 1] != b[i + 1] || a[i + 2] != b[i + 2]) n++;
        return n;
    }

    private static void Dump(string path) { DumpTo(path); }

    private static void DumpTo(string path)
    {
        _buf = new byte[_w * _h * 4];
        // сортировка устойчивая (OrderBy), чтобы при равных ключах работал порядок создания
        var list = new List<SpriteRenderer>(StubScene.Renderers);
        var keyed = new List<(int layer, int order, int idx, SpriteRenderer sr)>();
        for (int i = 0; i < list.Count; i++)
            keyed.Add((LayerIndex(list[i].sortingLayerName), list[i].sortingOrder, i, list[i]));
        keyed.Sort((a, b) => a.layer != b.layer ? a.layer.CompareTo(b.layer)
                          : a.order != b.order ? a.order.CompareTo(b.order) : a.idx.CompareTo(b.idx));
        foreach (var k in keyed) Blit(k.sr);
        if (path == null) return;
        using (var fs = new FileStream(path, FileMode.Create, FileAccess.Write))
        {
            fs.Write(Header(_w, _h), 0, 8);
            fs.Write(_buf, 0, _buf.Length);
        }
    }

    private static byte[] Header(int w, int h)
    {
        var b = new byte[8];
        Buffer.BlockCopy(BitConverter.GetBytes(w), 0, b, 0, 4);
        Buffer.BlockCopy(BitConverter.GetBytes(h), 0, b, 4, 4);
        return b;
    }

    private static void Blit(SpriteRenderer sr)
    {
        if (sr == null || sr.sprite == null) return;
        if (!sr.enabled) return;
        var tr = sr.transform;
        if (tr == null || tr.gameObject == null || !tr.gameObject.activeSelf) return;

        var sp = sr.sprite;
        var tex = sp.texture;
        if (tex == null) return;
        Color32[] px = tex.StubPixels;
        if (px == null) return;

        Vector3 s = tr.lossyScale;
        double w = sp.rect.width * Math.Abs(s.x);
        double h = sp.rect.height * Math.Abs(s.y);
        if (w < 0.5 || h < 0.5) return;
        double left = tr.position.x - sp.pivot.x * w;
        double top = -tr.position.y - (1.0 - sp.pivot.y) * h;

        Color c = sr.color;
        bool add = sr.sharedMaterial != null && sr.sharedMaterial.name == "PvzAdditive";
        int texW = tex.width;
        double kx = sp.rect.width / w, ky = sp.rect.height / h;

        int y0 = Math.Max(0, (int)Math.Floor(top)), y1 = Math.Min(_h, (int)Math.Ceiling(top + h));
        int x0 = Math.Max(0, (int)Math.Floor(left)), x1 = Math.Min(_w, (int)Math.Ceiling(left + w));
        for (int y = y0; y < y1; y++)
        {
            int sy = (int)((y - top) * ky);
            if (sy < 0) sy = 0; if (sy >= sp.rect.height) sy = (int)sp.rect.height - 1;
            int row = (int)(sp.rect.height - 1 - sy + sp.rect.y);         // GetPixels32: строка 0 = снизу
            for (int x = x0; x < x1; x++)
            {
                int sx = (int)((x - left) * kx);
                if (sx < 0) sx = 0; if (sx >= sp.rect.width) sx = (int)sp.rect.width - 1;
                Color32 p = px[row * texW + sx + (int)sp.rect.x];
                float a = p.a / 255f * c.a;
                if (a <= 0.002f) continue;
                int r = (int)(p.r * c.r), g = (int)(p.g * c.g), b = (int)(p.b * c.b);
                int o = (y * _w + x) * 4;
                if (add)
                {
                    _buf[o] = (byte)Math.Min(255, _buf[o] + r * a);
                    _buf[o + 1] = (byte)Math.Min(255, _buf[o + 1] + g * a);
                    _buf[o + 2] = (byte)Math.Min(255, _buf[o + 2] + b * a);
                    _buf[o + 3] = 255;
                }
                else
                {
                    _buf[o] = (byte)(_buf[o] + (r - _buf[o]) * a);
                    _buf[o + 1] = (byte)(_buf[o + 1] + (g - _buf[o + 1]) * a);
                    _buf[o + 2] = (byte)(_buf[o + 2] + (b - _buf[o + 2]) * a);
                    _buf[o + 3] = (byte)Math.Min(255, _buf[o + 3] + p.a * c.a);
                }
            }
        }
    }
}
