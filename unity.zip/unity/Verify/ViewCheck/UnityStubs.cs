// ============================================================================
//  Заглушки UnityEngine — НУЖНЫ ТОЛЬКО ДЛЯ КОМПИЛЯЦИИ в checks-проекте.
//  В Unity этот файл не участвует: он лежит вне Assets/ (и не попадает в сборку).
//  Цель: проверить, что весь слой View компилируется как C# 9 (Unity 2022.3)
//  и что сигнатуры API использованы правильно. Это НЕ подмена логики: игровой
//  код выполняется настоящий, просто без движка под ногами.
// ============================================================================
#pragma warning disable CS0169, CS0649, CS0414
using System;

namespace UnityEngine
{
    public struct Vector2
    {
        public float x, y;
        public Vector2(float x, float y) { this.x = x; this.y = y; }
        public static Vector2 zero { get { return new Vector2(0, 0); } }
        public static implicit operator Vector3(Vector2 v) { return new Vector3(v.x, v.y, 0); }
        public static Vector2 operator +(Vector2 a, Vector2 b) { return new Vector2(a.x + b.x, a.y + b.y); }
        public static Vector2 operator -(Vector2 a, Vector2 b) { return new Vector2(a.x - b.x, a.y - b.y); }
        public static Vector2 operator *(Vector2 a, float b) { return new Vector2(a.x * b, a.y * b); }
        public override string ToString() { return "(" + x + ", " + y + ")"; }
    }

    public struct Vector4
    {
        public float x, y, z, w;
        public Vector4(float x, float y, float z, float w) { this.x = x; this.y = y; this.z = z; this.w = w; }
        public static Vector4 zero { get { return new Vector4(0, 0, 0, 0); } }
    }

    public struct Vector3
    {
        public float x, y, z;
        public Vector3(float x, float y, float z) { this.x = x; this.y = y; this.z = z; }
        public Vector3(float x, float y) { this.x = x; this.y = y; z = 0; }
        public static Vector3 zero { get { return new Vector3(0, 0, 0); } }
        public static Vector3 one { get { return new Vector3(1, 1, 1); } }
        public static implicit operator Vector2(Vector3 v) { return new Vector2(v.x, v.y); }
        public static Vector3 operator +(Vector3 a, Vector3 b) { return new Vector3(a.x + b.x, a.y + b.y, a.z + b.z); }
        public static Vector3 operator -(Vector3 a, Vector3 b) { return new Vector3(a.x - b.x, a.y - b.y, a.z - b.z); }
        public static Vector3 operator *(Vector3 a, float b) { return new Vector3(a.x * b, a.y * b, a.z * b); }
        public static Vector3 operator /(Vector3 a, float b) { return new Vector3(a.x / b, a.y / b, a.z / b); }
        public float magnitude { get { return (float)Math.Sqrt(x * x + y * y + z * z); } }
    }

    public struct Quaternion
    {
        public float x, y, z, w;
        public static Quaternion identity { get { var q = new Quaternion(); q.w = 1; return q; } }
        public static Quaternion Euler(float x, float y, float z) { return identity; }
    }

    public struct Rect
    {
        public float x, y, width, height;
        public Rect(float x, float y, float w, float h) { this.x = x; this.y = y; width = w; height = h; }
        public Vector2 center { get { return new Vector2(x + width / 2, y + height / 2); } }
        // кромки — есть в Rect 2022.3 (xMin/yMin/xMax/yMax), без них тесты геометрии
        // пришлось бы переписывать на «x + width» и смысл проверки бы потерялся
        public float xMin { get { return x; } }
        public float yMin { get { return y; } }
        public float xMax { get { return x + width; } }
        public float yMax { get { return y + height; } }
        public bool Contains(Vector2 p) { return p.x >= x && p.x <= x + width && p.y >= y && p.y <= y + height; }
    }

    /// <summary>Заглушка PlayerPrefs: реальный API 2022.3, но всё в памяти
    /// (офлайн-харнесс не должен гадать, что было в реестре прошлым прогоном).</summary>
    public static class PlayerPrefs
    {
        private static readonly System.Collections.Generic.Dictionary<string, object> V =
            new System.Collections.Generic.Dictionary<string, object>();
        public static void Wipe() { V.Clear(); }
        public static bool HasKey(string key) { return V.ContainsKey(key); }
        public static int GetInt(string key, int defaultValue = 0) { object o; return V.TryGetValue(key, out o) ? (int)o : defaultValue; }
        public static void SetInt(string key, int value) { V[key] = value; }
        public static float GetFloat(string key, float defaultValue = 0f) { object o; return V.TryGetValue(key, out o) ? (float)o : defaultValue; }
        public static void SetFloat(string key, float value) { V[key] = value; }
        public static string GetString(string key, string defaultValue = "") { object o; return V.TryGetValue(key, out o) ? (string)o : defaultValue; }
        public static void SetString(string key, string value) { V[key] = value; }
        public static void DeleteKey(string key) { V.Remove(key); }
        public static void DeleteAll() { V.Clear(); }
        public static void Save() { }
        public static string[] GetKeys() { var a = new string[V.Keys.Count]; V.Keys.CopyTo(a, 0); return a; }
    }

    public struct Color
    {
        public float r, g, b, a;
        public Color(float r, float g, float b, float a = 1f) { this.r = r; this.g = g; this.b = b; this.a = a; }
        public static Color white { get { return new Color(1, 1, 1, 1); } }
        public static implicit operator Color32(Color c)
        {
            return new Color32((byte)(c.r * 255), (byte)(c.g * 255), (byte)(c.b * 255), (byte)(c.a * 255));
        }
        public static implicit operator Color(Color32 c)
        {
            return new Color(c.r / 255f, c.g / 255f, c.b / 255f, c.a / 255f);
        }
    }

    public struct Color32
    {
        public byte r, g, b, a;
        public Color32(byte r, byte g, byte b, byte a) { this.r = r; this.g = g; this.b = b; this.a = a; }
        public Color32(byte r, byte g, byte b) { this.r = r; this.g = g; this.b = b; this.a = 255; }
    }

    public static class Mathf
    {
        public const float PI = 3.14159265358979f;
        public static float Min(float a, float b) { return a < b ? a : b; }
        public static float Max(float a, float b) { return a > b ? a : b; }
        public static int Min(int a, int b) { return a < b ? a : b; }
        public static int Max(int a, int b) { return a > b ? a : b; }
        public static int Min(int a, int b, int c) { return Min(Min(a, b), c); }
        public static int Max(int a, int b, int c) { return Max(Max(a, b), c); }
        public static float Min(float a, float b, float c) { return Min(Min(a, b), c); }
        public static float Max(float a, float b, float c) { return Max(Max(a, b), c); }
        public const float Rad2Deg = 57.29578f;
        public const float Deg2Rad = 0.01745329f;
        public static float Abs(float a) { return a < 0 ? -a : a; }
        public static float Clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
        public static float Clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
        public static int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
        public static float Round(float v) { return (float)Math.Round(v, MidpointRounding.ToEven); }
        public static int RoundToInt(float v) { return (int)Math.Round(v, MidpointRounding.ToEven); }
        public static float Floor(float v) { return (float)Math.Floor(v); }
        public static int FloorToInt(float v) { return (int)Math.Floor(v); }
        public static float Sin(float v) { return (float)Math.Sin(v); }
        public static float Cos(float v) { return (float)Math.Cos(v); }
        public static float Sqrt(float v) { return (float)Math.Sqrt(v); }
    }

    public static class Random
    {
        private static readonly System.Random R = new System.Random(1);
        public static float value { get { return (float)R.NextDouble(); } }
        public static float Range(float a, float b) { return a + value * (b - a); }
        public static int Range(int a, int b) { return a + R.Next(b - a); }
    }

    public enum TextureFormat { RGBA32, ARGB32, RGB24 }
    public enum FilterMode { Point, Bilinear, Trilinear }
    public enum TextureWrapMode { Repeat, Clamp, Mirror }
    public enum CameraClearFlags { Skybox, SolidColor, Depth }
    public enum SpriteMeshType { FullRect, Tight }
    public enum RenderTextureFormat { Default }

    public class Object
    {
        public string name = "";
        public static void Destroy(Object o) { }
        public static T FindObjectOfType<T>() where T : Object { return null; }
        public static void DontDestroyOnLoad(Object o) { }
    }

    public class GameObject : Object
    {
        public static readonly System.Collections.Generic.List<GameObject> StubCreated =
            new System.Collections.Generic.List<GameObject>();
        public Transform transform;
        public bool activeSelf = true;
        public string tag = "";
        public GameObject()
        {
            transform = new Transform { gameObject = this };
            StubCreated.Add(this);                       // харнессам видно, что создал редакторский код
        }
        public GameObject(string n) : this() { name = n; }
        public T AddComponent<T>() where T : Component
        {
            var c = (T)System.Activator.CreateInstance(typeof(T));
            c.gameObject = this;
            c.transform = transform;
            comps.Add(c);
            var sr = c as SpriteRenderer;
            if (sr != null) StubScene.Renderers.Add(sr);
            return c;
        }
        public readonly System.Collections.Generic.List<Component> comps =
            new System.Collections.Generic.List<Component>();
        public T GetComponent<T>() where T : class
        {
            for (int i = 0; i < comps.Count; i++) { var c = comps[i] as T; if (c != null) return c; }
            return null;
        }
        public T GetComponentInChildren<T>(bool includeInactive) where T : class { return GetComponent<T>(); }
        public T[] GetComponentsInChildren<T>() where T : class { return GetComponentsInChildren<T>(true); }
        public T[] GetComponentsInChildren<T>(bool includeInactive) where T : class
        {
            var r = new System.Collections.Generic.List<T>();
            for (int i = 0; i < comps.Count; i++) { var c = comps[i] as T; if (c != null) r.Add(c); }
            return r.ToArray();
        }
        public void SetActive(bool v) { activeSelf = v; }
    }

    public class Transform : Object
    {
        public GameObject gameObject;
        public Vector3 localPosition, localScale = Vector3.one;
        public Quaternion rotation = Quaternion.identity, localRotation = Quaternion.identity;
        public Transform parent;
        public void SetParent(Transform p, bool worldPositionStays) { parent = p; }

        // как в Unity: position — мировая позиция (учитывает родителей и их масштаб)
        public Vector3 position
        {
            get { return parent == null ? localPosition
                    : parent.position + new Vector3(parent.lossyScale.x * localPosition.x,
                                                     parent.lossyScale.y * localPosition.y, 0f); }
            set
            {
                var pp = parent == null ? Vector3.zero : parent.position;
                localPosition = new Vector3(value.x - pp.x, value.y - pp.y, 0f);
            }
        }
        public Vector3 lossyScale
        {
            get { return parent != null ? new Vector3(parent.lossyScale.x * localScale.x,
                                                       parent.lossyScale.y * localScale.y, 1f) : localScale; }
        }
    }

    public class Component : Object
    {
        public GameObject gameObject;
        public Transform transform;
    }

    public class Behaviour : Component { public bool enabled = true; }
    public class MonoBehaviour : Behaviour { }

    public sealed class Sprite : Object
    {
        public Rect rect, textureRect;
        public Texture2D texture;
        public Vector2 pivot;
        public float pixelsPerUnit = 1f;
        public static Sprite Create(Texture2D tex, Rect rect, Vector2 pivot, float ppu,
                                     bool generateMipMap = false, bool recalculateBounds = false)
        {
            var sp = new Sprite { texture = tex, rect = rect, textureRect = rect, pivot = pivot, pixelsPerUnit = ppu };
            if (tex != null) sp.name = tex.name;
            return sp;
        }
        public static Sprite Create(Texture2D tex, Rect rect, Vector2 pivot, float ppu, bool gen, bool recalc, SpriteMeshType t)
        {
            return Create(tex, rect, pivot, ppu);
        }
    }

    public class Texture : Object
    {
        public int width = 1, height = 1;
        public FilterMode filterMode;
        public TextureWrapMode wrapMode;
    }

    public class Texture2D : Texture
    {
        private Color32[] _px;
        public Texture2D(int w, int h, TextureFormat f = TextureFormat.RGBA32, bool mipChain = false)
        {
            width = w; height = h; _px = new Color32[w * h];
        }
        public Color32[] StubPixels { get { return _px; } }
        public void SetPixels32(Color32[] px) { Array.Copy(px, _px, Math.Min(px.Length, _px.Length)); }
        public Color32[] GetPixels32() { return _px; }
        public void SetPixel(int x, int y, Color c) { if ((uint)x < (uint)width && (uint)y < (uint)height) _px[y * width + x] = c; }
        public void Apply(bool updateMipChain = false, bool linear = false) { }
    }

    public class RenderTexture : Texture
    {
        public static RenderTexture GetTemporary(int w, int h, int d, RenderTextureFormat f) { return new RenderTexture { width = w, height = h }; }
        public static void ReleaseTemporary(RenderTexture rt) { }
    }

    // enabled живёт на Renderer: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Renderer-enabled.html
    // (у Component его нет, поэтому переопределять в наследниках нечем — `new` дал бы CS0109)
    public class Renderer : Component
    {
        public Material sharedMaterial;
        public Material material;
        public bool enabled = true;
    }

    public class SpriteRenderer : Renderer
    {
        public Sprite sprite;
        public Color color = Color.white;
        public string sortingLayerName = "Default";
        public int sortingOrder;
    }

    public sealed class MeshFilter : Component { public Mesh mesh; public Mesh sharedMesh; }
    public class MeshRenderer : Renderer { }
    public sealed class Mesh : Object { }

    public sealed class Shader : Object
    {
        public static Shader Find(string name) { return new Shader { name = name }; }
    }

    public sealed class Material : Object
    {
        public Material() { }
        public Material(Shader s) { if (s != null) name = s.name; }
        public void SetInt(string n, int v) { }
        public void SetFloat(string n, float v) { }
        public void SetColor(string n, Color c) { }
    }

    public sealed class Camera : Behaviour
    {
        public static Camera main;
        public bool orthographic;
        public float orthographicSize = 5f, aspect = 1.5f;
        public CameraClearFlags clearFlags;
        public Color backgroundColor;
        public int pixelWidth = 1280, pixelHeight = 720;
        public int cullingMask = -1;
        // как в Unity: мир = центр камеры + смещение от центра экрана (орто-камера)
        public Vector3 ScreenToWorldPoint(Vector3 p)
        {
            float pw = pixelWidth > 0 ? pixelWidth : 1f, ph = pixelHeight > 0 ? pixelHeight : 1f;
            float hs = orthographicSize > 0f ? orthographicSize : ph * 0.5f;
            var cp = transform != null ? transform.position : Vector3.zero;
            float wx = cp.x + (p.x / pw - 0.5f) * (2f * hs * (pw / ph));
            float wy = cp.y + (p.y / ph - 0.5f) * (2f * hs);
            return new Vector3(wx, wy, p.z);
        }
    }

    public sealed class AudioListener : Behaviour { public static float volume = 1f; }

    public sealed class AudioSource : Behaviour
    {
        public bool playOnAwake, loop;
        public float volume = 1f, spatialBlend;
        public AudioClip clip;
        public void PlayOneShot(AudioClip c, float v = 1f) { }
        public void Play() { }
        public void Stop() { }
    }

    public sealed class AudioClip : Object { public float length = 0.2f; public int channels = 1; public int frequency = 22050; }

    public static class Resources
    {
        public static string StubBinDir = "";                 // папка с .bin из tools/export_unity.py
        private static readonly System.Collections.Generic.Dictionary<string, Sprite> _cache =
            new System.Collections.Generic.Dictionary<string, Sprite>();

        private static Sprite LoadSprite(string path)
        {
            Sprite sp;
            if (_cache.TryGetValue(path, out sp)) return sp;
            string key = path;
            if (key.StartsWith("Pvz/")) key = key.Substring(4);
            key = key.Replace('/', '_');
            if (key.EndsWith(".png")) key = key.Substring(0, key.Length - 4);
            string file = System.IO.Path.Combine(StubBinDir, key + ".bin");
            if (StubBinDir == "" || !System.IO.File.Exists(file)) return null;
            var bytes = System.IO.File.ReadAllBytes(file);
            int w = BitConverter.ToInt32(bytes, 0), h = BitConverter.ToInt32(bytes, 4);
            var tex = new Texture2D(w, h) { name = key };
            var px = new Color32[w * h];
            for (int i = 0; i < w * h; i++)
            {
                int o = 8 + i * 4;
                px[i] = new Color32(bytes[o], bytes[o + 1], bytes[o + 2], bytes[o + 3]);
            }
            tex.SetPixels32(px);
            int slash = path.LastIndexOf('/');
            string nm = slash >= 0 ? path.Substring(slash + 1) : path;
            var spr = Sprite.Create(tex, new Rect(0, 0, w, h), new Vector2(0f, 1f), 1f);
            spr.name = nm;
            _cache[path] = spr;
            return spr;
        }

        public static void StubClearCache() { _cache.Clear(); }

        public static T Load<T>(string path) where T : Object
        {
            if (typeof(T) == typeof(Sprite)) return (T)(Object)LoadSprite(path);
            return null;
        }

        public static T[] LoadAll<T>(string path) where T : Object
        {
            if (typeof(T) != typeof(Sprite) || StubBinDir == "" || !System.IO.Directory.Exists(StubBinDir))
                return new T[0];
            string key = path;
            if (key.StartsWith("Pvz/")) key = key.Substring(4);
            key = key.Replace('/', '_');
            var list = new System.Collections.Generic.List<Sprite>();
            foreach (var f in System.IO.Directory.GetFiles(StubBinDir, key + "_*.bin"))
            {
                string rel = "Pvz/" + key.Replace('_', '/');
                var sp = LoadSprite(rel + "/" + System.IO.Path.GetFileNameWithoutExtension(f).Substring(key.Length + 1));
                if (sp != null) list.Add(sp);
            }
            list.Sort((a, b) => string.Compare(a.name, b.name, StringComparison.Ordinal));
            return (T[])(object)list.ToArray();
        }
    }

    /// <summary>Реестр всех SpriteRenderer'ов — чтобы харнесс мог сам их наслоить.</summary>
    public static class StubScene
    {
        public static readonly System.Collections.Generic.List<SpriteRenderer> Renderers =
            new System.Collections.Generic.List<SpriteRenderer>();
        public static void Clear() { Renderers.Clear(); Resources.StubClearCache(); }
    }

    public static class Debug
    {
        public static bool isDebugBuild = true;
        public static bool record = false;                       // харнессы включают, чтобы читать вывод
        public static readonly System.Collections.Generic.List<string> Logs =
            new System.Collections.Generic.List<string>();
        public static readonly System.Collections.Generic.List<string> Warnings =
            new System.Collections.Generic.List<string>();
        static void Add(string s) { if (record) Logs.Add(s ?? ""); }
        public static void Log(object o) { Add(o == null ? "" : o.ToString()); }
        public static void LogWarning(object o) { Add(o == null ? "" : o.ToString()); if (record) Warnings.Add(Logs[Logs.Count - 1]); }
        public static void LogError(object o) { Add(o == null ? "" : o.ToString()); if (record) Warnings.Add("ERR " + o); }
        public static void Clear() { Logs.Clear(); Warnings.Clear(); }
        public static bool LastContains(string sub) { return Logs.Count > 0 && Logs[Logs.Count - 1].Contains(sub); }
        public static bool AnyContains(string sub)
        {
            for (int i = 0; i < Logs.Count; i++) if (Logs[i].Contains(sub)) return true;
            return false;
        }
    }

    public static class Application { public static bool isPlaying = true; public static string dataPath = "."; }

    public enum KeyCode
    {
        None = 0, Backspace = 8, Tab = 9, Return = 13, Escape = 27, Space = 32,
        Exclaim = 49, Alpha1 = 49, Alpha2 = 50, Alpha3 = 51, Alpha4 = 52, Alpha5 = 53, Alpha6 = 54,
        A = 97, C = 99, D = 100, E = 101, M = 109, P = 112, R = 114, S = 115, W = 119,
        X = 120,        // в Unity KeyCode.X == 120 (строчная буква как в ASCII), проверено по docs 2022.3
        KeypadEnter = 330, UpArrow = 273, DownArrow = 274, LeftArrow = 276, RightArrow = 275,
    }

    public static class Input
    {
        public static Vector3 mousePosition = new Vector3(100, 100, 0);
        public static bool StubDown0, StubUp0, StubDown1, StubHeld0;
        public static System.Collections.Generic.HashSet<KeyCode> StubKeys = new System.Collections.Generic.HashSet<KeyCode>();
        public static bool GetMouseButton(int b) { return b == 0 ? StubHeld0 : false; }
        public static bool GetMouseButtonDown(int b) { return b == 0 ? StubDown0 : b == 1 ? StubDown1 : false; }
        public static bool GetMouseButtonUp(int b) { return b == 0 ? StubUp0 : false; }
        public static bool GetKeyDown(KeyCode k) { return StubKeys.Contains(k); }
        public static bool GetKeyUp(KeyCode k) { return false; }
        public static bool GetKey(KeyCode k) { return false; }
        public static float axisHorizontal = 0f;
        public static void StubEndFrame() { StubDown0 = StubUp0 = StubDown1 = false; StubKeys.Clear(); }
    }

    public static class Time
    {
        public static float deltaTime = 1f / 60f, unscaledDeltaTime = 1f / 60f, time = 0f, realtimeSinceStartup = 0f;
    }

    public static class QualitySettings
    {
        public static int VSyncCount = 0;
        public static int shadowDistance = 0;
        public static int masterTextureLimit = 0;
    }

    [AttributeUsage(AttributeTargets.Class)]
    public sealed class DefaultExecutionOrderAttribute : Attribute { public DefaultExecutionOrderAttribute(int o) { } }
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class DisallowMultipleComponentAttribute : Attribute { }
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class ExecuteAlwaysAttribute : Attribute { }
    [AttributeUsage(AttributeTargets.Field)]
    public sealed class SerializeFieldAttribute : Attribute { }
    [AttributeUsage(AttributeTargets.Field)]
    public sealed class TooltipAttribute : Attribute { public TooltipAttribute(string s) { } }
    [AttributeUsage(AttributeTargets.Field)]
    public sealed class RangeAttribute : Attribute { public RangeAttribute(float a, float b) { } }
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class ContextMenuAttribute : Attribute { public ContextMenuAttribute(string s) { } }
}

namespace UnityEngine.SceneManagement
{
    public struct Scene
    {
        public string path, name;
        public bool isDirty, isValid_;
        public GameObject[] roots;                 // стаб: что лежит в сцене
        public bool IsValid() { return isValid_ || path != null || name != null; }
        public GameObject[] GetRootGameObjects() { return roots ?? new GameObject[0]; }
    }
}
