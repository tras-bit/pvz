// ============================================================================
//  Проверка C#-ядра без Unity: (1) паритет с JS-симуляцией, (2) порт тестов.
//
//    cd unity/Verify && dotnet run -c Release -- trace > /tmp/cs_trace.txt
//    cd unity/Verify && dotnet run -c Release -- test
//
//  Трейс сравнивается с `node pvz-pixel/tools/unity_parity.mjs` — см. tools/unity_parity_check.sh.
// ============================================================================
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Pvz.Core;

internal static class Program
{
    private const uint SEED = 1337u;
    private const double DT = 1.0 / 120.0;
    private const int EVERY = 2;

    private static string F(int digits, double v)
    {
        // ровно как в JS: Math.round(v*10^k)/10^k, где round = floor(x + 0.5)
        double m = Math.Pow(10, digits);
        double r = Math.Floor(v * m + 0.5) / m;
        if (r == 0) r = 0;                                   // JS роняет знак у «-0»
        return r.ToString("F" + digits.ToString(CultureInfo.InvariantCulture), CultureInfo.InvariantCulture);
    }
    private static string F3(double v) { return F(3, v); }
    private static string F4(double v) { return F(4, v); }
    private static string F6(double v) { return F(6, v); }

    private static string Snap(World w)
    {
        var sb = new StringBuilder();
        sb.Append("t=").Append(F6(w.Time)).Append(" sun=").Append(w.SunCount)
          .Append(" st=").Append(W(w.State)).Append(" wi=").Append(w.WaveIndex)
          .Append(" sp=").Append(w.SpawnedZombies).Append(" kl=").Append(w.KilledZombies)
          .Append(" q=").Append(w.SpawnQueueCount);
        foreach (var p in w.Plants) sb.Append(" P:").Append(p.Id).Append(':').Append(p.Type).Append(':').Append(p.Col).Append(':').Append(p.Row).Append(':').Append(F3(p.Hp));
        foreach (var z in w.Zombies) sb.Append(" Z:").Append(z.Id).Append(':').Append(z.Row).Append(':').Append(F3(z.X)).Append(':').Append(F3(z.Hp)).Append(':').Append(z.State).Append(':').Append(z.Stage).Append(':').Append(F3(z.ArmorHp));
        foreach (var e in w.Peas) sb.Append(" E:").Append(e.Id).Append(':').Append(e.Row).Append(':').Append(F3(e.X)).Append(':').Append(F3(e.Y));
        foreach (var s in w.Suns) sb.Append(" S:").Append(s.Id).Append(':').Append(s.Kind).Append(':').Append(F3(s.X)).Append(':').Append(F3(s.Y)).Append(':').Append(s.State).Append(':').Append(F4(s.Fade));
        foreach (var m in w.Mowers) sb.Append(" M:").Append(m.Row).Append(':').Append(m.State).Append(':').Append(F3(m.X)).Append(':').Append(m.Gone ? 1 : 0);
        return sb.ToString();
    }

    private static string W(WorldState s) { return s == WorldState.Playing ? "playing" : (s == WorldState.Won ? "won" : "lost"); }

    // ------------------------------------------------------------------ trace
    private sealed class TracePlan { public double At; public string Type; public int Col; public bool Taken; }

    private static string Run(string name, double seconds, Action<World, double, int> step, int levelIdx = 0)
    {
        var w = new World(CFG.LEVELS[levelIdx], SEED);
        var sb = new StringBuilder();
        sb.Append("# ").Append(name).Append('\n');
        int n = (int)Math.Round(seconds / DT);
        for (int i = 0; i < n; i++)
        {
            if (step != null) step(w, i * DT, i);
            w.Update(DT);
            w.DrainEvents();
            if (i % EVERY == 0) sb.Append(Snap(w)).Append('\n');
        }
        return sb.ToString();
    }

    private static string Trace()
    {
        var idle = Run("idle", 150, null);
        var plan = new List<TracePlan>
        {
            new TracePlan { At = 0.5, Type = "sunflower", Col = 0 }, new TracePlan { At = 3, Type = "sunflower", Col = 1 },
            new TracePlan { At = 20, Type = "peashooter", Col = 2 }, new TracePlan { At = 26, Type = "peashooter", Col = 3 },
            new TracePlan { At = 40, Type = "sunflower", Col = 4 }, new TracePlan { At = 52, Type = "peashooter", Col = 5 },
            new TracePlan { At = 66, Type = "sunflower", Col = 6 }, new TracePlan { At = 70, Type = "peashooter", Col = 7 },
            new TracePlan { At = 84, Type = "peashooter", Col = 8 },
        };
        var farmer = Run("farmer", 240, (w, t, i) =>
        {
            w.CollectAllSuns();
            foreach (var p in plan)
            {
                if (p.Taken) continue;
                if (p.At <= t) { p.Taken = true; Fail f; w.Place(2, p.Col, p.Type, out f); }
            }
        });
        // 3) «1-2»: три полосы, рандомайзер состава волн (ряд+тип из roster),
        //    конус на броне и вишня — единственный способ быстро снять 3×3.
        var plan2 = new List<TracePlan2>
        {
            new TracePlan2 { At = 0.6, Type = "sunflower", Col = 1, Row = 1 }, new TracePlan2 { At = 2, Type = "sunflower", Col = 3, Row = 2 },
            new TracePlan2 { At = 6, Type = "peashooter", Col = 5, Row = 1 }, new TracePlan2 { At = 10, Type = "sunflower", Col = 7, Row = 3 },
            new TracePlan2 { At = 16, Type = "peashooter", Col = 2, Row = 2 }, new TracePlan2 { At = 24, Type = "cherry", Col = 4, Row = 1 },
            new TracePlan2 { At = 30, Type = "peashooter", Col = 8, Row = 3 }, new TracePlan2 { At = 38, Type = "sunflower", Col = 6, Row = 2 },
            new TracePlan2 { At = 46, Type = "cherry", Col = 5, Row = 3 }, new TracePlan2 { At = 58, Type = "peashooter", Col = 4, Row = 1 },
            new TracePlan2 { At = 70, Type = "sunflower", Col = 2, Row = 2 }, new TracePlan2 { At = 84, Type = "cherry", Col = 6, Row = 3 },
        };
        var l2 = Run("l2", 240, (w, t2, i) =>
        {
            w.CollectAllSuns();
            foreach (var p in plan2)
            {
                if (p.Taken) continue;
                if (p.At <= t2) { p.Taken = true; Fail f; w.Place(p.Row, p.Col, p.Type, out f); }
            }
        }, 1);
        // 4) «1-3»: пять полос открыты сразу, ведроголовые и орех-стена. Ореха в
        //    пачке уровня нет (он — награда за 1-3), но Place() с ним работает: сценарий
        //    ровно для того и нужен — чтобы «40 с поедания стены» и «снятие ведра по
        //    1300» совпадали в C# и JS до последнего снятого HP.
        var plan3 = new List<TracePlan3>
        {
            new TracePlan3 { At = 0.5, Type = "sunflower", Col = 1, Row = 1 }, new TracePlan3 { At = 3, Type = "sunflower", Col = 3, Row = 3 },
            new TracePlan3 { At = 7, Type = "peashooter", Col = 2, Row = 2 }, new TracePlan3 { At = 12, Type = "wallnut", Col = 5, Row = 1 },
            new TracePlan3 { At = 16, Type = "peashooter", Col = 1, Row = 3 }, new TracePlan3 { At = 22, Type = "wallnut", Col = 5, Row = 4 },
            new TracePlan3 { At = 30, Type = "peashooter", Col = 2, Row = 1 }, new TracePlan3 { At = 40, Type = "cherry", Col = 4, Row = 2 },
            new TracePlan3 { At = 56, Type = "wallnut", Col = 4, Row = 2 }, new TracePlan3 { At = 70, Type = "peashooter", Col = 2, Row = 4 },
            new TracePlan3 { At = 92, Type = "cherry", Col = 6, Row = 3 }, new TracePlan3 { At = 110, Type = "peashooter", Col = 3, Row = 1 },
        };
        var l3 = Run("l3", 240, (w, t3, i) =>
        {
            w.CollectAllSuns();
            foreach (var p in plan3)
            {
                if (p.Taken) continue;
                if (p.At <= t3) { p.Taken = true; Fail f; w.Place(p.Row, p.Col, p.Type, out f); }
            }
        }, 2);
        // 4) «1-4»: чемперы в деле — проглатывание, жвачка и лопата в одном трассе
        var plan4 = new List<TracePlan4>
        {
            new TracePlan4 { At = 0, Type = "sunflower", Col = 0, Row = 1 }, new TracePlan4 { At = 1, Type = "sunflower", Col = 1, Row = 3 },
            new TracePlan4 { At = 3, Type = "chomper", Col = 2, Row = 2 }, new TracePlan4 { At = 14, Type = "peashooter", Col = 5, Row = 0 },
            new TracePlan4 { At = 22, Type = "wallnut", Col = 1, Row = 1 }, new TracePlan4 { At = 30, Type = "chomper", Col = 2, Row = 3 },
            new TracePlan4 { At = 44, Type = "peashooter", Col = 6, Row = 4 }, new TracePlan4 { At = 58, Type = "chomper", Col = 2, Row = 0 },
            new TracePlan4 { At = 72, Type = "wallnut", Col = 1, Row = 4 }, new TracePlan4 { At = 88, Type = "peashooter", Col = 4, Row = 2 },
            new TracePlan4 { At = 104, Type = "chomper", Col = 2, Row = 4 }, new TracePlan4 { At = 122, Type = "peashooter", Col = 6, Row = 1 },
        };
        var l4r = Run("l4", 240, (w, t4, i) =>
        {
            w.CollectAllSuns();
            foreach (var p in plan4)
            {
                if (p.Taken) continue;
                if (p.At <= t4) { p.Taken = true; Fail f; w.Place(p.Row, p.Col, p.Type, out f); }
            }
            if (i == (int)(150.5 / DT)) w.Dig(2, 2);          // лопата тоже в трассе
        }, 3);
        return idle + farmer + l2 + l3 + l4r;
    }

    private sealed class TracePlan2 { public double At; public string Type; public int Col; public int Row; public bool Taken; }

    private sealed class TracePlan3 { public double At; public string Type; public int Col; public int Row; public bool Taken; }

    private sealed class TracePlan4 { public double At; public string Type; public int Col; public int Row; public bool Taken; }

    // ------------------------------------------------------------------- тесты
    private static int _fails = 0;
    private static void Ok(bool cond, string name, string detail = "")
    {
        Console.WriteLine((cond ? "  ok   " : "  FAIL ") + name + (detail.Length > 0 && !cond ? "  → " + detail : ""));
        if (!cond) _fails++;
    }

    private static World Solo()
    {
        var lvl = CFG.LEVELS[0];
        var copy = new LevelDef
        {
            Id = lvl.Id, Name = lvl.Name, Subtitle = lvl.Subtitle, StartSun = 9999,
            Seeds = lvl.Seeds, Rows = lvl.Rows,
            SkySun = new SkySunDef { First = double.PositiveInfinity, Interval = double.PositiveInfinity, Value = 25 },
            TotalZombies = 999,
            Waves = new List<WaveDef> { new WaveDef { Zombies = new List<ZombieSpec>(), Time = double.PositiveInfinity } },
        };
        return new World(copy, 4242u);
    }

    private static World Step(World w, double seconds, Action<World> each = null)
    {
        int n = (int)Math.Round(seconds / DT);
        for (int i = 0; i < n; i++) { if (each != null) each(w); w.Update(DT); w.DrainEvents(); }
        return w;
    }

    private static void Tests()
    {
        // 1) солнце с неба падает и лежит 9 с
        var w = new World(CFG.LEVELS[0], 7u);
        Step(w, 6);
        Ok(w.Suns.Count >= 1, "солнце с неба появилось к 6с");
        var sun = w.Suns[0];
        Step(w, 3);
        Ok(w.Suns.Count >= 1, "солнце ещё лежит");
        // падение ~5с + 9с лежит + запас на затухание
        Step(w, 22);
        bool still = false;
        foreach (var q in w.Suns) if (q.Id == sun.Id) still = true;
        Ok(!still, "необранное солнце гаснет");

        // 2) подсолнух печатает 50 (наше отступление)
        var w2 = Step(Solo(), 0);
        Fail f2;
        var sf = w2.Place(2, 3, "sunflower", out f2);
        Ok(sf != null && f2 == Fail.None, "подсолнух сажается");
        Ok(sf.Def.Produce.Value == 50, "подсолнух даёт 50 солнца", sf.Def.Produce.Value.ToString());
        Step(w2, 9);
        Ok(w2.Suns.Count >= 1, "первое солнце через 8с");
        int bank0 = w2.SunCount;
        w2.CollectAllSuns();
        Step(w2, 1.2);
        Ok(w2.SunCount == bank0 + 50, "солнце долетело до банка: +" + (w2.SunCount - bank0), "+" + (w2.SunCount - bank0));

        // 3) 10 горошин убивают зомби (200 hp / 20 урона)
        var w3 = Solo();
        Fail f3p;
        w3.Place(2, 0, "peashooter", out f3p);
        var z = w3.SpawnZombie("basic", 2);
        z.X = Geo.LAWN_RIGHT - 40;                 // далеко: до растения не дойдёт
        int peaHits = 0;
        for (int i = 0; i < (int)(24 / DT); i++)
        {
            w3.Update(DT);
            foreach (var e in w3.DrainEvents()) if (e.Kind == EvKind.PeaHit) peaHits++;
        }
        Ok(z.State == "die", "горохострел убил зомби", "hp=" + z.Hp);
        Ok(peaHits == 10, "ровно 10 попаданий", "hits=" + peaHits);
        Ok(w3.Plants.Count == 1, "растение целое");

        // 4) стадии расчленёнки по порогам hp
        var w4 = Solo();
        var z4 = w4.SpawnZombie("basic", 2);
        Ok(z4.Stage == 0, "целый зомби = стадия 0");
        w4.HurtZombie(z4, 200 * 0.34 + 1);
        Ok(z4.Stage == 1, "70% hp → без руки (стадия 1)", "stage=" + z4.Stage);
        w4.HurtZombie(z4, 200 * 0.33);
        Ok(z4.Stage == 2, "37% hp → ещё и без ноги", "stage=" + z4.Stage);
        w4.HurtZombie(z4, 200 * 0.25);
        Ok(z4.Stage == 3, "12% hp → без головы", "stage=" + z4.Stage);

        // 5) поедание: 300 hp растения за ~3 секунды
        var w5 = Solo();
        Fail f5;
        var p5 = w5.Place(2, 4, "sunflower", out f5);
        p5.Hp = 300;
        var z5 = w5.SpawnZombie("basic", 2);
        z5.X = p5.X + 30;
        Step(w5, 2.6);
        Ok(w5.Plants.Count == 1, "за 2.6с ещё живёт");
        Step(w5, 0.8);
        Ok(w5.Plants.Count == 0, "за ~3с съедено", "plants=" + w5.Plants.Count);

        // 6) скорость зомби: 5 секунд на клетку
        var w6 = Solo();
        var z6 = w6.SpawnZombie("basic", 2);
        z6.X = Geo.CellX(5);
        double start = z6.X;
        Step(w6, 5);
        Ok(Math.Abs((start - z6.X) - Geo.TILE) < 2, "прошёл клетку за 5с", (start - z6.X).ToString("F1", CultureInfo.InvariantCulture));

        // 7) волны идут по часам, даже если ничего не сажать. Времен внутри теста
        //    нет — берутся из конфига, иначе любая правка темпа ломала бы проверку.
        var w7 = new World(CFG.LEVELS[0], 11u);
        Action<World> kill = (ww) => { foreach (var zz in new List<Zombie>(ww.Zombies)) if (zz.State != "die") ww.HurtZombie(zz, 9999); };
        double tFirst = CFG.LEVELS[0].Waves[0].Time;
        Step(w7, tFirst - 1, kill);
        Ok(w7.WaveIndex == 0, "до первой волны зомби нет", "t=" + w7.Time.ToString("F1", CultureInfo.InvariantCulture));
        for (int k = 0; k < CFG.LEVELS[0].Waves.Count; k++)
        {
            double need = CFG.LEVELS[0].Waves[k].Time + 0.5 - w7.Time;
            if (need > 0) Step(w7, need, kill);
            Ok(w7.WaveIndex > k, "волна " + (k + 1) + " стартовала по часам, без условий", "wi=" + w7.WaveIndex);
        }
        Step(w7, 6, kill);            // пауза между зомби в финальной волне
        Ok(w7.SpawnedZombies == CFG.LEVELS[0].TotalZombies, "всего зомби со спавна: " + w7.SpawnedZombies,
           w7.SpawnedZombies.ToString());
        Ok(tFirst >= 24, "на развитие дано время: первая волна 1-1 не раньше 24 с", "t=" + tFirst);

        // 8) косилка: заводится, скашивает, тратится навсегда
        var w8 = Solo();
        Ok(w8.Mowers.Count == 1, "одна открытая полоса — одна косилка");
        var m8 = w8.Mowers[0];
        var z8 = w8.SpawnZombie("basic", 2);
        z8.X = Geo.LAWN_X + 70;
        Step(w8, 6);
        Ok(m8.State == "run", "косилка завелась", m8.State);
        Ok(w8.Zombies.Count == 0, "зомби в полосе скашен (труп досчитался)", "zombies=" + w8.Zombies.Count);
        Ok(w8.KilledZombies == 1, "убитых: " + w8.KilledZombies);
        Ok(w8.State == WorldState.Playing, "косилка спасла полосу");
        Step(w8, 3);
        Ok(w8.Mowers.Count == 0, "косилка уехала и пропала");
        var z8b = w8.SpawnZombie("basic", 2);
        z8b.X = Geo.LAWN_X + 70;
        Step(w8, 8);
        Ok(w8.State == WorldState.Lost, "без косилки та же полоса — поражение", w8.State.ToString());

        // 9) разблокировка полосы выдаёт ей свою косилку
        var lvl9 = new LevelDef
        {
            Id = "1-2", StartSun = 9999, Seeds = CFG.LEVELS[0].Seeds, Rows = new List<int> { 2 },
            SkySun = new SkySunDef { First = double.PositiveInfinity, Interval = double.PositiveInfinity, Value = 25 },
            TotalZombies = 1,
            Waves = new List<WaveDef> { new WaveDef { Zombies = new List<ZombieSpec> { new ZombieSpec("basic", 1) }, Time = 0, UnlockRows = new int[] { 1 } } },
        };
        var w9 = Step(new World(lvl9, 5u), 1);
        Ok(w9.UnlockedRows.Contains(1) && w9.UnlockedRows.Count == 2, "полоса 1 открыта");
        int m9 = 0;
        foreach (var m in w9.Mowers) if (m.Row == 1) m9++;
        Ok(m9 == 1, "новой полосе — новая косилка", "mowers=" + w9.Mowers.Count);

        // 10) поражение/победа
        var w10 = Solo();
        w10.Mowers.Clear();
        var z10 = w10.SpawnZombie("basic", 2);
        z10.X = Geo.LAWN_X + 60;
        Step(w10, 8);
        Ok(w10.State == WorldState.Lost, "зомби дошёл до дома → поражение");

        // «проходится» по теперешним правилам: на 1-1 одна карточка (горохострел),
        // после посадки она уходит на 7.5 с перезарядки, солнце — только стартовое и с неба.
        var w11 = new World(CFG.LEVELS[0], 3u);
        int col11 = 2, planted11 = 0;
        for (int i = 0; i < (int)(200 / DT) && w11.State == WorldState.Playing; i++)
        {
            w11.CollectAllSuns();
            if (col11 <= 8)
            {
                Fail ff;
                if (w11.Place(2, col11, "peashooter", out ff) != null) { planted11++; col11++; }
            }
            w11.Update(DT);
            w11.DrainEvents();
        }
        Ok(w11.State == WorldState.Won, "уровень проходится: " + w11.State + ", зомби " + w11.Zombies.Count +
           ", волна " + w11.WaveIndex + ", посажено " + planted11);
        Ok(planted11 >= 1 && planted11 <= 6, "перезарядка ограничила число посадок: " + planted11,
           "n=" + planted11);

        // 11b) перезарядка карточки
        var wc = new World(CFG.LEVELS[1], 11u, new List<string> { "peashooter", "sunflower", "cherry" });
        wc.SunCount = 9999;
        Fail fcz;
        Ok(wc.Place(2, 1, "peashooter", out fcz) != null, "первый горох сел");
        Ok(wc.CooldownLeft("peashooter") == 7.5, "карточка ушла на 7.5 с", "cd=" + wc.CooldownLeft("peashooter"));
        Ok(wc.CanPlant(2, 2, "peashooter") == Fail.Cool, "тот же тип — Fail.Cool");
        Ok(wc.CanPlant(2, 2, "sunflower") == Fail.None, "другая карточка не ждёт");
        Ok(wc.Place(2, 2, "sunflower", out fcz) != null, "подсолнух сел сразу");
        Ok(wc.CooldownLeft("sunflower") == 7.5, "у подсолнуха своя перезарядка");
        Step(wc, 7.4);
        Ok(wc.CanPlant(2, 3, "peashooter") == Fail.Cool, "на 7.4 с ещё отдыхает");
        Step(wc, 0.2);
        Ok(wc.CanPlant(2, 3, "peashooter") == Fail.None, "на 7.6 с готова");
        Ok(wc.CooldownLeft("peashooter") == 0, "остаток обнуляется, не уходит в минус");
        Ok(wc.Place(2, 3, "cherry", out fcz) != null, "вишня села");
        Ok(wc.CooldownLeft("cherry") == 30, "вишня: 30 с, как в оригинале", "cd=" + wc.CooldownLeft("cherry"));
        wc.RechargeAll();
        Ok(wc.CooldownLeft("cherry") == 0 && wc.CanPlant(2, 4, "cherry") == Fail.None, "RechargeAll (клавиша C) заряжает всё");
        Ok(wc.Plants.Count == 3, "после перезарядки на газоне всё ещё 3 растения");

        // 11) причины отказа
        var w12 = Solo();
        Ok(w12.CanPlant(0, 4, "sunflower") == Fail.Locked, "закрытая полоса → Locked");
        Ok(w12.CanPlant(2, 0, "sunflower") == Fail.None, "открытая полоса → можно");
        Ok(w12.CanPlant(9, 0, "sunflower") == Fail.Out, "вне поля → Out");
        var w13 = new World(CFG.LEVELS[0], 9u);
        w13.SunCount = 0;
        Ok(w13.CanPlant(2, 0, "sunflower") == Fail.NoSun, "нет солнца → NoSun");

        // 12) вишня: секунду тлеет — и в квадрате 3×3 чисто
        var w14 = new World(CFG.LEVELS[1], 5u);
        w14.SunCount = 9999;
        Fail f12;
        var ch = w14.Place(2, 4, "cherry", out f12);
        Ok(ch != null, "вишня садится", "fail=" + f12);
        ch = w14.Plants[0];
        Ok(ch.Def.Explode != null && ch.FuseMax == 1.1, "фитиль 1.1с", "fuse=" + ch.FuseMax);
        var inzone = new List<Zombie>();
        for (int r = 1; r <= 3; r++)
        {
            var zt = w14.SpawnZombie("conehead", r);
            zt.X = Geo.LAWN_X + (4 + 0.5) * Geo.TILE;           // ставим ровно в квадрат 3×3 вокруг вишни
            inzone.Add(zt);
        }
        var far = w14.SpawnZombie("basic", 1);
        far.X = Geo.LAWN_X + 8.6 * Geo.TILE;                    // далеко справа — не должен получить
        Step(w14, 0.9);
        Ok(w14.Plants.Count == 1, "на 0.9с вишня ещё тлеет");
        Ok(inzone[0].Hp == 200, "пока тихо: никто не пострадал");
        for (int i = 0; i < 40; i++) w14.Update(DT);
        bool boom = false; int boomHit = -1;
        foreach (var e in w14.DrainEvents()) if (e.Kind == EvKind.Explode) { boom = true; boomHit = e.Count; }
        Ok(boom, "событие Explode создано");
        Ok(w14.Plants.Count == 0, "вишня исчезла (одноразовая)");
        Ok(boomHit == 3, "в зоне 3 зомби", "hit=" + boomHit);
        bool allDead = true;
        foreach (var zi in inzone) if (zi.Alive && zi.Hp > 0) allDead = false;
        Ok(allDead, "конусы сняты одним взрывом (1800 > 640)");
        Ok(far.Hp == 200, "вне квадрата не задело");

        // 13) конус: урон сначала по броне, тело чистое, пока броня держит
        var w15 = new World(CFG.LEVELS[1], 6u);
        var cz = w15.SpawnZombie("conehead", 2);
        var bz = w15.SpawnZombie("basic", 2);
        Ok(cz.MaxHp == 200 && cz.ArmorMax == 440, "200 тело + 440 конус = 640");
        w15.HurtZombie(cz, 100);
        w15.HurtZombie(bz, 100);
        Ok(cz.ArmorHp == 340 && cz.Hp == 200, "100 ушло в конус, тело не тронуто", "a=" + cz.ArmorHp);
        Ok(cz.Stage == 0 && bz.Stage == 1, "пока конус на голове — вид целый (540/640)", "cz=" + cz.Stage + " bz=" + bz.Stage);
        w15.HurtZombie(cz, 330);
        Ok(cz.ArmorHp == 10 && cz.Hp == 200, "конус на последних 10 ед.", "a=" + cz.ArmorHp + " hp=" + cz.Hp);
        w15.HurtZombie(cz, 20);
        Ok(cz.ArmorHp == 0 && cz.Hp == 190, "излишек 10 ушёл в тело", "hp=" + cz.Hp);
        Ok(cz.Stage == 2, "без конуса вид сразу побитый", "st=" + cz.Stage);
        Ok(cz.Alive, "но живой: 190 hp");
        int armorEvents = 0;
        foreach (var e in w15.DrainEvents()) if (e.Kind == EvKind.ArmorLost) armorEvents++;
        Ok(armorEvents == 1, "ArmorLost ровно один раз", "n=" + armorEvents);
        w15.HurtZombie(cz, 500);
        Ok(!cz.Alive || cz.Hp <= 0, "без конуса добивается как обычный");

        // 14) рандомайзер: один сид — один расклад, другой сид — другой
        var waves2 = CFG.LEVELS[1].Waves;
        double span2 = waves2[waves2.Count - 1].Time + 24;
        string Sig(int seed)
        {
            var ww = new World(CFG.LEVELS[1], (uint)seed);
            Step(ww, span2);
            var sb = new StringBuilder();
            foreach (var zz in ww.Zombies) sb.Append(zz.Type).Append(':').Append(zz.Row).Append(',');
            sb.Append('|').Append(ww.SpawnedZombies);
            return sb.ToString();
        }
        string sA = Sig(1337); string sB = Sig(1337); string sC = Sig(2024);
        Ok(sA == sB, "один сид → тот же состав и полосы");
        Ok(sA != sC, "другой сид → другой расклад");
        var seenTypes = new HashSet<string>();
        var wd = new World(CFG.LEVELS[1], 1337u);
        Step(wd, span2, (w) => { foreach (var zx in w.Zombies) seenTypes.Add(zx.Type); });
        Ok(seenTypes.Contains("conehead") && seenTypes.Contains("basic"),
           "в толпе успели пройти и обычные, и в конусах", "types=" + string.Join(",", new List<string>(seenTypes).ToArray()));

        // 15) пачка семян = seeds уровня ∩ открытое
        var w16 = new World(CFG.LEVELS[1], 1u);
        Ok(w16.Seeds.Count == 3, "1-2: три карточки", "n=" + w16.Seeds.Count);
        var only = new World(CFG.LEVELS[1], 1u, new List<string> { "peashooter" });
        Ok(only.Seeds.Count == 1 && only.Seeds[0] == "peashooter", "с одним открытым — одна карточка");
        Ok(only.Allows("peashooter") && !only.Allows("cherry"), "Allows() фильтрует");
        var none = new World(CFG.LEVELS[1], 1u, new List<string> { "netovigrine" });
        Ok(none.Seeds.Count == 3, "пустое пересечение → играем всем уровнем");
        var l11 = new World(CFG.LEVELS[0], 1u, new List<string> { "peashooter", "sunflower", "cherry" });
        Ok(l11.Seeds.Count == 1, "1-1 не выдаёт лишнего", "n=" + l11.Seeds.Count);

        // 16) полосы: случайный ряд только из открытых; повторный unlock — no-op
        var w17 = new World(CFG.LEVELS[0], 3u);
        bool same = true;
        for (int i = 0; i < 60; i++) if (w17.PickRow() != 2) same = false;
        Ok(same, "1-1: PickRow всегда 2 (одна полоса)");
        Ok(w17.UnlockRow(0), "UnlockRow(0) открыл полосу");
        Ok(!w17.UnlockRow(0), "повторный UnlockRow → false");
        Ok(w17.UnlockedRows.Count == 2, "полос стало две", "n=" + w17.UnlockedRows.Count);
        bool onlyOpen = true;
        for (int i = 0; i < 200; i++) { int rr = w17.PickRow(); if (rr != 0 && rr != 2) onlyOpen = false; }
        Ok(onlyOpen, "PickRow ходит только по открытым");

        // 18) орех: чистая стена — не стреляет, не производит, держит полосу
        var wnut = CFG.Plant("wallnut");
        Ok(wnut != null, "орех есть в конфиге");
        if (wnut != null)
        {
            Ok(wnut.Hp == 4000 && wnut.Cost == 50 && wnut.Cooldown == 30,
               "орех: 4000 HP, 50 ☀, карточка на 30 с", "hp=" + wnut.Hp + " cost=" + wnut.Cost + " cd=" + wnut.Cooldown);
            Ok(wnut.Fire == null && wnut.Produce == null && wnut.Explode == null,
               "орех ничего не делает — ни стрельбы, ни солнца, ни взрыва");
        }
        var w19 = Solo();
        Fail f19;
        var nut = w19.Place(2, 5, "wallnut", out f19);
        Ok(nut != null, "орех садится", "fail=" + f19);
        if (nut != null)
        {
            var zb = w19.SpawnZombie("buckethead", 2);
            zb.X = Geo.LAWN_X + 7 * Geo.TILE + 8;
            Step(w19, 12);
            Ok(zb.State == "eat", "зомби встал к ореху и грызёт его", "state=" + zb.State);
            Ok(nut.Hp > 3000 && nut.Hp < 4000, "за ~7 с еды у ореха снято ~700 HP", "hp=" + nut.Hp.ToString("F0", CultureInfo.InvariantCulture));
            double xHold = zb.X;
            Step(w19, 6);
            Ok(Math.Abs(zb.X - xHold) < 0.001, "пока орех жив, зомби не идёт вперёд", "dx=" + (zb.X - xHold).ToString("F3", CultureInfo.InvariantCulture));
            Step(w19, 36);                       // 4000/100 = 40 с чистого поедания
            Ok(w19.Plants.Count == 0 && zb.X < xHold - 10, "орех съеден за ~40 с, зомби пошёл дальше",
               "plants=" + w19.Plants.Count + " dx=" + (zb.X - xHold).ToString("F0", CultureInfo.InvariantCulture));
        }

        // 19) ведроголовый: 1300 брони сверху, тело 200; ведро портится раньше тела
        var w20 = Solo();
        var bk = w20.SpawnZombie("buckethead", 2);
        Ok(bk.ArmorHp == 1300 && bk.Hp == 200, "ведро: 1300 брони + 200 тело = 1500",
           "a=" + bk.ArmorHp + " hp=" + bk.Hp);
        w20.HurtZombie(bk, 700);
        Ok(bk.Hp == 200 && Math.Abs(bk.ArmorHp - 600) < 0.001, "урон ушёл в ведро, тело цело",
           "a=" + bk.ArmorHp.ToString("F0", CultureInfo.InvariantCulture) + " hp=" + bk.Hp);
        Ok(bk.ArmorRatio < 0.55 && bk.Hp == 200, "ведро помято (dmg-спрайт при <55%), тело не тронуто",
           "ratio=" + bk.ArmorRatio.ToString("F2", CultureInfo.InvariantCulture) + " stage=" + bk.Stage);
        w20.HurtZombie(bk, 600);
        Ok(bk.ArmorHp == 0 && bk.Hp == 200, "ведро сбито целиком", "a=" + bk.ArmorHp);
        bool armorLostEv = false;
        foreach (var ev in w20.DrainEvents()) if (ev.Kind == EvKind.ArmorLost) armorLostEv = true;
        Ok(armorLostEv, "событие ArmorLost прилетело (вьюха срисует обломок)");
        w20.HurtZombie(bk, 200);
        Ok(!bk.Alive || bk.Hp <= 0, "без ведра добивается как обычный", "hp=" + bk.Hp);

        // 20) 1-3: пять полос сразу, ведроголовые в ростере, орех — наградой
        var l3 = CFG.LEVELS[2];
        Ok(CFG.LEVELS.Count == 4, "уровней четыре: 1-1..1-4", "n=" + CFG.LEVELS.Count);
        var w21 = new World(l3, 7u);
        Ok(w21.UnlockedRows.Count == 5, "на 1-3 все пять полос открыты с первой секунды", "n=" + w21.UnlockedRows.Count);
        Ok(w21.Mowers.Count == 5, "по косилке на каждую полосу", "n=" + w21.Mowers.Count);
        bool hasBucket = false;
        foreach (var r in l3.Roster) if (r.Type == "buckethead" && r.Weight > 0) hasBucket = true;
        Ok(hasBucket, "на 1-3 впервые идут ведроголовые");
        Ok(l3.Rewards.Count == 1 && l3.Rewards[0] == "wallnut", "орех — награда за 1-3",
           "rewards=" + string.Join(",", l3.Rewards.ToArray()));
        Ok(l3.Seeds.Contains("wallnut"), "1-3 перечисляет орех в пачке (иначе после победы его негде взять)",
           string.Join(",", l3.Seeds.ToArray()));
        var nutBefore = new World(l3, 1u, new List<string> { "peashooter", "sunflower", "cherry" });
        Ok(nutBefore.Seeds.Count == 3 && nutBefore.Seeds.IndexOf("wallnut") < 0,
           "первым прохождением ореха в руке нет — он ещё не заработан", string.Join(",", nutBefore.Seeds.ToArray()));
        var nutAfter = new World(l3, 1u, new List<string> { "peashooter", "sunflower", "cherry", "wallnut" });
        Ok(nutAfter.Seeds.Count == 4, "после победы на 1-3 орех встаёт четвёртой картой",
           string.Join(",", nutAfter.Seeds.ToArray()));
        Ok(l3.Waves[0].Time >= 44, "на 1-3 есть время начать: первая волна не раньше 44 с", "t=" + l3.Waves[0].Time);
        // 1-3 — самый большой газон, поэтому и подготовка у него самая длинная.
        // Проверяем это порядком, а не только абсолютным числом: иначе «уравнять
        // уровни» снова превратится в «вернуть 1-3 к 1-1».
        double prep1 = CFG.LEVELS[0].Waves[0].Time, prep2 = CFG.LEVELS[1].Waves[0].Time, prep3 = l3.Waves[0].Time;
        Ok(prep3 > prep2 && prep2 > prep1, "подготовка растёт по мере роста газона: 1-1 < 1-2 < 1-3",
           string.Format("{0:0} < {1:0} < {2:0}", prep1, prep2, prep3));
        var sunP = CFG.Plant("sunflower");
        Ok(prep3 >= sunP.Produce.First + sunP.Produce.Interval,
           "за подготовку подсолнух успевает отработать полный цикл (посеял → два сбора)",
           string.Format("t={0:0} против {1:0}+{2:0}", prep3, sunP.Produce.First, sunP.Produce.Interval));
        double minGap3 = double.MaxValue;
        for (int i = 1; i < l3.Waves.Count; i++) minGap3 = Math.Min(minGap3, l3.Waves[i].Time - l3.Waves[i - 1].Time);
        Ok(minGap3 >= 26, "сдвиг не сжал волны: зазор на 1-3 не меньше 26 с", "min gap=" + minGap3.ToString("0.0"));
        // сумма волн = TotalZombies у всех уровней: ловит «добавил волну, забыл счётчик»
        int badSum = 0;
        for (int i = 0; i < CFG.LEVELS.Count; i++)
        {
            int sum = 0;
            foreach (var wv in CFG.LEVELS[i].Waves) sum += wv.Zombies.Count;
            if (sum != CFG.LEVELS[i].TotalZombies) badSum |= 1 << i;
        }
        Ok(badSum == 0, "во всех уровнях сумма волн = TotalZombies", "маска " + badSum);
        Ok(CFG.PLANTS.Count == 5 && CFG.ZOMBIES.Count == 3, "5 растений и 3 зомби в базе",
           "p=" + CFG.PLANTS.Count + " z=" + CFG.ZOMBIES.Count);
        Ok(CFG.LEVELS[0].TotalZombies == 9, "зомби на 1-1 стало больше: 9 вместо 5",
           "n=" + CFG.LEVELS[0].TotalZombies);

        // 21) чемпер + лопата + 1-4 (всё зеркально pvz-pixel/js: sim_test.mjs, тот же тест)
        var chomp = CFG.Plant("chomper");
        Ok(chomp != null, "чемпер есть в базе растений");
        if (chomp != null)
        {
            Ok(chomp.Cost == 150 && chomp.Hp == 300, "чемпер: 150 солнца и 300 HP — как в оригинале",
               "c=" + chomp.Cost + " hp=" + chomp.Hp);
            Ok(chomp.Chomp != null && chomp.Chomp.Damage == 1800 && chomp.Chomp.Tiles == 2
               && Math.Abs(chomp.Chomp.Chew - 20.0) < 0.001,
               "проглатывание: 1800 урона, 20 с жвачки, две клетки вперёд",
               chomp.Chomp == null ? "нет Chomp" : ("d=" + chomp.Chomp.Damage + " t=" + chomp.Chomp.Tiles));
            Ok(chomp.Cooldown == 7.5 && chomp.Fire == null && chomp.Produce == null && chomp.Explode == null,
               "перезарядка карты быстрая (7.5 с), других режимов у хищника нет", "cd=" + chomp.Cooldown);
        }
        var w22 = Solo();
        Fail f22;
        var mouth = w22.Place(2, 3, "chomper", out f22);
        Ok(mouth != null, "чемпер садится", "fail=" + f22);
        if (mouth != null)
        {
            var zb = w22.SpawnZombie("buckethead", 2);
            zb.X = mouth.X + Geo.TILE;
            Step(w22, 0.25);
            Ok(zb.State == "die" && zb.ArmorHp == 0, "ведро и тело проглочены одним укусом",
               "state=" + zb.State + " a=" + zb.ArmorHp + " hp=" + zb.Hp);
            Ok(mouth.ChewTimer > 19, "и залёг на жвачку", "chew=" + mouth.ChewTimer.ToString("F1", CultureInfo.InvariantCulture));
            double chew0 = mouth.ChewTimer;
            Step(w22, 1.0);
            Ok(mouth.ChewTimer < chew0 - 0.5 && mouth.ChewTimer > 0, "жвачка тикает",
               chew0.ToString("F1", CultureInfo.InvariantCulture) + "→" + mouth.ChewTimer.ToString("F1", CultureInfo.InvariantCulture));
            var z2 = w22.SpawnZombie("basic", 2);
            z2.X = mouth.X + Geo.TILE;
            Step(w22, 0.5);
            Ok(z2.State != "die", "пока жуёт — второй зомби цел");
            Ok(mouth.Hp < mouth.MaxHp, "и сам под ударом: хищник беззащитен",
               "hp=" + mouth.Hp.ToString("F0", CultureInfo.InvariantCulture));
            mouth.ChewTimer = 0;                    // «доев» (20 с сверены выше и в конфиге)
            Step(w22, 0.25);
            Ok(z2.State == "die", "готов — и сразу хватает того, кто его сам жевал");
            var z3 = w22.SpawnZombie("basic", 2);
            z3.X = mouth.X + 3.5 * Geo.TILE;         // дальше двух клеток
            mouth.ChewTimer = 0;
            Step(w22, 0.25);
            Ok(z3.State != "die", "за две клетки вперёд не дотягивается",
               "dx=" + (z3.X - mouth.X).ToString("F0", CultureInfo.InvariantCulture));
            // лопата: убирает растение, солнце не возвращает, пустая клетка — null
            int sun0 = w22.SunCount;
            var dug = w22.Dig(mouth.Row, mouth.Col);
            Ok(dug == mouth, "лопата сняла растение");
            Ok(w22.SunCount == sun0, "лопата не возвращает солнце — как в оригинале", "sun=" + w22.SunCount);
            Ok(w22.Plants.Count == 0, "на газоне пусто", "n=" + w22.Plants.Count);
            Ok(w22.Dig(0, 0) == null, "копать пустую клетку нечем");
            bool dugEv = false;
            foreach (var ev in w22.DrainEvents()) if (ev.Kind == EvKind.Dig) dugEv = true;
            Ok(dugEv, "событие Dig прилетело (вьюха сыпанет землёй)");
        }
        var l4 = CFG.LEVELS[3];
        Ok(l4.Id == "1-4" && l4.Rewards.Count == 1 && l4.Rewards[0] == "chomper", "1-4 отдаёт ровно чемпер",
           l4.Id + "/" + string.Join(",", l4.Rewards.ToArray()));
        Ok(l4.Seeds.Contains("chomper"), "1-4 перечисляет чемпер в пачке (иначе после победы его негде взять)",
           string.Join(",", l4.Seeds.ToArray()));
        var w23 = new World(l4, 3u, new List<string> { "peashooter", "sunflower", "cherry", "wallnut" });
        Ok(w23.Seeds.Count == 4 && w23.Seeds.IndexOf("chomper") < 0, "первым прохождением чемпера в руке нет",
           string.Join(",", w23.Seeds.ToArray()));
        Ok(l4.Roster.Count == 3 && l4.WinTip == "ЧЕМПЕР ОТКРЫТ", "на 1-4 три типа зомби, подсказка = награда");
        // волны лесенкой на ВСЕХ уровнях: первый вал — 1 зомби, размер не убывает, зазоры не сжаты
        int rampBad = 0;
        for (int i = 0; i < CFG.LEVELS.Count; i++)
        {
            var wv = CFG.LEVELS[i].Waves;
            if (wv[0].Zombies.Count != 1) rampBad |= 1 << i;
            for (int k = 1; k < wv.Count; k++)
            {
                if (wv[k].Zombies.Count < wv[k - 1].Zombies.Count) rampBad |= 1 << i;
                if (wv[k].Time - wv[k - 1].Time < 26) rampBad |= 1 << i;
            }
        }
        Ok(rampBad == 0, "лесенка на всех уровнях: первый вал 1 зомби, размер не убывает, зазоры >= 26 с",
           "маска " + rampBad);
        Ok(CFG.LEVELS[0].Tools.Count == 1 && CFG.LEVELS[0].Tools[0] == "shovel", "лопата — награда за 1-1",
           string.Join(",", CFG.LEVELS[0].Tools.ToArray()));
        Ok(CFG.LEVELS[2].TotalZombies == 28 && l4.TotalZombies == 32, "зомби больше: 1-3 = 28, 1-4 = 32",
           CFG.LEVELS[2].TotalZombies + "/" + l4.TotalZombies);

        // 22) орех бьётся: стадии скорлупы, укусы и событие скола (зеркало sim_test.mjs)
        {
            var wnA = Solo();
            Pvz.Core.Fail fnutA;
            var nutA = wnA.Place(2, 5, "wallnut", out fnutA);
            Ok(nutA != null, "орех садится в тестовое поле", "fail=" + fnutA);
            var cfgA = CFG.Plant("wallnut");
            Ok(cfgA != null && cfgA.Dmg.Count == 3 && cfgA.Bites.Count == 5,
               "в конфиге три кадра раскола и пять мест под укусы",
               cfgA == null ? "нет конфига" : cfgA.Dmg.Count + "/" + cfgA.Bites.Count);
            nutA.MaxHp = 4000;
            nutA.Hp = 4000; int st0 = nutA.Stage;
            nutA.Hp = 2881; int st1 = nutA.Stage;
            nutA.Hp = 2880; int st2 = nutA.Stage;
            nutA.Hp = 2000; int st3 = nutA.Stage;
            nutA.Hp = 1000; int st4 = nutA.Stage;
            Ok(st0 == 0 && st1 == 0 && st2 == 1 && st3 == 2 && st4 == 3,
               "стадии по HP: 4000/2881 — целая, 2880 трещины, 2000 нет макушки, 1000 половина",
               st0 + "/" + st1 + "/" + st2 + "/" + st3 + "/" + st4);
            nutA.Hp = 4000; int bt0 = nutA.Bites;
            nutA.Hp = 2880; int bt1 = nutA.Bites;
            nutA.Hp = 2000; int bt2 = nutA.Bites;
            nutA.Hp = 1000; int bt3 = nutA.Bites;
            Ok(bt0 == 0 && bt1 == 1 && bt2 == 2 && bt3 == 3, "укусы растут вместе со стадиями: 0/1/2/3",
               bt0 + "/" + bt1 + "/" + bt2 + "/" + bt3);
            int prevA = -1, monoA = 1;
            for (int hpq = 4000; hpq >= 0; hpq -= 137)
            {
                nutA.Hp = hpq;
                int bq = nutA.Bites;
                if (bq < prevA) monoA = 0;
                prevA = bq;
            }
            nutA.Hp = 0;
            Ok(monoA == 1 && nutA.Bites == 5, "укусы монотонны и доходят до пяти на нулях", "n=" + nutA.Bites);

            var weA = Solo();
            Pvz.Core.Fail f2A;
            var n2A = weA.Place(2, 5, "wallnut", out f2A);
            var z2A = weA.SpawnZombie("basic", 2);
            z2A.X = n2A.EatEdge + z2A.Def.Mouth + 2;
            int cracksA = 0, jumpsA = 0, lastA = 0;
            bool orderA = true;
            for (int iq = 0; iq < (int)Math.Round(34.0 / DT); iq++)
            {
                weA.Update(DT);
                foreach (var ev in weA.DrainEvents())
                {
                    if (ev.Kind != EvKind.PlantCrack) continue;
                    cracksA++;
                    if (ev.Stage <= lastA) orderA = false;
                    lastA = ev.Stage;
                }
                if (n2A.LimbT > 0) jumpsA++;
            }
            Ok(cracksA == 3 && orderA && lastA == 3, "34 с еды: сколы идут по порядку 1-2-3",
               "cracksA=" + cracksA + " lastA=" + lastA + " orderA=" + orderA);
            Ok(jumpsA > 0, "в момент скола орех дёргается (LimbT)", "jumpsA=" + jumpsA);
        }

        // 23) чемпер ловит клетку c+2 (две клетки ВПЕРЕД, от переднего края)
        {
            var wr = Solo();
            Pvz.Core.Fail fr;
            var pc = wr.Place(2, 3, "chomper", out fr);
            Ok(pc != null, "чемпер садится для проверки дальности", "fail=" + fr);
            double reach = pc.X + Pvz.Core.Geo.TILE + pc.Def.Chomp.Tiles * Pvz.Core.Geo.TILE;
            var outz = wr.SpawnZombie("basic", 2);
            outz.X = Pvz.Core.Geo.CellX(6) + Pvz.Core.Geo.TILE / 2;    // центр клетки c+3
            Ok(outz.X > reach, "c+3 — действительно за пределами", "x=" + outz.X + " reach=" + reach);
            Step(wr, 0.25);
            Ok(outz.State != "die", "до клетки c+3 чемпер не дотягивается", "state=" + outz.State);
            outz.X = Pvz.Core.Geo.CellX(5) + Pvz.Core.Geo.TILE / 2;    // тот же — центр c+2
            Step(wr, 0.25);
            Ok(outz.State == "die", "а c+2 хватает целиком (две клетки вперёд)", "state=" + outz.State);
            Ok(pc.ChewTimer > 0, "и залегает на жвачку после этого", "chew=" + pc.ChewTimer.ToString("F1"));
        }

        Console.WriteLine();
        if (_fails == 0) Console.WriteLine("ВСЕ ТЕСТЫ ЯДРА ПРОШЛИ (port of sim_test)");
        else Console.WriteLine("ПРОВАЛОВ: " + _fails);
    }

    private static int Main(string[] args)
    {
        string mode = args.Length > 0 ? args[0] : "test";
        if (mode == "ch")
        {
            string txt = args.Length > 1 ? args[1] : "";
            var bad = new System.Collections.Generic.List<string>();
            foreach (char c in txt.ToUpperInvariant())
            {
                int[] bits;
                if (!Pvz.View.Glyphs.TryGet(c, out bits)) bad.Add("'" + c + "'");
            }
            Console.WriteLine((bad.Count == 0 ? "есть все глифы" : "нет глифа: " + string.Join(" ", bad)) + "   [" + txt + "]");
            return 0;
        }
        if (mode == "fontcheck")
        {
            var missing = new System.Collections.Generic.List<string>();
            void Check(char c)
            {
                int[] bits;
                if (!Pvz.View.Glyphs.TryGet(c, out bits)) missing.Add("'" + c + "'");
            }
            for (char c = 'А'; c <= 'Я'; c++) Check(c);
            Check('Ё'); Check(' ');
            for (char c = 'a'; c <= 'z'; c++) Check(c);
            for (char c = '0'; c <= '9'; c++) Check(c);
            foreach (char c in ".,:;!?-\u00b7\u00bb\u00ab()/%+*=<>@&_") Check(c);
            for (char c = 'А'; c <= 'Я'; c++) Check((char)(c + 32));
            Check('ё');
            Console.WriteLine("нет глифа для: " + (missing.Count == 0 ? "нет таких — покрыто всё" : string.Join(" ", missing)));
            var rows = new System.Text.StringBuilder();
            foreach (char c in "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЫЭЮЯ")
                rows.Append(c);
            Console.WriteLine(rows);
            return 0;
        }
        if (mode == "font")
        {
            Console.WriteLine(Pvz.View.Glyphs.Preview("ЗОМБИ 2/5"));
            Console.WriteLine(Pvz.View.Glyphs.Preview("ВОЛНА 4/4 · КОСИЛКА"));
            Console.WriteLine(Pvz.View.Glyphs.Preview("ПРИКЛЮЧЕНИЕ 0123456789"));
            Console.WriteLine(Pvz.View.Glyphs.Preview("ABCDEF012345 ?!»«+=%"));
            return 0;
        }
        if (mode == "trace") { Console.Write(Trace()); return 0; }
        if (mode == "parity")
        {
            var path = args.Length > 1 ? args[1] : "/tmp/js_trace.txt";
            var js = System.IO.File.ReadAllText(path).Replace("\r\n", "\n");
            var cs = Trace();
            var a = js.Split('\n'); var b = cs.Split('\n');
            int diff = 0, shown = 0;
            for (int i = 0; i < Math.Max(a.Length, b.Length); i++)
            {
                string la = i < a.Length ? a[i] : "<нет>";
                string lb = i < b.Length ? b[i] : "<нет>";
                if (la == lb) continue;
                diff++;
                if (shown++ < 12) Console.WriteLine("строка " + i + "\n  js: " + la + "\n  c#: " + lb);
            }
            Console.WriteLine("строк: js=" + a.Length + " cs=" + b.Length + " · расхождений: " + diff);
            return diff == 0 ? 0 : 1;
        }
        Tests();
        return _fails == 0 ? 0 : 1;
    }
}
