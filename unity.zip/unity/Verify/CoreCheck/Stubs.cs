// Минимальные заглушки UnityEngine, чтобы ядро можно было собрать и прогнать
// «на голом» .NET (без Unity) — см. Verify/README.md.
// Повторяют форму реальных типов: поля x/y, r/g/b/a, публичные конструкторы.
using System;

namespace UnityEngine
{
    public struct Vector2
    {
        public float x, y;
        public Vector2(float x, float y) { this.x = x; this.y = y; }
        public static Vector2 zero { get { return new Vector2(0, 0); } }
        public override string ToString() { return "(" + x + ", " + y + ")"; }
    }

    public struct Color32
    {
        public byte r, g, b, a;
        public Color32(byte r, byte g, byte b, byte a) { this.r = r; this.g = g; this.b = b; this.a = a; }
    }
}
