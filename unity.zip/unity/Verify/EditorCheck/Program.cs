// ============================================================================
//  EditorCheck: проверяет Editor-скрипты PvZ без Unity.
//
//    1) компиляция против заглушек, повторяющих ScriptReference 2022.3
//       (так поймаешь «члена нет в этой версии» — на этом же ловились
//       SpriteAlignment.UpperLeft, TextureImporter.spriteAlignment,
//       AudioImporter.loadType);
//    2) поведение: какие настройки импорта реально выставились, идемпотентность
//       PrepareProject и вся матрица решений автосборки сцены (PvzAutoSetup).
//
//  Запускать из пустой временной папки — тесты создают там Assets/Scenes/** и
//  Pvz-Build/** на диске.
// ============================================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;
using UnityEngine;
using Pvz.View;
using PvzEditor;

public static class Program
{
    private const BindingFlags NonPublic = BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
    private const BindingFlags All = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
    private static readonly string ScenePath = PvzBootstrapper.ScenePath;

    private static int _ok, _fail;

    private static void Yes(string what, bool cond)
    {
        if (cond) { _ok++; Console.WriteLine("  ok   " + what); }
        else { _fail++; Console.WriteLine("  FAIL " + what); }
    }

    private static void Yes(string what, bool cond, string detail)
    {
        if (cond) { _ok++; Console.WriteLine("  ok   " + what); }
        else { _fail++; Console.WriteLine("  FAIL " + what + "  → " + detail); }
    }

    private static void Eq(string what, object got, object want)
    {
        bool same = Equals(got, want);
        Yes(what + " = " + Show(got) + (same ? "" : "  (ожидалось " + Show(want) + ")"), same);
    }
    private static string Show(object o)
    {
        if (o == null) return "null";
        if (o is string) return "\"" + o + "\"";
        return o.ToString();
    }

    public static int Main()
    {
        Debug.record = true;
        // «проект», в котором крутятся редакторские скрипты: все пути идут от
        // Application.dataPath, так что тест можно запускать из любой папки
        Application.dataPath = Path.Combine(Directory.GetCurrentDirectory(), "PvzProj", "Assets");
        Directory.CreateDirectory(Application.dataPath);
        Console.WriteLine("EditorCheck: проект " + Path.GetDirectoryName(Application.dataPath));

        ImporterTexture();
        ImporterGuard();
        ImporterAudio();
        ImporterStubActuallyChecks();
        PrepareProject();
        AutoSetup();
        Menus();
        CheckAssetsAndReimport();
        ShippedAssets();
        ProgressFlow();
        NoMutateWhileEnumerating();
        FontCoversUiStrings();
        NoKillCounterInUi();
        BuildMenu();

        Console.WriteLine(_fail == 0
            ? "OK: проверок " + _ok + " — редакторские скрипты компилируются и ведут себя правильно"
            : "ПРОВАЛ: " + _fail + " из " + (_ok + _fail));
        return _fail == 0 ? 0 : 1;
    }

    // ------------------------------------------------------------------ импорт
    private static object NewImporter(string path, AssetImporter im)
    {
        var obj = Activator.CreateInstance(typeof(PvzImporter), true);
        ((AssetPostprocessor)obj).assetPath = path;
        ((AssetPostprocessor)obj).assetImporter = im;
        return obj;
    }

    private static void Call(object obj, string method)
    {
        typeof(PvzImporter).GetMethod(method, NonPublic).Invoke(obj, null);
    }

    private static void ImporterTexture()
    {
        Console.WriteLine("[1] импорт PNG");
        var ti = new TextureImporter();
        Call(NewImporter("Assets/Resources/Pvz/assets/plants/sunflower.png", ti), "OnPreprocessTexture");

        Eq("textureType", ti.textureType, TextureImporterType.Sprite);
        Eq("spriteImportMode", ti.spriteImportMode, SpriteImportMode.Single);
        Eq("PPU", ti.spritePixelsPerUnit, 1f);
        Yes("mipMaps выключены", !ti.mipmapEnabled && !ti.streamingMipmaps);
        Eq("filter", ti.filterMode, FilterMode.Point);
        Eq("wrap", ti.wrapMode, TextureWrapMode.Clamp);
        Yes("Read/Write", ti.isReadable);
        Yes("ignoreMipmapLimit (бывш. ignoreMasterTextureLimit)", ti.ignoreMipmapLimit);
        Eq("npotScale", ti.npotScale, TextureImporterNPOTScale.None);
        Eq("compression", ti.textureCompression, TextureImporterCompression.Uncompressed);
        Yes("sRGB", ti.sRGBTexture);
        Yes("alphaIsTransparency", ti.alphaIsTransparency);
        Yes("Settings прочитаны и записаны", ti._read && ti._applied == (int)SpriteAlignment.TopLeft);
        Eq("пивот через SpriteAlignment", (SpriteAlignment)ti._applied, SpriteAlignment.TopLeft);
        Eq("пивот Vector2", ti.spritePivot, new Vector2(0f, 1f));
        Eq("border", ti.spriteBorder, Vector4.zero);
    }

    private static void ImporterGuard()
    {
        Console.WriteLine("[2] чужие папки не трогаем");
        var ti = new TextureImporter();
        Call(NewImporter("Assets/Textures/ui-atlas.png", ti), "OnPreprocessTexture");
        Eq("PPU не изменён", ti.spritePixelsPerUnit, 100f);
        Yes("settings не трогались", !ti._read && ti._applied == int.MinValue);

        var ai = new AudioImporter();
        AudioClipLoadType was = ai.defaultSampleSettings.loadType;
        Call(NewImporter("Assets/Audio/music.wav", ai), "OnPreprocessAudio");
        Eq("звук вне Pvz/ не тронут", ai.defaultSampleSettings.loadType, was);
    }

    private static void ImporterAudio()
    {
        Console.WriteLine("[3] импорт WAV");
        var ai = new AudioImporter();
        Call(NewImporter("Assets/Resources/Pvz/audio/collect.wav", ai), "OnPreprocessAudio");
        Eq("loadType", ai.defaultSampleSettings.loadType, AudioClipLoadType.DecompressOnLoad);
        Eq("compressionFormat", ai.defaultSampleSettings.compressionFormat, AudioCompressionFormat.PCM);
        Yes("не моно", !ai.forceToMono);
    }

    private static void ImporterStubActuallyChecks()
    {
        Console.WriteLine("[4] стаб реально следит за правилами (а не всегда true)");
        var ti = new TextureImporter();
        var st = new TextureImporterSettings();
        ti.ReadTextureSettings(st);
        st.spritePixelsPerUnit = 100f;                     // PPU обязан быть 1
        bool threw = false;
        try { ti.SetTextureSettings(st); } catch (InvalidOperationException) { threw = true; }
        Yes("PPU != 1 → exception", threw);

        st = new TextureImporterSettings();
        ti.ReadTextureSettings(st);
        st.spritePixelsPerUnit = 1f;
        st.spriteAlignment = (int)SpriteAlignment.Center;  // пивот обязан быть TopLeft
        threw = false;
        try { ti.SetTextureSettings(st); } catch (InvalidOperationException) { threw = true; }
        Yes("пивот != TopLeft → exception", threw);
    }

    // --------------------------------------------------------------- проект
    private static void PrepareProject()
    {
        Console.WriteLine("[5] PrepareProject идемпотентен");
        SerializedObject.ForgetTargets();
        SerializedObject.All.Clear();
        PlayerSettings.colorSpace = ColorSpace.Linear;
        Debug.Clear();

        PvzBootstrapper.PrepareProject();
        Eq("Color Space", PlayerSettings.colorSpace, ColorSpace.Gamma);
        var so = LastSerialized();
        var arr = so == null ? null : so.FindProperty("m_SortingLayers");
        Yes("m_SortingLayers найден", arr != null);
        Eq("слоёв добавлено", arr == null ? -1 : arr.arraySize, Sort.All.Length);
        bool names = arr != null && arr.arraySize == Sort.All.Length;
        for (int i = 0; i < (arr == null ? 0 : arr.arraySize) && i < Sort.All.Length; i++)
            if (arr.GetArrayElementAtIndex(i).FindPropertyRelative("name").stringValue != Sort.All[i]) names = false;
        Yes("имена слоёв = Sort.All", names);
        Yes("ApplyModifiedProperties вызван", so != null && so.ApplyCalls == 1);

        Debug.Clear();
        PvzBootstrapper.PrepareProject();
        var so2 = LastSerialized();
        var arr2 = so2 == null ? null : so2.FindProperty("m_SortingLayers");
        Eq("слои не удвоились", arr2 == null ? -1 : arr2.arraySize, Sort.All.Length);
        Yes("второй раз — тишина", !Debug.AnyContains("добавлено sorting layers"));
        Yes("Color Space не пилим зря", !Debug.AnyContains("Color Space → Gamma"));

        // нет TagManager.asset → только предупреждение, без падения
        SerializedObject.ForgetTargets();
        AssetDatabase.StubTagManager = false;
        bool threw = false;
        try { PvzBootstrapper.PrepareProject(); } catch (Exception e) { threw = true; Console.WriteLine("       " + e.Message); }
        Yes("без TagManager не падает", !threw);
        AssetDatabase.StubTagManager = true;
    }

    private static SerializedObject LastSerialized()
    {
        return SerializedObject.All.Count == 0 ? null : SerializedObject.All[SerializedObject.All.Count - 1];
    }

    // ----------------------------------------------------------- автосборка
    private static void RunAuto()
    {
        typeof(PvzAutoSetup).GetMethod("Run", BindingFlags.NonPublic | BindingFlags.Static).Invoke(null, null);
    }

    private static void Fresh(bool sceneOnDisk, string activePath, bool dirty, GameObject[] roots)
    {
        string file = PvzBootstrapper.SceneFile;
        Directory.CreateDirectory(Path.GetDirectoryName(file));
        if (sceneOnDisk && !File.Exists(file)) File.WriteAllText(file, "%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n");
        if (!sceneOnDisk && File.Exists(file)) File.Delete(file);

        var s = new Scene
        {
            name = Path.GetFileNameWithoutExtension(activePath.Length == 0 ? "Untitled" : activePath),
            path = activePath,
            isDirty = dirty,
            roots = roots
        };
        EditorSceneManager.Active = s;
        EditorSceneManager.Opened.Clear();
        EditorSceneManager.Saved.Clear();
        EditorSceneManager.NewSceneCalls = 0;
        GameObject.StubCreated.Clear();
        EditorPrefs.Bools.Clear();
        EditorBuildSettings.scenes = new EditorBuildSettingsScene[0];
        SerializedObject.ForgetTargets();
        SerializedObject.All.Clear();
        Debug.Clear();
    }

    private static void AutoSetup()
    {
        Console.WriteLine("[6] автосборка сцены (PvzAutoSetup.Run)");
        System.Runtime.CompilerServices.RuntimeHelpers.RunClassConstructor(typeof(PvzAutoSetup).TypeHandle);
        Yes("Run запланирован на delayCall при загрузке домена", EditorApplication.delayCall != null);

        // сцена уже есть, активна Untitled → просто открыть
        Fresh(true, "", false, null);
        RunAuto();
        Eq("открыта наша сцена", EditorSceneManager.Opened.Count == 1 ? EditorSceneManager.Opened[0] : null, ScenePath);
        Eq("CreateScene не звался", EditorSceneManager.NewSceneCalls, 0);
        Yes("log про Play", Debug.AnyContains("открыта сцена"));

        // на активной сцене уже есть GameRoot → не мешаем
        var go = new GameObject("PvZ");
        go.AddComponent<GameRoot>();
        Fresh(true, ScenePath, false, new[] { go });
        RunAuto();
        Eq("ничего не открыто", EditorSceneManager.Opened.Count, 0);
        Eq("и не создано", EditorSceneManager.NewSceneCalls, 0);

        // открыта чужая сохранённая сцена → не отбираем
        Fresh(true, "Assets/Scenes/Mine.unity", false, null);
        RunAuto();
        Eq("чужую сцену не открыли/не сменили", EditorSceneManager.Opened.Count, 0);
        Yes("сказали, что делать", Debug.AnyContains("не переключаю"));

        // Untitled с несохранёнными правками → не лезем
        Fresh(true, "", true, null);
        RunAuto();
        Eq("не тронули грязную сцену", EditorSceneManager.Opened.Count + EditorSceneManager.NewSceneCalls, 0);
        Yes("объяснили почему", Debug.AnyContains("не сохранена"));

        // сцены нет совсем → собрать с нуля
        Fresh(false, "", false, null);
        PlayerSettings.colorSpace = ColorSpace.Linear;
        RunAuto();
        Eq("создана новая сцена", EditorSceneManager.NewSceneCalls, 1);
        Eq("сохранена по нужному пути", EditorSceneManager.Saved.Count == 1 ? EditorSceneManager.Saved[0] : null, ScenePath);
        Yes("файл сцены на диске", File.Exists(PvzBootstrapper.SceneFile));
        Eq("в Build Settings", HasSceneInBuild(), true);
        Eq("Color Space", PlayerSettings.colorSpace, ColorSpace.Gamma);

        GameObject root = GameObject.StubCreated.Count == 0 ? null : GameObject.StubCreated[GameObject.StubCreated.Count - 1];
        var gr = root == null ? null : root.GetComponent<GameRoot>();
        Yes("на GameObject висит GameRoot", gr != null);
        if (gr != null)
        {
            Eq("имя объекта", root.name, "PvZ");
            Eq("LevelIndex", gr.LevelIndex, 0);
            Eq("StartInMenu", gr.StartInMenu, true);
            Eq("PixelPerfect", gr.PixelPerfect, true);
        }
        Yes("log «сцена собрана автоматически»", Debug.AnyContains("сцена собрана автоматически"));

        // второй прогон: уже ничего делать не надо
        int before = EditorSceneManager.NewSceneCalls + EditorSceneManager.Opened.Count;
        var s2 = EditorSceneManager.Active;
        s2.roots = new[] { root };
        EditorSceneManager.Active = s2;
        Debug.Clear();
        RunAuto();
        Eq("идемпотентно: ничего не открыто/создано",
            EditorSceneManager.NewSceneCalls + EditorSceneManager.Opened.Count, before);

        // галка выкл → Run ничего не делает
        Fresh(false, "", false, null);
        EditorPrefs.SetBool("Pvz.AutoSetupScene", false);
        RunAuto();
        Eq("выключенная автосборка не трогает сцены", EditorSceneManager.NewSceneCalls + EditorSceneManager.Opened.Count, 0);
        Yes("сказала, что выключена", Debug.AnyContains("выключена"));

        // сам тумблер
        typeof(PvzAutoSetup).GetMethod("Toggle", NonPublic).Invoke(null, null);
        Eq("EditorPrefs переключился", EditorPrefs.GetBool("Pvz.AutoSetupScene", true), true);
        Eq("галка в меню синхронна", Menu.GetChecked("PvZ/Автонастройка сцены"), true);
        Yes("SetChecked вызывался", Menu.SetCheckedCalls > 0);
        object v = typeof(PvzAutoSetup).GetMethod("ToggleValidate", NonPublic).Invoke(null, null);
        Eq("validate-функция возвращает true", v, true);
    }

    private static bool HasSceneInBuild()
    {
        var sc = EditorBuildSettings.scenes;
        if (sc == null) return false;
        for (int i = 0; i < sc.Length; i++) if (sc[i].path == ScenePath && sc[i].enabled) return true;
        return false;
    }

    // ------------------------------------------------------------------- меню
    private static void Menus()
    {
        Console.WriteLine("[7] пункты меню");
        var want = new Dictionary<string, Type>
        {
            { "PvZ/Создать сцену 1-1", typeof(PvzBootstrapper) },
            { "PvZ/Собрать билд (Windows)", typeof(PvzBootstrapper) },
            { "PvZ/Проверить ассеты", typeof(PvzBootstrapper) },
            { "PvZ/Переимпортировать ассеты", typeof(PvzImporter) },
            { "PvZ/Автонастройка сцены", typeof(PvzAutoSetup) },
            { "PvZ/Сбросить прогресс", typeof(PvzBootstrapper) },
        };
        var found = new Dictionary<string, MethodInfo>();
        var validate = new HashSet<string>();
        foreach (Type t in new[] { typeof(PvzBootstrapper), typeof(PvzImporter), typeof(PvzAutoSetup) })
        {
            foreach (var m in t.GetMethods(All))
            {
                var a = (MenuItemAttribute[])m.GetCustomAttributes(typeof(MenuItemAttribute), false);
                for (int i = 0; i < a.Length; i++)
                {
                    if (a[i].isValidateFunction) validate.Add(a[i].path);
                    else found[a[i].path] = m;
                }
            }
        }
        foreach (var kv in want)
        {
            MethodInfo m;
            Yes("есть «" + kv.Key + "»", found.TryGetValue(kv.Key, out m) && m.IsStatic && m.GetParameters().Length == 0);
            if (m != null && kv.Value != null)
                Yes("  принадлежит " + kv.Value.Name, m.DeclaringType == kv.Value);
        }
        Yes("у галки есть validate-функция", validate.Contains("PvZ/Автонастройка сцены"));
        Yes("[InitializeOnLoad] на PvzAutoSetup",
            typeof(PvzAutoSetup).GetCustomAttributes(typeof(InitializeOnLoadAttribute), false).Length == 1);
    }

    /// <summary>Прогресс: награды, открытие уровней и пункт «Сбросить прогресс».</summary>
    private static void ProgressFlow()
    {
        Console.WriteLine("[8c] прогресс и награды");
        UnityEngine.PlayerPrefs.Wipe();
        Yes("на старте открыт только горохострел", Pvz.View.Progress.Plants().Count == 1);
        Yes("на старте доступен только 1-1",
            Pvz.View.Progress.LevelOpen(0) && !Pvz.View.Progress.LevelOpen(1));
        Yes("на старте лопаты нет — её ещё не заработали", !Pvz.View.Progress.HasTool("shovel"));
        var l1 = Pvz.Core.CFG.LEVELS[0];
        var l2 = Pvz.Core.CFG.LEVELS[1];
        // награды разведены по уровням, как в оригинале: подсолнух за 1-1, вишня за 1-2.
        // Проверяем не «что-то выдаётся», а конкретно что и когда — иначе баг
        // «1-1 отдал оба растения, 1-2 ни одного» пройдёт как сейчас и не всплывёт.
        Yes("1-1 выдаёт ровно одно растение — подсолнух",
            l1.Rewards != null && l1.Rewards.Count == 1 && l1.Rewards[0] == "sunflower",
            l1.Rewards == null ? "null" : string.Join(",", l1.Rewards.ToArray()));
        Yes("1-2 выдаёт ровно одно растение — вишню",
            l2.Rewards != null && l2.Rewards.Count == 1 && l2.Rewards[0] == "cherry",
            l2.Rewards == null ? "null" : string.Join(",", l2.Rewards.ToArray()));
        Pvz.View.Progress.Won(0, l1);
        Yes("1-2 открыт после победы", Pvz.View.Progress.LevelOpen(1));
        Yes("лопата выдана наградой за 1-1", Pvz.View.Progress.HasTool("shovel"));
        Yes("лопата — инструмент, а не растение (в Plants() её нет)",
            Pvz.View.Progress.Plants().IndexOf("shovel") < 0, string.Join(",", Pvz.View.Progress.Plants().ToArray()));
        Yes("лопата не добавляет карту в пачку 1-1",
            new Pvz.Core.World(l1, 1u, Pvz.View.Progress.Plants()).Seeds.Count == 1);
        Yes("после 1-1 открыто два растения (горох + подсолнух)",
            Pvz.View.Progress.Plants().Count == 2, "n=" + Pvz.View.Progress.Plants().Count);
        Yes("вишня после 1-1 ещё закрыта", !Pvz.View.Progress.Has("cherry"));
        Yes("1-1 после наград всё ещё с одной карточкой",
            new Pvz.Core.World(l1, 1u, Pvz.View.Progress.Plants()).Seeds.Count == 1);
        var afterL1 = new Pvz.Core.World(l2, 1u, Pvz.View.Progress.Plants());
        Yes("1-2 после 1-1 — две карточки, вишни в пачке нет", afterL1.Seeds.Count == 2,
            string.Join(",", afterL1.Seeds.ToArray()));
        Yes("1-2 без наград — только горохострел",
            new Pvz.Core.World(l2, 1u, new System.Collections.Generic.List<string> { "peashooter" }).Seeds.Count == 1);
        Pvz.View.Progress.Won(1, l2);
        Yes("вишня открыта после 1-2", Pvz.View.Progress.Has("cherry"));
        var afterL2 = new Pvz.Core.World(l2, 1u, Pvz.View.Progress.Plants());
        Yes("1-2 при повторе — три карточки", afterL2.Seeds.Count == 3,
            string.Join(",", afterL2.Seeds.ToArray()));
        // третий уровень: открыт после 1-2, играет без ореха и выдаёт именно орех
        var l3 = Pvz.Core.CFG.LEVELS[2];
        Yes("1-3 открыт после победы на 1-2", Pvz.View.Progress.LevelOpen(2));
        Yes("1-3 выдаёт ровно одно растение — орех",
            l3.Rewards != null && l3.Rewards.Count == 1 && l3.Rewards[0] == "wallnut",
            l3.Rewards == null ? "null" : string.Join(",", l3.Rewards.ToArray()));
        var deckL3 = new Pvz.Core.World(l3, 1u, Pvz.View.Progress.Plants());
        Yes("на 1-3 в пачке нет ореха — его ещё не заработали",
            deckL3.Seeds.Count == 3 && deckL3.Seeds.IndexOf("wallnut") < 0,
            string.Join(",", deckL3.Seeds.ToArray()));
        Yes("уровень перечисляет орех в своих seeds (иначе награда негде не играется)",
            l3.Seeds.IndexOf("wallnut") >= 0, string.Join(",", l3.Seeds.ToArray()));
        Yes("у 1-3 пять полос и пять косилок", new Pvz.Core.World(l3, 3u).UnlockedRows.Count == 5,
            "rows=" + new Pvz.Core.World(l3, 3u).UnlockedRows.Count);
        Pvz.View.Progress.Won(2, l3);
        Yes("орех открыт после 1-3", Pvz.View.Progress.Has("wallnut"));
        Yes("после трёх побед открыто все четыре растения",
            Pvz.View.Progress.Plants().Count == 4, "n=" + Pvz.View.Progress.Plants().Count);
        var deckL3b = new Pvz.Core.World(l3, 1u, Pvz.View.Progress.Plants());
        Yes("при повторе 1-3 орех встаёт в пачку четвёртой картой",
            deckL3b.Seeds.Count == 4 && deckL3b.Seeds.IndexOf("wallnut") >= 0,
            string.Join(",", deckL3b.Seeds.ToArray()));
        // четвёртый уровень: чемпер — награда, лопата уже выдана раньше и тут не дублируется
        var l4 = Pvz.Core.CFG.LEVELS[3];
        Yes("1-4 открыт после победы на 1-3", Pvz.View.Progress.LevelOpen(3));
        Yes("1-4 выдаёт ровно одно растение — чемпера",
            l4.Rewards != null && l4.Rewards.Count == 1 && l4.Rewards[0] == "chomper",
            l4.Rewards == null ? "null" : string.Join(",", l4.Rewards.ToArray()));
        Yes("1-4 ничего не выдаёт инструментами (лопата уже есть)",
            l4.Tools == null || l4.Tools.Count == 0,
            l4.Tools == null ? "null" : string.Join(",", l4.Tools.ToArray()));
        var deckL4 = new Pvz.Core.World(l4, 1u, Pvz.View.Progress.Plants());
        Yes("на 1-4 в пачке нет чемпера — его ещё не заработали",
            deckL4.Seeds.Count == 4 && deckL4.Seeds.IndexOf("chomper") < 0,
            string.Join(",", deckL4.Seeds.ToArray()));
        Yes("1-4 перечисляет чемпера в своих seeds (иначе награде негде играть)",
            l4.Seeds.IndexOf("chomper") >= 0, string.Join(",", l4.Seeds.ToArray()));
        Pvz.View.Progress.Won(3, l4);
        Yes("чемпер открыт после 1-4", Pvz.View.Progress.Has("chomper"));
        Yes("после четырёх побед открыто все пять растений",
            Pvz.View.Progress.Plants().Count == 5, "n=" + Pvz.View.Progress.Plants().Count);
        var deckL4b = new Pvz.Core.World(l4, 1u, Pvz.View.Progress.Plants());
        Yes("при повторе 1-4 чемпер встаёт пятой картой",
            deckL4b.Seeds.Count == 5 && deckL4b.Seeds.IndexOf("chomper") >= 0,
            string.Join(",", deckL4b.Seeds.ToArray()));
        Yes("подзаголовок меню склоняет «4 УРОВНЯ»", Pvz.View.MenuLayout.LevelsWord(4) == "4 УРОВНЯ",
            Pvz.View.MenuLayout.LevelsWord(4));
        Yes("экран победы 1-1 называет лопату отдельно от растения",
            Pvz.View.Progress.ToolNames(l1) == "ЛОПАТА" && Pvz.View.Progress.RewardNames(l1) == "ПОДСОЛНУХ",
            Pvz.View.Progress.ToolNames(l1) + "/" + Pvz.View.Progress.RewardNames(l1));
        Yes("winTip 1-4 — про чемпера", l4.WinTip.Contains("ЧЕМПЕР"), l4.WinTip);
        Yes("подзаголовок меню склоняет число уровней",
            Pvz.View.MenuLayout.LevelsWord(3) == "3 УРОВНЯ" &&
            Pvz.View.MenuLayout.LevelsWord(1) == "1 УРОВЕНЬ" &&
            Pvz.View.MenuLayout.LevelsWord(5) == "5 УРОВНЕЙ", Pvz.View.MenuLayout.LevelsWord(3));
        Yes("экран победы 1-1 называет подсолнух", Pvz.View.Progress.RewardNames(l1) == "ПОДСОЛНУХ",
            Pvz.View.Progress.RewardNames(l1));
        Yes("экран победы 1-2 называет вишню", Pvz.View.Progress.RewardNames(l2).Contains("ВИШНЯ"),
            Pvz.View.Progress.RewardNames(l2));
        Yes("winTip 1-1 не обещает вишню", l1.WinTip.Contains("ПОДСОЛНУХ") && !l1.WinTip.Contains("ВИШНЯ"),
            l1.WinTip);
        Yes("winTip 1-2 — про вишню", l2.WinTip.Contains("ВИШНЯ"), l2.WinTip);
        PvzBootstrapper.ResetProgress();
        Yes("сброс вернул пустой список растений", UnityEngine.PlayerPrefs.GetString("pvz.plants", "").Length == 0);
        Yes("сброс закрыл уровни", UnityEngine.PlayerPrefs.GetInt("pvz.level", 0) == 0);
        Yes("после сброса снова один горохострел", Pvz.View.Progress.Plants().Count == 1);
        Yes("в логе есть отчёт о сбросе", Debug.AnyContains("прогресс сброшен"));
        UnityEngine.PlayerPrefs.Wipe();
    }

    private static void CheckAssetsAndReimport()
    {
        Console.WriteLine("[8] сервисные пункты не падают без ассетов");
        Debug.Clear();
        PvzBootstrapper.CheckAssets();
        Yes("CheckAssets отчитался", Debug.AnyContains("[PvZ] ассеты:"));
        PvzImporter.Reimport();
        Yes("Reimport без папки — предупреждение, не exception", Debug.AnyContains("нечего импортировать"));
    }

    /// <summary>Проверка самой поставки:png/wav, которые игра грузит из Resources,
    /// лежат рядом с этим проектом (в архиве). Запускается из unity/Verify/EditorCheck —
    /// там Assets/Resources/Pvz находится вверх по дереву; если рядом его нет (например,
    /// тест гоняют из /tmp) — проверка честно пропускается, а не «всегда зелёная».</summary>
    private static void ShippedAssets()
    {
        Console.WriteLine("[8b] что лежит в поставке");
        var dir = new DirectoryInfo(Directory.GetCurrentDirectory());
        string res = null;
        for (int i = 0; i < 8 && dir != null; i++, dir = dir.Parent)
        {
            string cand = Path.Combine(dir.FullName, "Assets", "Resources", "Pvz");
            if (Directory.Exists(cand)) { res = cand; break; }
        }
        if (res == null)
        {
            Console.WriteLine("  пропуск: рядом с " + Directory.GetCurrentDirectory() + " нет Assets/Resources/Pvz");
            return;
        }
        string[] must = { "assets/plants/cherry.png", "assets/zombies/cone.png", "assets/zombies/cone-dmg.png",
                          "audio/boom.wav", "assets/plants/peashooter.png", "audio/shoot.wav",
                          // чемпер и лопата: без них карта 1-4 и слот в HUD — пустые квадраты
                          "assets/plants/chomper.png", "assets/fx/shovel.png",
                          // стадии ореха: без них скорлупа всю дорогу выглядит целой
                          "assets/plants/wallnut.png", "assets/plants/wallnut_dmg1.png",
                          "assets/plants/wallnut_dmg2.png", "assets/plants/wallnut_dmg3.png",
                          // кадры движения: без них «анимации нет», и это не видно в логах
                          "assets/zombies/basic_walk_0.png", "assets/zombies/basic_walk_3.png",
                          "assets/zombies/basic_eat_1.png", "assets/zombies/basic_death_2.png",
                          "assets/plants/chomper_chew_0.png", "assets/plants/chomper_chew_3.png" };
        for (int i = 0; i < must.Length; i++)
            Yes("в поставке есть " + must[i], File.Exists(Path.Combine(res, must[i].Replace('/', Path.DirectorySeparatorChar))));

        // Кадры анимаций. Смысл именно списка: не хватает файла — ядро не падает, а
        // молча остаётся на статичном спрайте, и «анимаций нет» видно только глазами.
        // Поэтому проверяем, что в каждой группе минимум два кадра (одного не хватает
        // ни на какой цикл) и что имя совпадает с тем, что просит SpriteLib/Assets.js.
        string[] anims = { "zombies/basic|walk", "zombies/basic|eat", "zombies/basic|death",
                           "zombies/basic-arm|walk", "zombies/basic-limp|walk", "zombies/basic-headless|walk",
                           "plants/chomper|eat", "plants/chomper|chew", "plants/peashooter|shoot",
                           "plants/sunflower|shoot" };
        for (int i = 0; i < anims.Length; i++)
        {
            int slash = anims[i].IndexOf('/'), bar = anims[i].IndexOf('|');
            string adir = anims[i].Substring(0, slash);
            string astem = anims[i].Substring(slash + 1, bar - slash - 1);
            string agrp = anims[i].Substring(bar + 1);
            // в Resources всё лежит под assets/ — там же, откуда их берёт веб-версия
            string afolder = Path.Combine(res, "assets", adir.Replace('/', Path.DirectorySeparatorChar));
            int agot = Directory.Exists(afolder)
                ? Directory.GetFiles(afolder, astem + "_" + agrp + "_*.png").Length : 0;
            // шаг и жвачка — по четыре кадра: на двух кадрах «медленного» цикла ноги
            // не перебирают, а силуэт только вздрагивает
            int aneed = agrp == "walk" || agrp == "chew" ? 4 : 2;
            Yes("анимация " + astem + " · " + agrp + ": кадров хватает", agot >= aneed,
                "найдено " + agot + ", нужно " + aneed);
        }

        // res = <проект>/Assets/Resources/Pvz  →  наверх три ступени = корень проекта
        string saved = UnityEngine.Application.dataPath;
        UnityEngine.Application.dataPath = Path.Combine(new DirectoryInfo(res).Parent.Parent.Parent.FullName, "Assets");
        Debug.Clear();
        PvzBootstrapper.CheckAssets();
        UnityEngine.Application.dataPath = saved;
        string log = "";
        for (int i = 0; i < Debug.Logs.Count; i++)
            if (Debug.Logs[i].Contains("[PvZ] ассеты:")) log = Debug.Logs[i];
        Yes("CheckAssets не находит пробелов", log.Contains("не хватает: нет"), log);
        var m = System.Text.RegularExpressions.Regex.Match(log, @"ассеты: (\d+) png, (\d+) wav");
        Yes("в Resources 62+ png и 13+ wav",
            m.Success && int.Parse(m.Groups[1].Value) >= 62 && int.Parse(m.Groups[2].Value) >= 13, log);
    }

    /// <summary>Конструкция, которую офлайн-тест не увидит НИКОГДА: правка коллекции
    /// внутри её же перечисления. Разница рантаймов злая — в .NET Core присваивание
    /// <c>dict[k] = v</c> под <c>foreach</c> по этому словарю проходит молча, а в Mono
    /// (то есть в Unity) инвалидирует итератор: InvalidOperationException «Collection was
    /// modified». Именно так и умер тик перезарядки карточек. Поэтому — статический скан
    /// игровых скриптов; детектор сначала проверяет сам себя на заведомо плохом куске
    /// (иначе это была бы зелёная заглушка), потом работает по настоящим исходникам.</summary>
    private static void NoMutateWhileEnumerating()
    {
        Console.WriteLine("[8d] правка коллекции под её же перечислением");
        string bad = "void T()\n{\n    foreach (var kv in _cool)\n    {\n        if (kv.Value <= 0) continue;\n        _cool[kv.Key] = 0;\n    }\n}\n";
        var hit = Scan(bad);
        Yes("детектор видит заведомо плохой код", hit.Count == 1 && hit[0].Contains("_cool"),
            string.Join(" | ", hit.ToArray()));
        var decoy = Scan("void T()\n{\n    foreach (var z in Zombies) HurtZombie(z, 1);\n}\n");
        Yes("чтение коллекции под foreach не считается правкой", decoy.Count == 0,
            string.Join(" | ", decoy.ToArray()));
        var addHit = Scan("void T()\n{\n    foreach (var k in _coolKeys) _coolKeys.Add(k);\n}\n");
        Yes("детектор ловит и структурную правку (.Add)", addHit.Count == 1,
            string.Join(" | ", addHit.ToArray()));
        var qualifier = Scan("void T()\n{\n    foreach (string id in level.Seeds)\n    {\n        Seeds.Add(id);\n    }\n}\n");
        Yes("разные коллекции с одинаковым хвостом не путаются", qualifier.Count == 0,
            string.Join(" | ", qualifier.ToArray()));
        var good = Scan("void T()\n{\n    for (int i = 0; i < _coolKeys.Count; i++)\n    {\n        string k = _coolKeys[i];\n        _cool[k] = 0;\n    }\n}\n");
        Yes("детектор не воет на правильном коде (список ключей + словарь)", good.Count == 0,
            string.Join(" | ", good.ToArray()));

        string dir = ScriptsDir();
        if (dir == null)
        {
            Console.WriteLine("  пропуск: рядом с " + Directory.GetCurrentDirectory() + " нет Assets/Scripts");
            return;
        }
        int files = 0;
        var all = new List<string>();
        foreach (string f in Directory.GetFiles(dir, "*.cs", SearchOption.AllDirectories))
        {
            files++;
            foreach (string h in Scan(File.ReadAllText(f))) all.Add(Path.GetFileName(f) + " " + h);
        }
        Yes("в игровых скриптах (" + files + " шт.) нет правок коллекции под foreach", all.Count == 0,
            string.Join(" | ", all.ToArray()));
    }

    /// <summary>Шрифт 5×7 должен покрывать всё, что печатается: отсутствующий глиф
    /// Tex не пропускает, а рисует точку (именно так в подсказках меню вместо «←» и
    /// «↑↓» были точки). Скан собирает строковые литералы из Assets/Scripts, отбрасывает
    /// комментарии и служебные символы (цвета «#1f2a18», форматные «{0:F1}»), и сверяет
    /// каждую букву/цифру/знак с таблицей глифов. Сначала проверка на себе: если бы
    /// TryGet всегда возвращал true, секция была бы зелёной заглушкой.</summary>
    private static void FontCoversUiStrings()
    {
        Console.WriteLine("[8e] шрифт покрывает строки интерфейса");
        int[] dummy;
        Yes("отсутствующий глиф TryGet действительно не находит",
            !Pvz.View.Glyphs.TryGet('§', out dummy) && Pvz.View.Glyphs.TryGet('А', out dummy));
        Yes("стрелки подсказок есть в шрифте",
            Pvz.View.Glyphs.TryGet('←', out dummy) && Pvz.View.Glyphs.TryGet('→', out dummy) &&
            Pvz.View.Glyphs.TryGet('↑', out dummy) && Pvz.View.Glyphs.TryGet('↓', out dummy));

        string dir = ScriptsDir();
        if (dir == null)
        {
            Console.WriteLine("  пропуск: рядом с " + Directory.GetCurrentDirectory() + " нет Assets/Scripts");
            return;
        }
        string shown = ".,:;!?(«»—·/-'%+0123456789←→↑↓☼";
        // список «что вообще должно быть нарисовано» — whitelist: в строках кода
        // живут цвета («#1f2a18») и формат («{0:F1}»), которые на экран не попадают,
        // угадывать ихчёрным списком нельзя. Стрелки сюда включены специально: подсказки
        // карты рисуют «← → ↑ ↓», и однажды они были точками вместо стрелок.
        var missing = new SortedSet<string>();
        int files = 0, literals = 0, checkedChars = 0;
        foreach (string f in Directory.GetFiles(dir, "*.cs", SearchOption.AllDirectories))
        {
            files++;
            string src = File.ReadAllText(f);
            // комментарии вон: там что угодно написано, а на экран это не попадает
            int c0;
            while ((c0 = src.IndexOf("/*")) >= 0)
            {
                int c1 = src.IndexOf("*/", c0 + 2);
                if (c1 < 0) { c1 = src.Length - 2; }
                src = src.Remove(c0, c1 - c0 + 2);
            }
        foreach (string line in src.Split('\n'))
            {
                int sl = line.IndexOf("//");
                string code = sl >= 0 ? line.Substring(0, sl) : line;
                int i = 0;
                while (i < code.Length)
                {
                    if (code[i] != '\"' && code[i] != '\'') { i++; continue; }
                    char q = code[i++];
                    int start = i;
                    while (i < code.Length && code[i] != q) { if (code[i] == '\\') i++; i++; }
                    string lit = i < code.Length ? code.Substring(start, i - start) : "";
                    i++;
                    if (lit.Length == 0) continue;
                    literals++;
                    foreach (char ch in lit)
                    {
                        if (ch <= ' ') continue;
                        bool interesting = char.IsLetter(ch) || char.IsDigit(ch) || shown.IndexOf(ch) >= 0;
                        if (!interesting) continue;                     // цвета, формат, идентификаторы
                        checkedChars++;
                        int[] bits;
                        if (!Pvz.View.Glyphs.TryGet(ch, out bits)) missing.Add("'" + ch + "' U+" +
                                                                                ((int)ch).ToString("X4"));
                    }
                }
            }
        }
        Yes("скан что-то прочитал (не зелёная заглушка)", files >= 10 && literals > 200 && checkedChars > 2000,
            "файлов " + files + " · строк " + literals + " · символов " + checkedChars);
        Yes("в подписях и подсказках нет символа без глифа", missing.Count == 0, string.Join(" ", new List<string>(missing)));
    }

    /// <summary>Счётчик «убито X/Y» игрок просил убрать с экрана. Убирается он из
    /// отрисовки, а не из мира (World.KilledZombies нужен и для полосы прогресса, и
    /// для условия победы), поэтому проверка — статический скан: в коде, который
    /// что-то печатает, не должно быть склейки killed + "/" + total. Как и [8d]/[8e],
    /// скан сначала проверяет сам себя на заведомо плохом куске: зелёная заглушка
    /// хуже, чем её отсутствие.</summary>
    private static System.Collections.Generic.List<string> KillCounterHits(string src)
    {
        var hits = new System.Collections.Generic.List<string>();
        string[] lines = src.Replace("\r\n", "\n").Split('\n');
        var rx = new System.Text.RegularExpressions.Regex(
            "KilledZombies[^;\n]*\\+[^;\n]*TotalZombies|TotalZombies[^;\n]*\\+[^;\n]*KilledZombies");
        for (int i = 0; i < lines.Length; i++)
            if (rx.IsMatch(lines[i])) hits.Add("строка " + (i + 1) + ": " + lines[i].Trim());
        return hits;
    }

    private static void NoKillCounterInUi()
    {
        Console.WriteLine("[8f] на экране нет счётчика «убито X из Y»");
        Yes("детектор видит заведомо плохой код",
            KillCounterHits("t.Text(1, 2, \"ЗОМБИ \" + w.KilledZombies + \"/\" + w.TotalZombies, 1);").Count == 1, "");
        Yes("доля для полосы прогресса — не счётчик",
            KillCounterHits("float done = Mathf.Clamp01((float)w.KilledZombies / w.TotalZombies);").Count == 0, "");
        string dir = ScriptsDir();
        if (dir == null)
        {
            Console.WriteLine("  пропуск: рядом с " + Directory.GetCurrentDirectory() + " нет Assets/Scripts");
            return;
        }
        var hits = new System.Collections.Generic.List<string>();
        foreach (string f in Directory.GetFiles(dir, "*.cs", SearchOption.AllDirectories))
            foreach (string h in KillCounterHits(File.ReadAllText(f))) hits.Add(Path.GetFileName(f) + " " + h);
        Yes("ни HUD, ни экран победы не печатают убитых дробью", hits.Count == 0,
            string.Join(" | ", hits.ToArray()));
    }

    private static string ScriptsDir()
    {
        var dir = new DirectoryInfo(Directory.GetCurrentDirectory());
        for (int i = 0; i < 8 && dir != null; i++, dir = dir.Parent)
        {
            string cand = Path.Combine(dir.FullName, "unity", "Assets", "Scripts");
            if (Directory.Exists(cand)) return cand;
            cand = Path.Combine(dir.FullName, "Assets", "Scripts");
            if (Directory.Exists(cand)) return cand;
        }
        return null;
    }

    /// <summary>Находит в тексте «foreach ( … in COLL )» и смотрит, не правит ли тело
    /// ту же COLL (присваивание индексом, Add/Remove/Insert/Clear/Sort). Строки и
    /// комментарии при расстановке скобок пропускаются.</summary>
    private static List<string> Scan(string code)
    {
        var found = new List<string>();
        int i = 0;
        while (i < code.Length)
        {
            int at = code.IndexOf("foreach", i, StringComparison.Ordinal);
            if (at < 0) break;
            int open = code.IndexOf('(', at);
            int close = open < 0 ? -1 : Match(code, open, '(', ')');
            if (close < 0) break;
            string head = code.Substring(open + 1, close - open - 1);
            int inIdx = head.IndexOf(" in ", StringComparison.Ordinal);
            int bodyOpen = code.IndexOf('{', close);
            int bodyClose = bodyOpen < 0 ? -1 : Match(code, bodyOpen, '{', '}');
            int semi = code.IndexOf(';', close);
            if (semi >= 0 && (bodyOpen < 0 || semi < bodyOpen))
            {
                bodyOpen = close;                     // тело без фигурных скобок: до «;»
                bodyClose = semi + 1;
            }
            if (inIdx >= 0 && bodyOpen >= 0 && bodyClose > bodyOpen)
            {
                // имя берём ЦЕЛИКОМ вместе с квалификатором: «level.Seeds» и «Seeds» —
                // разные списки, а по одному хвосту скан давал бы ложняк на
                // foreach (var id in level.Seeds) { Seeds.Add(id); }
                string coll = head.Substring(inIdx + 4).Trim();
                int paren = coll.IndexOf('(');
                if (paren >= 0) coll = coll.Substring(0, paren);
                coll = coll.Trim();
                if (coll.Length > 0 && (char.IsLetter(coll[0]) || coll[0] == '_'))
                {
                    string body = code.Substring(bodyOpen + 1, bodyClose - bodyOpen - 1);
                    var rx = new System.Text.RegularExpressions.Regex(
                        @"(^|[^.\w])" + System.Text.RegularExpressions.Regex.Escape(coll) +
                        @"\s*(\[[^\]]*\]\s*=[^=]|\.(Add|Insert|Remove|RemoveAt|Clear|Sort|Reverse)\s*\()");
                    foreach (System.Text.RegularExpressions.Match m in rx.Matches(body))
                    {
                        int line = 1;
                        for (int k = 0; k <= bodyOpen + m.Index; k++) if (code[k] == '\n') line++;
                        found.Add("строка " + line + ": правка «" + coll + "» внутри foreach");
                    }
                }
            }
            i = close + 1;
        }
        return found;
    }

    /// <summary>Позиция парной скобки (пропуская строки, чары и комментарии).</summary>
    private static int Match(string s, int open, char l, char r)
    {
        int depth = 0;
        for (int i = open; i < s.Length; i++)
        {
            char c = s[i];
            if (c == '/' && i + 1 < s.Length && s[i + 1] == '/') { i = s.IndexOf('\n', i); if (i < 0) return -1; continue; }
            if (c == '/' && i + 1 < s.Length && s[i + 1] == '*') { int e = s.IndexOf("*/", i + 2, StringComparison.Ordinal); return e < 0 ? -1 : (i = e + 1); }
            if (c == '"' || c == '\'')
            {
                char q = c;
                for (i++; i < s.Length; i++) { if (s[i] == '\\') { i++; continue; } if (s[i] == q) break; }
                continue;
            }
            if (c == l) depth++;
            else if (c == r) { depth--; if (depth == 0) return i; }
        }
        return -1;
    }

    private static void BuildMenu()
    {
        Console.WriteLine("[9] PvZ → Собрать билд");
        Fresh(false, "", false, null);
        Debug.Clear();
        UnityEditor.BuildPipeline.Calls = 0;
        PvzBootstrapper.BuildWindows();
        Yes("папка билда создана", Directory.Exists(Path.Combine(PvzBootstrapper.ProjectDir, PvzBootstrapper.BuildDir)));
        Yes("сцена для билда собрана", File.Exists(PvzBootstrapper.SceneFile));
        Yes("в Build Settings лежит эта сцена", HasSceneInBuild());
        Yes("BuildPipeline вызван один раз", UnityEditor.BuildPipeline.Calls == 1);
        var opts = UnityEditor.BuildPipeline.Last;
        Eq("таргет", opts.target, UnityEditor.BuildTarget.StandaloneWindows64);
        Eq("сцена в opts", opts.scenes.Length == 1 ? opts.scenes[0] : null, PvzBootstrapper.ScenePath);
        Yes("путь билда — .exe (иначе Unity не примет)", opts.locationPathName.EndsWith(".exe"));
        Yes("в логе результат из BuildSummary", Debug.AnyContains("[PvZ] билд Succeeded"));
        Yes("в логе размер/время", Debug.AnyContains(" МБ, ") && Debug.AnyContains("ошибок 0"));
        Yes("в ветке успеха ни одного LogError", Debug.Warnings.Count == 0);

        // ветка ошибки: BuildPipeline вернул Failed → код обязан достать SummarizeErrors
        UnityEditor.BuildPipeline.StubResult = UnityEditor.Build.Reporting.BuildResult.Failed;
        Debug.Clear();
        PvzBootstrapper.BuildWindows();
        Yes("Failed виден в логе", Debug.AnyContains("[PvZ] билд Failed"));
        Yes("SummarizeErrors вызван", Debug.AnyContains("проверка ветки ошибок"));
        Yes("LogError сработал", Debug.Warnings.Count > 0);
        UnityEditor.BuildPipeline.StubResult = UnityEditor.Build.Reporting.BuildResult.Succeeded;
    }
}
