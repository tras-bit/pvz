// ============================================================================
//  Заглушки UnityEditor — НУЖНЫ ТОЛЬКО чтобы проверить, что Assets/Editor/*.cs
//  компилируются (ошибка в редакторском скрипте ломает весь проект в Unity).
//  В Unity этот файл не участвует: он лежит вне Assets/.
//  Сигнатуры сверены с API 2022.3.
// ============================================================================
#pragma warning disable CS0108, CS0109, CS0169, CS0414, CS0649
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace UnityEditor
{
    public sealed class Menu
    {
        public static readonly Dictionary<string, bool> Checked = new Dictionary<string, bool>();
        public static int SetCheckedCalls;
        public static void SetChecked(string path, bool on) { Checked[path] = on; SetCheckedCalls++; }
        public static bool GetChecked(string path) { return Checked.TryGetValue(path, out bool v) && v; }
    }

    // ------------------------------------------------------------------ импорты
    // Состав членов повторяет ScriptReference 2022.3, а не «как обычно пишут в
    // блогах»: у TextureImporter НЕТ spriteAlignment/ignoreMasterTextureLimit
    // (первое живёт в TextureImporterSettings, второе с 2022.2 называется
    // ignoreMipmapLimit), у AudioImporter НЕТ loadType/compressionFormat (они в
    // AudioImporterSampleSettings). Если код обратится к тому, чего в 2022.3
    // нет, заглушка падает так же, как Unity.
    public enum TextureImporterType { Default, NormalMap, GUI, Sprite, Cursor, Cookie, Lightmap, SingleChannel }
    public enum TextureImporterNPOTScale { None, ToNearest, ToLarger, ToSmaller }
    public enum TextureImporterCompression { Uncompressed, CompressedLQ, Compressed, CompressedHQ }
    public enum TextureImporterFormat { Automatic = 0, Alpha8, RGB24, RGBA32, ARGB32, RGBA64, R8, R16, R32, RG16, RG32, DXT1, DXT5, ASTC_4x4, ASTC_6x6, BC7 }
    public enum MipmapFilter { Khronos, Box, Triangle, CatmullRom, Mitchell, Lanczos }
    public enum SingleChannelComponent { Alpha = 0, R, G, B }
    public enum TextureResizeAlgorithm { Unspecified, MitchellNetravali, Box, Triangle, CatmullRom, LanczosBeta }
    public enum SpriteImportMode { None, Single, Multiple, GridBySize, GridByCellSize, Automatic }
    public enum SpriteAlignment { Center, TopLeft, TopCenter, TopRight, RightCenter, BottomRight, BottomCenter, BottomLeft, LeftCenter, Custom }
    public enum AlphaSource { InputTextureAlpha, InputTextureRed, InputTextureGreen, InputTextureBlue, InputTextureAlphaIgnored, InputTextureAlphaTransparent, BuiltFromSoftness, SetAlphaTo1 }
    public enum AudioClipLoadType { CompressedInMemory, Streaming, DecompressOnLoad }
    public enum AudioCompressionFormat { PCM, Vorbis, ADPCM, MP3, FMODADPCM }
    public enum AudioSampleRateSetting { OptimizeSampleRate, PreserveSampleRate, OverrideSampleRate }

    public sealed class TextureImporterSettings
    {
        public AlphaSource alphaSource;
        public int aniso;
        public bool alphaIsTransparency, borderMipmap, convertToNormalMap, fadeOut, flipGreenChannel;
        public bool generateCubemap, ignoreMipmapLimit, ignorePngGamma, mipmapEnabled, mipMapsPreserveCoverage;
        public bool readable, sRGBTexture, streamingMipmaps;
        public float alphaTestReferenceValue, heightmapScale, mipmapBias, spritePixelsPerUnit;
        public FilterMode filterMode;
        public MipmapFilter mipmapFilter, normalMapFilter;
        public TextureImporterNPOTScale npotScale;
        public Vector2 spritePivot;
        public Vector4 spriteBorder;
        public int spriteAlignment, spriteExtrude, spriteTessellationDetail;
        public int flipbookColumns, flipbookRows;
        public SpriteImportMode spriteMode;
        public SpriteMeshType spriteMeshType;
        public bool spriteGenerateFallbackPhysicsShape;
        public SingleChannelComponent singleChannelComponent;
    }

    public sealed class TextureImporterPlatformSettings
    {
        public string name = "Default";
        public bool overridden;
        public int maxTextureSize = 2048;
        public TextureImporterFormat format = TextureImporterFormat.Automatic;
        public TextureImporterCompression textureCompression = TextureImporterCompression.Uncompressed;
        public int crunchedCompressionSpeed;
        public int compressionQuality;
        public bool allowsAlphaSplitting;
        public TextureResizeAlgorithm resizeAlgorithm = TextureResizeAlgorithm.MitchellNetravali;
    }

    public class AssetImporter
    {
        public string assetPath = "";
        public string userData = "";
        public string assetBundleName = "";
        public string assetBundleVariant = "";
        public void SaveAndReimport() { }
        public static AssetImporter GetAtPath(string path) { return _all != null && _all.ContainsKey(path) ? _all[path] : null; }
        public static readonly Dictionary<string, AssetImporter> _all = new Dictionary<string, AssetImporter>();
    }

    public sealed class TextureImporter : AssetImporter
    {
        public TextureImporterType textureType;
        public SpriteImportMode spriteImportMode;
        public float spritePixelsPerUnit = 100f;
        public Vector4 spriteBorder;
        public Vector2 spritePivot;
        public bool mipmapEnabled, streamingMipmaps, isReadable, ignoreMipmapLimit, alphaIsTransparency, sRGBTexture;
        public bool crunchedCompression, allowAlphaSplitting, flipGreenChannel;
        public string mipmapLimitGroupName = "";
        public int maxTextureSize = 2048;
        public int anisoLevel = 1;
        public int compressionQuality;
        public float mipMapBias;
        public AlphaSource alphaSource;
        public FilterMode filterMode;
        public TextureWrapMode wrapMode;
        public TextureImporterNPOTScale npotScale;
        public TextureImporterCompression textureCompression;
        public bool qualifiesForSpritePacking { get { return false; } }

        public void ReadTextureSettings(TextureImporterSettings settings)
        {
            if (settings == null) throw new ArgumentNullException("settings");
            settings.spritePixelsPerUnit = spritePixelsPerUnit;
            settings.spritePivot = spritePivot;
            settings.spriteBorder = spriteBorder;
            settings.mipmapEnabled = mipmapEnabled;
            settings.filterMode = filterMode;
            settings.readable = isReadable;
            settings.npotScale = npotScale;
            settings.sRGBTexture = sRGBTexture;
            settings.alphaIsTransparency = alphaIsTransparency;
            settings.ignoreMipmapLimit = ignoreMipmapLimit;
            _read = true;
        }

        public void SetTextureSettings(TextureImporterSettings settings)
        {
            if (settings == null) throw new ArgumentNullException("settings");
            if (!_read) throw new InvalidOperationException("SetTextureSettings без ReadTextureSettings");
            if (settings.spriteAlignment != (int)SpriteAlignment.TopLeft)
                throw new InvalidOperationException("пивот должен быть TopLeft, иначе View считает координаты неверно");
            if (Mathf.Abs(settings.spritePixelsPerUnit - 1f) > 1e-4f)
                throw new InvalidOperationException("PPU должен быть 1 (см. README-UNITY)");
            if (settings.spriteMeshType != SpriteMeshType.FullRect)
                throw new InvalidOperationException("нужен FullRect, иначе Tight-обрезка сдвигает якорь спрайта");
            _applied = settings.spriteAlignment;
            spritePivot = settings.spritePivot;
            spriteBorder = settings.spriteBorder;
            mipmapEnabled = settings.mipmapEnabled;
            isReadable = settings.readable;
            ignoreMipmapLimit = settings.ignoreMipmapLimit;
            filterMode = settings.filterMode;
        }

        public int _applied = int.MinValue;      // проверка из EditorCheck: настройки реально применены
        public bool _read;

        public TextureImporterPlatformSettings GetDefaultPlatformTextureSettings() { return new TextureImporterPlatformSettings(); }
        public TextureImporterPlatformSettings GetPlatformTextureSettings(string platform) { return new TextureImporterPlatformSettings { name = platform }; }
        public void SetPlatformTextureSettings(TextureImporterPlatformSettings s) { }
        public void ClearPlatformTextureSettings(string platform) { }
        public TextureImporterFormat GetAutomaticFormat(string platform) { return TextureImporterFormat.Automatic; }
        public void GetSourceTextureWidthAndHeight(out int w, out int h) { w = 64; h = 64; }
    }

    public struct AudioImporterSampleSettings
    {
        public AudioClipLoadType loadType;
        public AudioCompressionFormat compressionFormat;
        public float quality;
        public AudioSampleRateSetting sampleRateSetting;
        public int sampleRateOverride;
        public bool preloadAudioData;
    }

    public sealed class AudioImporter : AssetImporter
    {
        public bool ambisonic;
        public bool forceToMono;
        public bool loadInBackground;
        public AudioImporterSampleSettings defaultSampleSettings = new AudioImporterSampleSettings
        {
            loadType = AudioClipLoadType.CompressedInMemory,
            compressionFormat = AudioCompressionFormat.Vorbis,
            quality = 0.5f,
            sampleRateSetting = AudioSampleRateSetting.OptimizeSampleRate,
            sampleRateOverride = 44100,
            preloadAudioData = true
        };

        public AudioImporterSampleSettings GetOverrideSampleSettings(BuildTargetGroup g) { return defaultSampleSettings; }
        public void SetOverrideSampleSettings(BuildTargetGroup g, AudioImporterSampleSettings s) { }
        public void ClearSampleSettingOverride(BuildTargetGroup g) { }
        public bool ContainsSampleSettingsOverride(BuildTargetGroup g) { return false; }
    }

    public class AssetPostprocessor
    {
        public string assetPath = "";
        public AssetImporter assetImporter;
        public static void OnPostprocessAllAssets(string[] a, string[] b, string[] c, string[] d) { }
    }

    public sealed class EditorPrefs
    {
        public static readonly Dictionary<string, bool> Bools = new Dictionary<string, bool>();
        public static readonly Dictionary<string, string> Strings = new Dictionary<string, string>();
        public static bool GetBool(string key, bool def = false) { return Bools.TryGetValue(key, out bool v) ? v : def; }
        public static void SetBool(string key, bool v) { Bools[key] = v; }
        public static string GetString(string key, string def = "") { return Strings.TryGetValue(key, out string v) ? v : def; }
        public static void SetString(string key, string v) { Strings[key] = v; }
    }

    public sealed class SceneAsset : UnityEngine.Object { }

    public static class EditorApplication
    {
        public static EditorCallback delayCall;
        public static EditorCallback update;
        public static bool isPlaying, isUpdating;
        public delegate void EditorCallback();
        public static void quit(QuitApplicationMode m) { }
    }

    public enum QuitApplicationMode { AskQuesave, QuitApplication }

    public static class AssetDatabase
    {
        public static T LoadAssetAtPath<T>(string path) where T : UnityEngine.Object
        {
            if (StubAssets.Contains(path))
            {
                object o = System.Activator.CreateInstance(typeof(T));
                ((UnityEngine.Object)o).name = path;
                return (T)o;
            }
            return null;
        }
        public static UnityEngine.Object LoadAssetAtPath(string path, System.Type t) { return null; }
        public static string[] FindAssets(string filter, string[] searchInFolders) { return new string[0]; }
        public static string GUIDToAssetPath(string guid) { return ""; }
        public static bool StubTagManager = true;                // стаб: есть ли ProjectSettings/TagManager.asset
        private static UnityEngine.Object _tagManager;
        public static readonly System.Collections.Generic.HashSet<string> StubAssets = new System.Collections.Generic.HashSet<string>();
        public static UnityEngine.Object[] LoadAllAssetsAtPath(string path)
        {
            if (path == "ProjectSettings/TagManager.asset" && StubTagManager)
            {
                if (_tagManager == null) _tagManager = new UnityEngine.Object { name = "TagManager" };
                return new UnityEngine.Object[] { _tagManager };
            }
            return new UnityEngine.Object[0];
        }
        public static void Refresh() { }
        public static string GetMainAssetPath(string path) { return path; }
    }

    public enum NewSceneSetup { EmptyScene, DefaultGameSetup }
    public enum NewSceneMode { Single, Additive, AdditiveWithoutLoading }

    public sealed class EditorBuildSettingsScene
    {
        public string path;
        public bool enabled;
        public EditorBuildSettingsScene() { }
        public EditorBuildSettingsScene(string path, bool enabled) { this.path = path; this.enabled = enabled; }
    }

    public static class EditorBuildSettings
    {
        public static EditorBuildSettingsScene[] scenes = new EditorBuildSettingsScene[0];
    }

    namespace SceneManagement
    {
        public enum OpenSceneMode { Single, Additive, AdditiveWithoutLoading }

        /// <summary>Стаб с памятью: на что открыта/сохранена «активная сцена»,
        /// сколько раз его трогали — чтобы автосборку можно было проверить офлайн.</summary>
        public static class EditorSceneManager
        {
            public static UnityEngine.SceneManagement.Scene Active = new UnityEngine.SceneManagement.Scene
            {
                name = "Untitled",
                path = "",
                isDirty = false
            };
            public static readonly System.Collections.Generic.List<string> Opened = new System.Collections.Generic.List<string>();
            public static readonly System.Collections.Generic.List<string> Saved = new System.Collections.Generic.List<string>();
            public static int NewSceneCalls, MarkDirtyCalls, ClosedScenes;

            public static void Reset()
            {
                Active = new UnityEngine.SceneManagement.Scene { name = "Untitled", path = "" };
                Opened.Clear(); Saved.Clear();
                NewSceneCalls = MarkDirtyCalls = ClosedScenes = 0;
            }

            public static UnityEngine.SceneManagement.Scene NewScene(NewSceneSetup setup, NewSceneMode mode)
            {
                NewSceneCalls++;
                Active = new UnityEngine.SceneManagement.Scene { name = "New Scene", path = "" };
                return Active;
            }

            public static UnityEngine.SceneManagement.Scene OpenScene(string path, OpenSceneMode mode)
            {
                Opened.Add(path);
                Active = new UnityEngine.SceneManagement.Scene
                {
                    path = path,
                    name = System.IO.Path.GetFileNameWithoutExtension(path),
                    isDirty = false
                };
                return Active;
            }

            public static UnityEngine.SceneManagement.Scene OpenScene(string path) { return OpenScene(path, OpenSceneMode.Single); }
            public static bool SaveScene(UnityEngine.SceneManagement.Scene scene, string path)
            {
                Saved.Add(path);
                // Unity на SaveScene реально пишет .unity на диск — стаб тоже, иначе
                // проверки «файл сцены есть» ничего не стоят
                try
                {
                    string data = UnityEngine.Application.dataPath;
                    string root = string.IsNullOrEmpty(data) ? Directory.GetCurrentDirectory()
                                                              : Path.GetDirectoryName(Path.GetFullPath(data));
                    string full = Path.Combine(root, path.Replace('/', Path.DirectorySeparatorChar));
                    Directory.CreateDirectory(Path.GetDirectoryName(full));
                    File.WriteAllText(full, "%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n--- !u!1001 &1\nSceneSettings:\n  m_ObjectHideFlags: 0\n");
                }
                catch (Exception e) { Debug.LogWarning("SaveScene stub: " + e.Message); }
                var s = Active;
                s.path = path;
                s.name = System.IO.Path.GetFileNameWithoutExtension(path);
                s.isDirty = false;
                Active = s;
                return true;
            }
            public static bool MarkSceneDirty(UnityEngine.SceneManagement.Scene scene) { MarkDirtyCalls++; return true; }
            public static bool SaveOpenScenes() { return true; }
            public static bool CloseScene(UnityEngine.SceneManagement.Scene scene, bool removeScene) { ClosedScenes++; return true; }
            public static UnityEngine.SceneManagement.Scene GetActiveScene() { return Active; }
        }
    }

    // ------------------------------------------------------------------ игрок
    public enum ColorSpace { Uninitialized, Gamma, Linear }

    public static class PlayerSettings
    {
        public static ColorSpace colorSpace = ColorSpace.Uninitialized;
        public static bool runInBackground = true;
        public static string productName = "PvZ";
    }

    public static class EditorUtility
    {
        public static void RevealInFinder(string p) { }
        public static bool DisplayDialog(string title, string message, string ok) { return true; }
        public static bool DisplayDialog(string title, string message, string ok, string cancel) { return true; }
        public static void SetDirty(UnityEngine.Object o) { }
    }

    public static class Undo
    {
        public static void RegisterCreatedObjectUndo(UnityEngine.Object o, string name) { }
    }

    public sealed class SerializedProperty
    {
        public string stringValue = "";
        public int intValue;
        public bool boolValue;
        public bool boolValueSet;                       // стаб: различаем «не трогали» и false

        private readonly Dictionary<string, SerializedProperty> _children = new Dictionary<string, SerializedProperty>();
        private readonly List<SerializedProperty> _items = new List<SerializedProperty>();

        public int arraySize { get { return _items.Count; } }
        public void InsertArrayElementAtIndex(int i)
        {
            if (i < 0 || i > _items.Count) throw new ArgumentOutOfRangeException("i");
            _items.Insert(i, new SerializedProperty());
        }
        public void ClearArray() { _items.Clear(); }
        public SerializedProperty GetArrayElementAtIndex(int i) { return _items[i]; }
        public SerializedProperty FindPropertyRelative(string name)
        {
            SerializedProperty p;
            if (!_children.TryGetValue(name, out p)) { p = new SerializedProperty(); _children[name] = p; }
            return p;
        }
        internal IReadOnlyList<SerializedProperty> Items { get { return _items; } }
        internal bool HasChild(string name) { return _children.ContainsKey(name); }
    }

    public sealed class SerializedObject
    {
        public static readonly List<SerializedObject> All = new List<SerializedObject>();
        public static bool FailUnknownProperties = true;         // как Unity: неизвестное свойство = null
        // что реально лежит в TagManager.asset (иначе тест нечем проверять)
        public static readonly HashSet<string> KnownProperties = new HashSet<string>
        {
            "m_SortingLayers", "m_SortingLayerIDs", "m_TagList", "m_SortingLayerID", "m_SortingLayerName"
        };

        private static readonly Dictionary<UnityEngine.Object, SerializedObject> _byTarget =
            new Dictionary<UnityEngine.Object, SerializedObject>();

        private Dictionary<string, SerializedProperty> _props = new Dictionary<string, SerializedProperty>();
        public readonly UnityEngine.Object target;
        public int ApplyCalls;

        public SerializedObject(UnityEngine.Object o)
        {
            target = o;
            // как Unity: свойства принадлежат объекту, новый SerializedObject на том же
            // объекте видит прежние значения (иначе нельзя проверить идемпотентность)
            SerializedObject prev;
            if (o != null && _byTarget.TryGetValue(o, out prev) && prev._props != null) _props = prev._props;
            if (o != null) _byTarget[o] = this;
            All.Add(this);
        }
        public static void ForgetTargets() { _byTarget.Clear(); }
        public SerializedProperty FindProperty(string name)
        {
            SerializedProperty p;
            if (_props.TryGetValue(name, out p)) return p;
            if (FailUnknownProperties && !KnownProperties.Contains(name)) return null;
            if (FailUnknownProperties) { p = new SerializedProperty(); _props[name] = p; return p; }
            p = new SerializedProperty();
            _props[name] = p;
            return p;
        }
        public SerializedProperty FindPropertyOrCreate(string name)   // только для харнесса
        {
            FailUnknownProperties = false;
            try { return FindProperty(name); }
            finally { FailUnknownProperties = true; }
        }
        public bool ApplyModifiedProperties() { ApplyCalls++; return true; }
        public void Update() { }
        internal IReadOnlyDictionary<string, SerializedProperty> Props { get { return _props; } }
    }

    // ------------------------------------------------------------------ билд
    public enum BuildTarget { NoTarget = -2, StandaloneWindows64 = 19, StandaloneOSX = 2, StandaloneLinux64 = 24 }
    [Flags]
    public enum BuildOptions { None = 0, Development = 1, AutoPlay = 64, CompressWithLz4 = 512 }

    public sealed class BuildPlayerOptions
    {
        public string[] scenes;
        public string locationPathName;
        public BuildTarget target;
        public BuildOptions options;
        public BuildTargetGroup targetGroup;
        public string assetBundleManifestPath;
        public int optionsExtra;
    }

    public enum BuildTargetGroup { Unknown = 0, StandaloneWindows64 = 8, WebGL = 13 }

    public static class BuildPipeline
    {
        public static UnityEditor.Build.Reporting.BuildResult StubResult =
            UnityEditor.Build.Reporting.BuildResult.Succeeded;
        public static string StubErrorText = "stub: сборка не удалась (проверка ветки ошибок)";
        public static int Calls;
        public static BuildPlayerOptions Last;

        public static UnityEditor.Build.Reporting.BuildReport BuildPlayer(BuildPlayerOptions opts)
        {
            Calls++;
            Last = opts;
            if (opts == null) throw new ArgumentNullException("opts");
            if (opts.scenes == null || opts.scenes.Length == 0) throw new InvalidOperationException("нет сцен");
            for (int i = 0; i < opts.scenes.Length; i++)
                if (string.IsNullOrEmpty(opts.scenes[i])) throw new InvalidOperationException("пустой путь сцены");
            if (opts.target == BuildTarget.StandaloneWindows64 &&
                (opts.locationPathName == null || !opts.locationPathName.EndsWith(".exe")))
                throw new InvalidOperationException("для StandaloneWindows64 нужен путь .exe (Unity ругается так же)");
            return new UnityEditor.Build.Reporting.BuildReport(opts, StubResult, StubErrorText);
        }
    }

    // ------------------------------------------------------------------ атрибуты    // ------------------------------------------------------------------ атрибуты
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class MenuItemAttribute : Attribute
    {
        public readonly string path;
        public readonly bool isValidateFunction;
        public readonly int priority;
        public MenuItemAttribute(string path) { this.path = path; }
        public MenuItemAttribute(string path, bool isValidateFunction, int priority)
        { this.path = path; this.isValidateFunction = isValidateFunction; this.priority = priority; }
    }

    [AttributeUsage(AttributeTargets.Class)]
    public sealed class InitializeOnLoadAttribute : Attribute { }

    [AttributeUsage(AttributeTargets.Class)]
    public sealed class InitializeOnLoadMethodAttribute : Attribute { }

    [AttributeUsage(AttributeTargets.Method)]
    public sealed class DidReloadScriptsAttribute : Attribute { }
}

namespace UnityEditor.Build.Reporting
{
    public enum BuildResult { Unknown = 0, Succeeded = 1, Failed = 2, Cancelled = 3, Error = 4 }
    public enum BuildReportMessage { Info = 0, Warning = 1, Error = 2 }

    /// <summary>Состав членов — по ScriptReference 2022.3: у BuildReport НЕТ
    /// result/totalTime, они в BuildSummary (report.summary).</summary>
    public sealed class BuildReport
    {
        private readonly BuildPlayerOptions _opts;
        private readonly BuildResult _result;
        private readonly string _errors;

        public BuildReport(BuildPlayerOptions opts, BuildResult result, string errors)
        {
            _opts = opts; _result = result; _errors = errors;
        }

        public BuildSummary summary
        {
            get
            {
                return new BuildSummary
                {
                    result = _result,
                    outputPath = _opts == null ? "" : _opts.locationPathName,
                    platform = _opts == null ? BuildTarget.NoTarget : _opts.target,
                    options = _opts == null ? BuildOptions.None : _opts.options,
                    totalSize = 0,
                    totalTime = TimeSpan.Zero,
                    totalErrors = _result == BuildResult.Succeeded ? 0 : 1,
                    totalWarnings = 0,
                    buildStartedAt = DateTime.Now,
                    buildEndedAt = DateTime.Now,
                    guid = Guid.NewGuid().ToString()
                };
            }
        }

        public BuildStep[] steps { get { return new[] { new BuildStep { name = "Postprocess player", depth = 0, duration = TimeSpan.Zero } }; } }
        public BuildReport.PackedSprite[] packedAssets { get { return new BuildReport.PackedSprite[0]; } }
        public object strippingInfo { get { return null; } }
        public string SummarizeErrors() { return _errors ?? ""; }
        public string[] GetFiles() { return new string[0]; }
        public static BuildReport GetLatestReport() { return null; }

        public class PackedSprite { public string assetPath; public ulong totalSize; }
    }

    public struct BuildSummary
    {
        public BuildResult result;
        public string outputPath;
        public BuildTarget platform;
        public BuildTargetGroup platformGroup;
        public BuildOptions options;
        public ulong totalSize;
        public TimeSpan totalTime;
        public int totalErrors;
        public int totalWarnings;
        public DateTime buildStartedAt;
        public DateTime buildEndedAt;
        public string guid;
        public int GetSubtarget() { return 0; }
    }

    public sealed class BuildStep
    {
        public string name;
        public int depth;
        public TimeSpan duration;
        public Message[] messages = new Message[0];
        public struct Message { public BuildReportMessage type; public string content; }
    }
}
